# Diamond Rush — Animation & Timed-State System

Findings from decompiling the game's own logic (class `k`/`h`, N70 and N73 builds — level
data and object IDs are confirmed identical between builds, see project notes). This
documents the *general* mechanism the original game uses to animate anything and time any
state change — chest opening, torch flicker, boulder cracking, etc. — so it can be built
once in `dr_engine.py` and reused for all of them, starting with chest-opening + rewards.

## 1. One global tick counter drives everything

There is a single counter, `aP`, incremented once per game logic step. Nothing in the game
has its own private timer. Instead, individual objects gate their own updates by testing a
bit (or a few bits) of this shared counter, e.g.:

```java
if ((aP >> 1 & 1) == 0) { /* only do this on every other tick */ }
```

Different objects test different bits/shifts of `aP` to get different effective speeds
(full speed, half speed, quarter speed, etc.) without needing a separate clock each.

**Port equivalent:** keep one incrementing `tick` counter in `Game`, advanced once per
logic update. Any animated object checks `tick & mask` the same way instead of tracking
its own elapsed time.

## 2. Every level cell is a packed int, not just an object ID

Throughout this session the "object ID" (0–53, 74, terrain 80+) has meant the **low byte**
of each cell's stored value. That's only half of it. The **upper bits hold a per-instance,
mutable progress counter** — separate storage for every individual placed object, even two
of the same type on the same level.

```
cell value = (progress_counter << 8) | type_id
```

- `type_id = cell & 0xFF` — static, what's been mapped all session (14/33 = chests, etc.)
- `progress = cell >> 8` — dynamic, starts at 0, climbs over time or on interaction, can
  hit a terminal/sentinel value that means "done" (see chests below).

**Port equivalent:** a level cell can't just be an int ID anymore if it's animated/statey.
Needs at minimum `(type_id, progress)` per instance — a dict keyed by cell position holding
progress counters for cells that are mid-animation is the simplest fit, defaulting to 0/absent
for static terrain.

## 3. The generic per-object state-machine pattern

Every timed object in the game follows the same shape:

1. **Trigger** — either free-running from level load (decoration, e.g. a torch), or started
   by player interaction (a chest).
2. **Tick-gated increment** — each qualifying tick (per §1), `progress += step` (usually
   `+= 256`, i.e. +1 in the upper byte; sometimes a smaller step into a nibble instead of a
   full byte, e.g. `& 0xF00` masks a 4-bit sub-counter for shorter cycles).
3. **Frame lookup** — the draw code reads the *same* progress value to pick which frame of
   the object's small animation clip to show, e.g. (from the chest-draw routine):
   ```java
   int spriteSlot = (typeId == 14) ? 8 : 22;      // which sprite file/chunk
   int frame = cellValue >> 8;                     // which frame within it
   ```
4. **Terminal transition** — once `progress` reaches a max, something happens: the object
   is removed, replaced, or (for looping decorations) wraps back to 0 instead of stopping.

## 4. Confirmed concrete example: chest opening (IDs 14 & 33)

- **Sentinel:** `255` in the progress byte means "already opened, stays empty forever."
  The interaction handler (`w(int)`, the player-action dispatcher) explicitly checks this
  and refuses to reopen an already-opened chest:
  ```java
  int typeId = cell & 0xFF;
  if ((typeId == 14 || typeId == 33) && (cell >> 8) == 255) return;  // no-op, already open
  ```
- Interacting with a fresh chest (progress not yet 255) starts the sequence — progress
  begins climbing from 0/1 on qualifying ticks, using the same tick-gated-increment pattern
  as everything else.
- The draw side is the `k(int)` method found earlier this session: sprite slot 8 for type
  14, slot 22 for type 33, frame = `cell >> 8`. Both types share one draw function, which is
  why 14 and 33 render as visually identical closed-chest icons at progress 0 — the actual
  chest color art presumably only differs in later frames of each slot's clip (not yet
  screenshotted frame-by-frame — see Open Questions).
- **Reward granting** is presumably tied to the terminal transition (progress hits its max
  and/or gets set to 255), but the exact line that grants the item and which frame that
  corresponds to visually hasn't been isolated yet — see Open Questions.

## 5. Other confirmed examples of the same pattern (different objects, not yet identified by ID)

- A per-cell counter in a *different* backing array (`b[][]`, distinct from the main `a[][]`
  cell-type array) increments by a full step every hit and triggers a removal once it
  reaches 8 — reads like a "hit this N times to break it" mechanic (candidate: a
  crackable/breakable object, maybe the sandy block or a pressure-triggered wall — not
  confirmed against a specific ID yet).
- A nibble-sized counter (masked with `0xF00`, so only 4 bits / max value 4) advances one
  step every *other* tick and resets the object at 4 — same shape as the chest logic but
  faster-cycling and smaller range, consistent with something like a short flicker or blink
  effect rather than a multi-second open animation.

These confirm the pattern is genuinely the game's universal mechanism, not something
special-cased just for chests — which is exactly why it's worth building once, generically.

## 6. Recommended `dr_engine.py` implementation shape

```python
# Per-instance state for any cell that's mid-animation or interactive.
# Static/never-touched cells need no entry — absence means progress 0 / not started.
anim_state: dict[(x, y), int] = {}

ANIM_TABLE = {
    14: dict(slot=8,  step_mask=0b1,  max_progress=..., loops=False),  # chest type A
    33: dict(slot=22, step_mask=0b1,  max_progress=..., loops=False),  # chest type B
    # statue torch, jar glow, etc. go here too, with loops=True and no interact-trigger
}

def tick_animations(self):
    self.tick += 1
    for (x, y), progress in list(self.anim_state.items()):
        typ = self.type_id_at(x, y)
        cfg = ANIM_TABLE[typ]
        if progress >= cfg['max_progress']:
            if cfg['loops']:
                self.anim_state[(x, y)] = 0
            else:
                self.on_animation_complete(x, y, typ)   # grant reward, remove/replace, etc.
            continue
        if (self.tick & cfg['step_mask']) == 0:
            self.anim_state[(x, y)] = progress + 1

def interact(self, x, y):
    typ = self.type_id_at(x, y)
    if typ in (14, 33) and self.anim_state.get((x, y)) == SENTINEL_DONE:
        return  # already opened
    if typ in ANIM_TABLE and (x, y) not in self.anim_state:
        self.anim_state[(x, y)] = 1   # kick off the open animation
```

Decorations (statue, jar) would populate `anim_state` at level load instead of on
interaction, with `loops=True` and no `on_animation_complete` side effect — same tick loop,
no special-casing needed.

## 7. Open questions / not yet confirmed

- Exact frame count and per-frame duration for chest slots 8 and 22 (how many frames make
  up "opening", and which frame is "fully open") — needs walking up to a real chest in the
  emulator and screenshotting the open sequence frame-by-frame, which hasn't been done yet
  (only the closed/idle frame has been screenshotted and matched).
- The precise line that grants the reward item and how it picks red-diamonds vs.
  compass/hammer/hookshot/ice-mallet/potion (per the user's chest-contents theory) — not
  yet isolated in the decompiled code.
- Whether the blue-chest-swaps-to-healing-potion-if-hurt logic (per the user's theory) is
  part of this same routine or a separate health check — not yet located.
- The two "other confirmed examples" in §5 are not yet tied to specific object IDs from
  this session's ID map — worth cross-referencing against the gallery findings (the
  invisible IDs 2/3/5/6/7/9/13/74 tested earlier, which may turn out to be exactly these).
- Statue/jar's actual tick-gate mask and frame count haven't been individually confirmed —
  only the general pattern (torch-flicker-shaped 8-frame sprite chunk) is known so far.
