# Diamond Rush Port — Patch v0.1a — Findings Summary

Consolidated from this session's work. Cross-reference `dr_engine.py`'s inline comments,
`ANIMATION_SYSTEM.md`, and `emulator_tools/gallery_and_matching/id_matches_world0.json` for
detail — this file is the narrative summary tying it together.

## Primary target build switched to N73

The project's reference build is now `Diamond_Rush__240x320___Nokia_N73___andrew-lviv_net__jar.zip`
(MIDlet-Version 1.0.0, "[ANDREW-LVIV] / Gameloft SA", CLDC-1.1/MIDP-2.0), replacing the older
`Diamond-Rush_J2ME_EN_v109-Nokia-N70.jar`. Reasons: it has a genuinely working debug/cheat menu
(confirmed on real N73 hardware), and the user has more hands-on familiarity with it.

**Verified compatible:** world 0's level data is byte-identical between the two builds except for
a single byte (one extra chest placed in the N73 build, level index 6). So every ID-mapping finding
below — derived against the N70 jar — carries over directly; no need to redo gallery testing.

## Confirmed object IDs (layer 0 unless noted)

| ID | Meaning | Confidence |
|---|---|---|
| 0 | Boulder | high (pre-existing) |
| 1 | Diamond | high (pre-existing) |
| 4 | Diamond-gated exit/lock icon (NOT a chest, NOT a pickup — see corrections below) | high — decompiled `Y()` routine, checks a diamond-count threshold |
| 10 | Bush | high (pre-existing) |
| 12 | Exit | high (pre-existing) |
| 14, 33 | The two chest types (which is red/blue not yet confirmed) | high — confirmed 3 ways: this session's emulator gallery (visually identical closed icon), an independent decompile of a different build (v1.2.0) calling one shared `method_342(14)`/`method_342(33)` open routine, and a real N73-build level placing an actual id-33 chest |
| 19 | Snake | medium (earlier session) |
| 79 | Player start | high |
| 80–127 | Terrain tiles | high, fully rendered/confirmed visually |
| 20/21 (layer 2) | Wall-mounted torch niche, animated flicker | high — confirmed live in emulator this session |
| 22/23 (layer 2) | A golden bracket/arch decoration — **not** the statue (corrects an earlier guess) | high |
| 4 (layer 2) | Checkpoint | high — co-located with player start in real level data |

**Layer 0 and layer 2 are separate ID namespaces.** The same number means different things
depending which layer it's in — confirmed multiple times (e.g. layer-2 `4` = checkpoint, layer-0
`4` = exit lock).

## Corrections made this session (in order — each supersedes the last)

1. ~~ID 4 = red chest~~ → **corrected:** ID 4 is the diamond-gated exit-lock icon. The original
   "pixel-exact chest match" was real pixels, wrong object — likely matched the wrong frame.
2. ~~ID 4 = hammer pickup lying on the ground (`TOOL_PICKUPS`)~~ → **corrected and removed.** User
   confirmed tools/mallets/potions/red diamonds are **never** overworld pickups — they only come
   from chests. The whole ground-pickup model was wrong, not just the specific ID.
3. ~~Layer-2 20/21/22/23 = the statue's four quadrants~~ → **partially corrected.** 20/21 is
   actually a torch niche; 22/23 is a bracket decoration near the statue, not the statue itself.
   **The statue's real placement mechanism is still unconfirmed** — may need multiple co-located
   values not yet tried together, or may be baked into the terrain tileset rather than placed as
   an object at all.
4. The `extras/` folder's `DIAMOND_RUSH_LEVEL_FORMAT.md` claims a `0x55` XOR obfuscation on level
   layers — **empirically disproven** (raw, non-XORed bytes work correctly when patched directly
   into a running jar). The user has told that collaborator to abandon it.
5. `render_dr.py`'s object-ID guess table (layer-0 `2`=chest, layer-2 `33`=blue chest, etc.) was
   tested live and **did not hold up** — none of those specific cells rendered anything.

## The animation/timing system (full detail in `ANIMATION_SYSTEM.md`)

Confirmed from the decompiled code: one global tick counter drives all timing; every level cell is
actually a packed int (low byte = static type ID, upper bits = a per-instance mutable progress
counter); per-tick functions gate on bits of the counter and increment progress; the draw code
reads the same counter to pick a frame; a terminal value triggers a state change. Confirmed
concretely for chests: progress `255` means "already opened, stays empty" — the game's own
interaction dispatcher checks for and refuses to reopen a chest already at that value.

This is now implemented as a generic, reusable `AnimClock` class in `dr_engine.py` and wired to:
- **Chests** (open-on-interact, tick-gated progress, terminal → `_grant_chest_reward()` stub)
- **Player walk/push animation** (now uses real per-frame durations instead of a movement-distance
  approximation)

**Not yet wired** (needs the placement-mechanism questions above resolved first): statue torch
flicker, jar/cauldron glow, and real chest artwork (only a placeholder colored box renders for
chests right now — no confirmed sprite file/chunk for IDs 14/33's actual art yet).

## The debug/cheat menu (`#4772`)

Confirmed via bytecode disassembly: genuinely live, working code in the N73 build (a real
key-sequence state machine), dead/unused code in the older N70 jar. User provided video proof of
it working on real hardware. Full menu text:
- Press 6 — Add diamonds (+0)
- Press 7 — Add red diamonds (+0)
- Press 8 — Available weapons (×0)
- Press 9 — Unlock all stages (off)
- Press 0 — Unlock secret stages (off)
- Press 5 — activate lang cheat
- Pound (#) — toggle "pass levels" off/on

Usage tips from the user: don't stand on the blue checkpoint circle while entering it; pressing `*`
kills the player. **Not yet reproduced in FreeJ2ME-Plus** despite the code being confirmed
live — looks like an emulator input-compatibility gap, not a problem with the code itself. Worth
trying a different J2ME emulator (e.g. J2ME Loader) if this needs to be reproduced again.

## Chest contents theory (user's, not yet confirmed against code)

Red/important chests give tools (compass, hammer/mallet, hookshot, ice mallet), a blue potion, or
sometimes a stack of red diamonds. Blue/common chests give 1–10 purple diamonds, but detect if the
player is hurt and swap to a healing green potion instead. Not yet located in the decompiled code;
`self.chests[pos]['param']` (the cell's layer-1 value) is captured and is the leading candidate for
where the specific-reward encoding lives, but this is unconfirmed.

## Other decompilation projects reviewed (credited, cross-referenced)

- **palaceswitcher/Diamond-Rush-Decomp** — different build (v1.2.0, Sony Ericsson S700), but its
  named sound constants and shared open-chest routine independently confirmed IDs 14/33 as the two
  chest types (see above). Genuinely useful.
- **kubikaugustyn/DiamondRushSource** — Nokia-line build like ours, mostly scaffolding so far.
- **VuqarAhadli/DRVM** — a custom JVM/disassembler for running the game natively elsewhere, not a
  source decomp. Not useful for ID-mapping.
- **musanif01/diamondrush** (found independently) — a TypeScript remake; does *not* faithfully
  decode real object IDs, uses its own invented tile scheme. Not usable as a reference.

## What's in this patch

- `dr_engine.py` — updated engine: corrected chest IDs, the `AnimClock` animation system, chest
  open/interact/reward-stub logic, corrected player animation timing, removed the wrong
  ground-pickup model, layer-1 capture.
- `ANIMATION_SYSTEM.md` — full technical writeup of the animation/timing mechanism with code
  citations and a suggested implementation shape (superseded in part by `dr_engine.py` now
  actually implementing it, but still the best explanation of *why*).
- `emulator_tools/` — everything needed to reproduce this session's live-emulator investigation:
  `setup_emulator.sh` (installs FreeJ2ME-Plus + deps), `run_emu.sh`/`boot_game.sh` (launch),
  `emu_ctl.py`/`tap.py`/`tour.py` (screenshot/input), `record_walk.py`/`stitch.py` (panorama
  capture), `make_dev_jar.py` (patches a jar to build synthetic "ID gallery" test levels — the
  main tool used to identify object IDs this session), `match_ids.py` (automated sprite-frame
  matching), and `id_matches_world0.json` (its output).
- `decompiled_source/` — CFR-decompiled Java source for both jars (`n70/` and `n73/`), for
  reference. Only read this, never used to run/redistribute the Java itself.

## Open items for next session

1. Chest open-animation frame-by-frame capture — walk to a real chest (level index 6/"Stage 7" in
   the N73 build has four) and screenshot the actual open sequence. Not yet done.
2. The statue's real placement/trigger mechanism — still unconfirmed after this session's testing.
3. Reproduce `#4772` in FreeJ2ME-Plus, or switch to a different emulator for it.
4. Locate the actual reward-granting code for chests (ties into the red/blue contents theory).
5. Confirm which of the player's idle-sway anim candidates (41/42/43 + mirrored 44/45/46) map to
   which facing direction, then wire up idle animation (currently a static single frame).
