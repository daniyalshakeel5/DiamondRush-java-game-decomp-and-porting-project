#!/bin/bash
# One-time setup: headful Java + virtual display + window manager + FreeJ2ME-Plus, so the ORIGINAL
# Diamond Rush jar can be run and screenshotted in a headless sandbox.
set -e
apt-get install -y openjdk-21-jre xvfb openbox xdotool x11-utils imagemagick ffmpeg libxrender1 libxtst6 libxi6 fontconfig
mkdir -p /home/claude/work/emu && cd /home/claude/work/emu
curl -sL -o fj.zip https://github.com/TASEmulators/freej2me-plus/releases/download/1.52/freej2me-v1.52.zip
unzip -o -q fj.zip
echo "Now copy the Diamond Rush jar to /home/claude/work/emu/dr.jar, copy run_emu.sh + emu_ctl.py here, and run ./run_emu.sh"
echo "Then: python3 emu_ctl.py key Return --wait 2 ; python3 emu_ctl.py shot out.png   (keys: Up/Down/Left/Right/Return; input needs the window activated, which emu_ctl does)"
