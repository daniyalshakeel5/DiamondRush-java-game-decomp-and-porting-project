#!/usr/bin/env python3
"""tour.py : walk the gallery aisles, take a screenshot at exact player cells, annotate each niche with its ID.
Assumes the player is somewhere on aisle y=5 to start. Outputs /tmp/tour_<aisle>_<n>.png (2x, annotated) + raw crops in /tmp/cells/."""
import json, os, subprocess, sys, time
os.environ['DISPLAY'] = ':99'
sys.path.insert(0, '/home/claude/work/emu')
import emu_ctl
from PIL import Image, ImageDraw
slots = {k: tuple(v) for k, v in json.load(open('/home/claude/work/devlevel/dev.jar.slots.json')).items()}
MW, MH = 26, 21
os.makedirs('/tmp/cells', exist_ok=True)
def tap(key, n, hold=0.22, gap=0.3):
    subprocess.check_call(['python3', '/home/claude/work/emu/tap.py', key, str(n), str(hold), str(gap)])
def hold(key, secs):
    w = emu_ctl.win(); subprocess.call(['xdotool', 'windowactivate', w]); time.sleep(0.2)
    subprocess.check_call(['xdotool', 'keydown', key]); time.sleep(secs); subprocess.check_call(['xdotool', 'keyup', key]); time.sleep(0.6)
def grab(path):
    emu_ctl.shot('/tmp/_full.png', scale=1); Image.open('/tmp/_full.png').crop((0, 0, 176, 180)).save(path)
def cam(px, py):
    cx = max(0, min(MW*24-176, px*24+12-88)); cy = max(0, min(MH*24-180, py*24+12-90)); return cx, cy
def annotate(path, px, py, out, sheet):
    cx, cy = cam(px, py); im = Image.open(path).convert('RGB'); d = ImageDraw.Draw(im)
    for v, (x, y) in slots.items():
        sx, sy = x*24-cx, y*24-cy
        if -24 < sx < 176 and -24 < sy < 180:
            c = im.crop((max(0, sx-12), max(0, sy-24), min(176, sx+36), min(180, sy+36)))   # 48x60 window around the cell
            c.save(f'/tmp/cells/id{v.replace(":","_")}_{sheet}.png')
            d.text((sx+1, sy+1), str(v), fill=(255, 255, 0))
    im.resize((352, 360), Image.NEAREST).save(out)
def aisle(y, tag):
    hold('Left', 6); shots = []
    for i, stop in enumerate([1, 7, 13, 19, 23]):
        if i: tap('Right', 7 if i == 1 else 6 if stop < 23 else 4)
        if stop == 23:
            pass
        p = f'/tmp/raw_{tag}_{i}.png'; grab(p); annotate(p, stop, y, f'/tmp/tour_{tag}_{i}.png', f'{tag}{i}'); shots.append(f'/tmp/tour_{tag}_{i}.png')
    return shots
if __name__ == '__main__':
    tag, y = sys.argv[1], int(sys.argv[2])
    print(aisle(y, tag))
