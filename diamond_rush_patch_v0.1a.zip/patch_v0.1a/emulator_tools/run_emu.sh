#!/bin/bash
export DISPLAY=:99
cd /home/claude/work/emu
nohup setsid Xvfb :99 -screen 0 800x700x24 >/tmp/xvfb.log 2>&1 &
sleep 2
nohup setsid openbox >/tmp/ob.log 2>&1 &
sleep 1
nohup setsid java -Dfile.encoding=ISO_8859_1 -jar freej2me.jar ${1:-dr.jar} >/tmp/fj.log 2>&1 &
