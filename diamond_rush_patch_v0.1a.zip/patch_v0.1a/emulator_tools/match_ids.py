#!/usr/bin/env python3
"""Match each object id's on-screen appearance (from gallery screenshots taken in the ORIGINAL game) to a sprite
(file, chunk, frame) from the jar. Uses an empty niche as background reference, aligns bounding boxes, scores by pixel diff."""
import sys, json, glob, os, zipfile
sys.path.insert(0, '/home/claude/work/repo/diamond_rush_port_v0.3')
os.environ['SDL_VIDEODRIVER'] = 'dummy'
import numpy as np
from PIL import Image
from dr_engine import Assets
A = Assets('/home/claude/work/repo/Diamond-Rush_J2ME_EN_v109-Nokia-N70.jar')
slots = {int(k): tuple(v) for k, v in json.load(open('/home/claude/work/matcher/slots_full.json')).items()}
MW, MH = 26, 21
def cam(px, py): return max(0, min(MW*24-176, px*24+12-88)), max(0, min(MH*24-180, py*24+12-90))
# (raw shot prefix, aisle y, stops)
SHOTS = [('A5', 5), ('B13', 13), ('B19', 19)]; STOPS = [1, 7, 13, 19, 23]
views = []   # (image array 180x176x3, cam)
for tag, y in SHOTS:
    for i, st in enumerate(STOPS):
        p = f'/tmp/raw_{tag}_{i}.png'
        if os.path.exists(p): views.append((np.asarray(Image.open(p).convert('RGB')).astype(np.int16), cam(st, y)))
def window(v, x, y):
    img, (cx, cy) = v; sx, sy = x*24-cx-12, y*24-cy-12       # 48x48 window centred on the cell
    if sx < 0 or sy < 0 or sx+48 > 176 or sy+48 > 180: return None
    return img[sy:sy+48, sx:sx+48]
def find_pair(idv):
    x, y = slots[idv]; best = None
    for v in views:
        w = window(v, x, y)
        if w is None: continue
        for e in EMPTY_IDS[y]:
            if e == idv: continue
            ex, ey = slots[e]; r = window(v, ex, ey)
            if r is None: continue
            score = (np.abs(w - r).sum(2) > 40)[8:40, 8:40].sum()
            if best is None or score > best[0]: best = (score, w, r)
            break
    return None if best is None else (best[1], best[2])
EMPTY_IDS = {3: [2,3,5,6,7,9], 7: [13,15,16,17,18,20,21], 11: [24,25,26,27,28,29,31,32], 15: [33,39,40,41,42,43], 17: [48,49,50,51,52,53,74]}
# candidate frames
cands = []
z = zipfile.ZipFile('/home/claude/work/repo/Diamond-Rush_J2ME_EN_v109-Nokia-N70.jar')
for name in sorted(n for n in z.namelist() if n.endswith('.f')):
    try: nch = len(A.chunks(name))
    except Exception: continue
    for ci in range(nch):
        try: spr = A.sprite(name, ci); nfr = len(spr.frame_count)
        except Exception: continue
        for fr in range(nfr):
            try: im, (ox, oy) = A.frame(spr, fr)
            except Exception: continue
            if im is None: continue
            a = np.asarray(im.convert('RGBA')).astype(np.int16)
            ys, xs = np.nonzero(a[:, :, 3] > 0)
            if len(xs) < 6: continue
            cands.append((name, ci, fr, a, ox, oy, xs.min(), ys.min(), xs.max()-xs.min()+1, ys.max()-ys.min()+1))
print('candidate frames:', len(cands), file=sys.stderr)
out = {}
for idv in sorted(slots):
    pr = find_pair(idv)
    if pr is None: out[idv] = 'no-view'; continue
    w, ref = pr
    d = np.abs(w - ref).sum(2) > 40
    if d[8:40, 8:40].sum() < 6: out[idv] = 'invisible'; continue
    ys, xs = np.nonzero(d[:, :]); 
    # keep the connected blob nearest the cell centre: just use the bbox of diff pixels
    tx0, ty0, tx1, ty1 = xs.min(), ys.min(), xs.max()+1, ys.max()+1; tw, th = tx1-tx0, ty1-ty0
    best = []
    for (name, ci, fr, a, ox, oy, bx, by, bw, bh) in cands:
        if abs(bw-tw) > 3 or abs(bh-th) > 3: continue
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                px0 = tx0 - bx + dx; py0 = ty0 - by + dy       # place candidate so its opaque bbox top-left meets the target's
                canvas = ref.copy()
                h, ww = a.shape[:2]
                x0, y0 = max(0, px0), max(0, py0); x1, y1 = min(48, px0+ww), min(48, py0+h)
                if x1 <= x0 or y1 <= y0: continue
                sub = a[y0-py0:y1-py0, x0-px0:x1-px0]; m = sub[:, :, 3:4] > 127
                canvas[y0:y1, x0:x1] = np.where(m, sub[:, :, :3], canvas[y0:y1, x0:x1])
                region = d | (np.abs(canvas - ref).sum(2) > 40)
                if region.sum() == 0: continue
                err = np.abs(canvas - w).sum(2)[region].mean() / 3
                best.append((err, name, ci, fr))
    best.sort(); out[idv] = [(round(e, 1), n, c, f) for e, n, c, f in best[:4]]
    print(idv, out[idv][:3], file=sys.stderr)
json.dump({str(k): v for k, v in out.items()}, open('/tmp/id_matches.json', 'w'), indent=1)
