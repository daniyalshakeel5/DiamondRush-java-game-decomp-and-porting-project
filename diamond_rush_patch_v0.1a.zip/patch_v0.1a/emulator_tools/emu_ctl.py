#!/usr/bin/env python3
"""Drive/inspect the emulated original game. usage: emu_ctl.py shot OUT.png | key K [K...] [--wait S]"""
import os, subprocess, sys, time
from PIL import Image
os.environ['DISPLAY'] = ':99'
WIN = None
def win():
    out = subprocess.check_output(['xdotool','search','--name','FreeJ2ME-Plus']).split()
    return out[0].decode()
def shot(path, scale=2):
    subprocess.check_call(['import','-window','root','/tmp/_root.png'])
    import re
    g = subprocess.check_output(['xwininfo','-id',win()]).decode()
    x = int(re.search(r'Absolute upper-left X:\s+(\d+)',g).group(1)); y = int(re.search(r'Absolute upper-left Y:\s+(\d+)',g).group(1))
    im = Image.open('/tmp/_root.png').crop((x,y+25,x+240,y+25+320))
    im.resize((im.width*scale, im.height*scale), Image.NEAREST).save(path)
def key(keys, delay=0.15, hold=0.25):
    w = win()
    subprocess.call(['xdotool','windowactivate',w])
    for k in keys:
        subprocess.check_call(['xdotool','keydown',k]); time.sleep(hold); subprocess.check_call(['xdotool','keyup',k]); time.sleep(delay)
if __name__ == '__main__':
    a = sys.argv[1:]
    if a[0]=='shot': shot(a[1])
    elif a[0]=='key':
        wait = 0.5
        if '--wait' in a: i=a.index('--wait'); wait=float(a[i+1]); a=a[:i]+a[i+2:]
        key(a[1:]); time.sleep(wait)
