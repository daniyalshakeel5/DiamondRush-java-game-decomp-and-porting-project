#!/usr/bin/env python3
"""Make a patched copy of the ORIGINAL jar for reverse-engineering: (1) New Game now starts on world-0 level-0
instead of the level-13 intro; (2) level 0 is replaced by an "ID gallery": every object id sits alone in a walled
niche off a free aisle, so the original engine draws it and we can screenshot it.
usage: make_dev_jar.py IN.jar OUT.jar [id[:layer1param] ...]"""
import re, struct, sys, zipfile, json
src, dst = sys.argv[1], sys.argv[2]
entries = []      # (layer, id, param) - layer 'L0' or 'L2'; param is layer1 for L0 entries, ignored for L2
for a in sys.argv[3:]:
    layer = 'L0'
    if a.upper().startswith('L2:'): layer, a = 'L2', a[3:]
    if ':' in a: k, v = a.split(':'); entries.append((layer, int(k), int(v)))
    else: entries.append((layer, int(a), 0))
if not entries: entries = [('L0', i, 0) for i in list(range(0, 54)) + [74] if i != 79]
z = zipfile.ZipFile(src)
kc = bytearray(z.read('k.class'))
m = list(re.finditer(rb'\x2a\x10\x0d\xb5..\x03\xb3..', bytes(kc))); assert len(m) == 1
kc[m[0].start() + 2] = 0                                   # bipush 13 -> bipush 0  (New Game starts at level 0)
d = z.read('w0.bin'); (n,) = struct.unpack('<I', d[:4]); p = bytearray(d[4:4+n])
pos = 2; recs = []
for i in range(p[1]):
    w, h = struct.unpack('<HH', p[pos:pos+4]); recs.append((pos+4, w, h)); pos += 4 + 3*w*h
off, W, H = recs[0]; assert (W, H) == (26, 21)
WALL = 82
L0 = bytearray([WALL]*(W*H)); L1 = bytearray([0]*(W*H)); L2 = bytearray([255]*(W*H))
AISLES = [5, 13, 19]; ROWS = [3, 7, 11, 15, 17]
for y in AISLES:
    for x in range(1, 24): L0[x + y*W] = 255                # aisles keep a wall margin at both map edges
for y in range(5, 20): L0[1 + y*W] = 255                    # west connector column (x=1)
slots = [(x, y) for y in ROWS for x in range(3, 24, 2)]
placed = {}
for i, (layer, v, pr) in enumerate(entries):
    x, y = slots[i]
    if layer == 'L0': L0[x + y*W] = v; L1[x + y*W] = pr & 255; placed[f'{v}:{pr}'] = (x, y)
    else: L2[x + y*W] = v; L0[x + y*W] = pr if pr else 91; placed[f'L2-{v}'] = (x, y)  # pr reused as an optional L0 wall tile override, default 91 (a plain wall)
L0[1 + 5*W] = 79; L1[1 + 5*W] = 0
p[off:off+W*H] = L0; p[off+W*H:off+2*W*H] = L1; p[off+2*W*H:off+3*W*H] = L2
w0 = struct.pack('<I', n) + bytes(p) + d[4+n:]
zo = zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED)
for it in z.infolist():
    zo.writestr(it, w0 if it.filename == 'w0.bin' else bytes(kc) if it.filename == 'k.class' else z.read(it.filename))
zo.close()
json.dump(placed, open(dst + '.slots.json', 'w'))
print('placed', len(placed), 'entries on', W, 'x', H)
