#!/usr/bin/env python3
"""record_walk.py NAME KEY SECONDS : hold KEY for SECONDS while recording the 176x180 map view at 15fps to /tmp/rec_NAME/"""
import os, re, subprocess, sys, time, shutil
os.environ['DISPLAY'] = ':99'
name, key, secs = sys.argv[1], sys.argv[2], float(sys.argv[3])
w = subprocess.check_output(['xdotool','search','--name','FreeJ2ME-Plus']).split()[0].decode()
g = subprocess.check_output(['xwininfo','-id',w]).decode()
x = int(re.search(r'Absolute upper-left X:\s+(\d+)', g).group(1)); y = int(re.search(r'Absolute upper-left Y:\s+(\d+)', g).group(1))
d = f'/tmp/rec_{name}'; shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
subprocess.call(['xdotool','windowactivate',w]); time.sleep(0.3)
ff = subprocess.Popen(['ffmpeg','-loglevel','error','-y','-f','x11grab','-framerate','15','-video_size','176x180','-i',f':99.0+{x},{y+25}','-t',str(secs+1.2),f'{d}/%04d.png'])
time.sleep(0.4)
subprocess.check_call(['xdotool','keydown',key]); time.sleep(secs); subprocess.check_call(['xdotool','keyup',key])
ff.wait(); print(len(os.listdir(d)), 'frames in', d)
