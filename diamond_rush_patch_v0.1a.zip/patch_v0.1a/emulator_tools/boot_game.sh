#!/bin/bash
# boot_game.sh JAR : start emulator, choose SOUND OFF, go through title -> New Game
cd /home/claude/work/emu; export DISPLAY=:99
pkill java; pkill Xvfb; pkill openbox; sleep 1
rm -rf rms/*; ./run_emu.sh ${1:-dr.jar}; sleep 14
python3 emu_ctl.py key Down --wait 0.5; python3 emu_ctl.py key Return --wait 2
python3 emu_ctl.py key Return --wait 2; python3 emu_ctl.py key Return --wait 10
