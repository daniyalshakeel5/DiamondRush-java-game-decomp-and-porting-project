#!/usr/bin/env python3
"""play_seq.py NAME step... ; step = key:seconds_held  (e.g. Right:0.6) or wait:S or shot ; saves contact sheet /tmp/NAME.png"""
import sys, time, subprocess, os
sys.path.insert(0,'/home/claude/work/emu')
import emu_ctl
from PIL import Image
name=sys.argv[1]; shots=[]
def snap():
    p=f'/tmp/_s{len(shots)}.png'; emu_ctl.shot(p,scale=1); shots.append(Image.open(p).convert('RGB').crop((0,0,176,208)))
w=emu_ctl.win(); subprocess.call(['xdotool','windowactivate',w]); time.sleep(0.3)
for st in sys.argv[2:]:
    if st=='shot': snap(); continue
    k,t=st.split(':'); t=float(t)
    if k=='wait': time.sleep(t); continue
    subprocess.check_call(['xdotool','keydown',k]); time.sleep(t); subprocess.check_call(['xdotool','keyup',k]); time.sleep(0.15)
n=len(shots); cols=min(n,4); rows=(n+cols-1)//cols
sheet=Image.new('RGB',(cols*180,rows*212),'white')
for i,s in enumerate(shots): sheet.paste(s,((i%cols)*180,(i//cols)*212))
sheet=sheet.resize((sheet.width*2//1, sheet.height*2//1), Image.NEAREST) if n<=2 else sheet
sheet.save(f'/tmp/{name}.png'); print('saved',name,n)
