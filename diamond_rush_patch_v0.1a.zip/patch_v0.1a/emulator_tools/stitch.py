#!/usr/bin/env python3
"""stitch.py NAME : stitch /tmp/rec_NAME/*.png (horizontal walk, camera starts clamped at x=0) into a panorama of the
top and bottom strips (player rows skipped). Saves /tmp/pano_NAME.png and /tmp/pano_NAME_top.png, _bot.png (1x)."""
import sys, glob, numpy as np
from PIL import Image
name = sys.argv[1]
fr = [np.asarray(Image.open(f).convert('RGB')).astype(np.int16) for f in sorted(glob.glob(f'/tmp/rec_{name}/*.png'))]
TOP, BOT = (0, 58), (112, 180)
def strip(f): return np.concatenate([f[TOP[0]:TOP[1]], f[BOT[0]:BOT[1]]], 0)
cum, xs = 0, [0]
for a, b in zip(fr, fr[1:]):
    A, B = strip(a), strip(b); best = (1e18, 0)
    for dx in range(0, 40):                      # walking right => the world moves left by dx
        if dx: e = np.abs(A[:, dx:] - B[:, :-dx]).mean()
        else: e = np.abs(A - B).mean()
        if e < best[0]: best = (e, dx)
    cum += best[1]; xs.append(cum)
W = 176 + cum
pano = np.zeros((180, W, 3), np.uint8); seen = np.zeros(W, bool)
for f, x in zip(fr, xs): pano[:, x:x+176] = f.astype(np.uint8)   # later frames win; player rows are ignored downstream
print('frames', len(fr), 'total scroll px', cum, '=', cum/24, 'cells')
im = Image.fromarray(pano); im.save(f'/tmp/pano_{name}.png')
Image.fromarray(pano[TOP[0]:TOP[1]]).save(f'/tmp/pano_{name}_top.png'); Image.fromarray(pano[BOT[0]:BOT[1]]).save(f'/tmp/pano_{name}_bot.png')
