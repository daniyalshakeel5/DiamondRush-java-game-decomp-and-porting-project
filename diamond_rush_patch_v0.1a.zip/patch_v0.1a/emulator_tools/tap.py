import subprocess, time, sys, os
os.environ['DISPLAY']=':99'
w=subprocess.check_output(['xdotool','search','--name','FreeJ2ME-Plus']).split()[0].decode()
subprocess.call(['xdotool','windowactivate',w]); time.sleep(0.2)
key, n, hold, gap = sys.argv[1], int(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
for _ in range(n):
    subprocess.check_call(['xdotool','keydown',key]); time.sleep(hold); subprocess.check_call(['xdotool','keyup',key]); time.sleep(gap)
time.sleep(0.6)
