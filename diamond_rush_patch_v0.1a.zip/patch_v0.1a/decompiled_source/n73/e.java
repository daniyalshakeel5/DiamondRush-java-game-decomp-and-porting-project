/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 */
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class e {
    public static Image[] a;
    public static a a;
    public static a b;
    public static String[] a;
    public static String[] b;
    public static int a;
    public static int b;
    public static int c;
    public boolean a;
    public int d;

    public e() {
        a = new Image[5];
        a = new String[5];
    }

    private static void a(String string) {
        if (string == null) {
            return;
        }
        try {
            h.a.platformRequest(string);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public static void a() {
        int n;
        b = h.a[41];
        e.b.e = 1;
        a = h.a("/tips.f", 0);
        if (b == null) {
            n = 0;
            b = h.a("/lang_IGA.f", 17);
            e.b[7] = h.a(b[7], 170);
            e.b[10] = h.a(b[10], 170);
            e.b[11] = h.a(b[11], 170);
        }
        n = 12;
        int n2 = 0;
        while (n <= 16) {
            e.a[n2] = h.a.getAppProperty(b[n]);
            if (a[n2] != null && (a[n2].compareTo("no") == 0 || a[n2].compareTo("") == 0)) {
                e.a[n2] = null;
            }
            ++n;
            ++n2;
        }
        e.b[3] = b[3] + "\n\u0001\u0001" + b[4] + "\n\u0001\u0000" + b[5];
        e.b[7] = new String("\u0001\u0000" + b[7] + "\n\u0001\u0001" + b[8] + "\n\u0001\u0000" + b[9]);
        try {
            for (n = 0; n < 4; ++n) {
                e.a[n] = Image.createImage((String)("/ad" + (n + 1)));
            }
            h.a[0] = new g(h.a("/ui.f", 0), 0, 0, null);
        }
        catch (Exception exception) {}
        a = 0;
        h.b(3);
    }

    private static void a(int n) {
        block6: {
            int n2;
            block5: {
                block4: {
                    if ((a += n) == 3 && a[a] == null) {
                        a += n;
                    }
                    if (a >= 0) break block4;
                    n2 = 4;
                    break block5;
                }
                if (a != 5) break block6;
                n2 = 0;
            }
            a = n2;
        }
    }

    private static void a(Graphics graphics, int n) {
        int n2;
        int n3;
        int n4;
        String[] stringArray;
        if (a[a] == null) {
            return;
        }
        if (b % 30 < 15) {
            return;
        }
        if (a >= 3) {
            stringArray = b;
            n4 = 10;
        } else {
            stringArray = b;
            n4 = 11;
        }
        String string = stringArray[n4];
        b.a(string);
        int n5 = a.c + 2;
        int n6 = b.a(string);
        if (n != 0) {
            n3 = 320 + n >> 1;
            n2 = (n6 >> 1) + 4;
        } else {
            n3 = 160;
            n2 = n6 >> 1;
        }
        int n7 = n3 - n2;
        graphics.setClip(0, 0, 240, 320);
        graphics.setColor(0xFF0000);
        graphics.fillRect(120 - (n5 >> 1) - 4, n7 - 4, n5 + 8, n6 + 8);
        b.b(graphics, string, 120, n7, 1);
    }

    private static void a(Graphics graphics, int n, int n2) {
        int n3 = (n & 0xFF0000) >> 16;
        int n4 = (n & 0xFF00) >> 8;
        int n5 = n & 0xFF;
        int n6 = (n2 & 0xFF0000) >> 16;
        int n7 = (n2 & 0xFF00) >> 8;
        int n8 = n2 & 0xFF;
        int n9 = (n3 - n6) / 16;
        int n10 = (n4 - n7) / 16;
        int n11 = (n5 - n8) / 16;
        int n12 = n3;
        int n13 = n4;
        int n14 = n5;
        graphics.setClip(0, 0, 240, 320);
        for (int i = 0; i < 16; ++i) {
            graphics.setColor(n12 << 16 | n13 << 8 | n14);
            graphics.fillRect(0, 160 + 160 * i / 16, 240, 21);
            graphics.fillRect(0, 160 - 160 * (i + 1) / 16, 240, 21);
            n12 -= n9;
            n13 -= n10;
            n14 -= n11;
        }
    }

    public final void a(Graphics graphics) {
        int n = 0;
        switch (a) {
            case 4: {
                e.a(graphics, -16776961, -16777216);
                b.b(graphics, "\n\u0001\u0001" + b[6], 120, 35, 17);
                b.b(graphics, b[7], 120, 152, 3);
                b.a(b[7]);
                int n2 = 160 + (a.d >> 1) + 4;
                break;
            }
            case 3: {
                e.a(graphics, -10288963, -14614471);
                graphics.drawImage(a[a], 120, 15, 17);
                b.b(graphics, b[3], 120, 160, 3);
                b.a(b[3]);
                int n2 = 160 + (a.d >> 1) + 4;
                break;
            }
            default: {
                e.a(graphics, -16776961, -16777216);
                graphics.drawImage(a[a], 120, 240, 33);
                b.b(graphics, b[a], 120, 252, 17);
                int n2 = n = 0;
            }
        }
        if (a != 3) {
            g g2 = h.a[0];
            g2.a.a(graphics, 11, 120, 15, 0, 0, 0);
        }
        h.a.a();
        if (a[a] != null) {
            h.a.b();
        }
        e.a(graphics, n);
        if (h.a(16388)) {
            e.a(-1);
        } else if (h.a(65544)) {
            e.a(1);
        } else if (h.a(32944)) {
            e.a(a[a]);
        } else if (h.a(64)) {
            h.a.a(0);
            c = 2;
            h.W = 0;
        }
        a.a(graphics, h.a(16388) ? 2 : 0, b % a.a(0), 20 + this.d, 160, 0, 0, 0);
        a.a(graphics, h.a(65544) ? 3 : 1, b % a.a(1), 220 - this.d, 160, 0, 0, 0);
        this.d += this.a ? -1 : 1;
        if (this.d > 3 || this.d < 1) {
            this.a = !this.a;
        }
        h.W = 0;
    }

    public static void b() {
        int n = 0;
        int n2 = a.length;
        for (n = 0; n < n2; ++n) {
            e.a[n] = null;
        }
        a = null;
        n2 = a.length;
        for (n = 0; n < n2; ++n) {
            e.a[n] = null;
        }
        a = null;
        n2 = b.length;
        for (n = 0; n < n2; ++n) {
            e.b[n] = null;
        }
        b = null;
        b = null;
        a = null;
        c = 0;
        System.gc();
    }
}
