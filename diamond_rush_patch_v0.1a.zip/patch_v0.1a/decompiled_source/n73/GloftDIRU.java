/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.midlet.MIDlet
 *  javax.microedition.midlet.MIDletStateChangeException
 */
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class GloftDIRU
extends MIDlet {
    public static byte[] a = null;
    public h a;
    public Display a;
    public static int[] a;

    public GloftDIRU() {
        a = new int[102400];
        a = this.getAppProperty("MIDlet-Version").getBytes();
        this.a = new h(this);
    }

    public final void startApp() throws MIDletStateChangeException {
        if (this.a == null) {
            this.a = Display.getDisplay((MIDlet)this);
        }
        this.a.setCurrent((Displayable)this.a);
        this.a.f();
    }

    public final void pauseApp() {
        this.a.e();
        this.notifyPaused();
    }

    public final void destroyApp(boolean bl) throws MIDletStateChangeException {
        this.notifyDestroyed();
    }

    public final void a() {
        h.d();
        this.a.g();
        this.b();
        try {
            this.destroyApp(true);
            return;
        }
        catch (MIDletStateChangeException mIDletStateChangeException) {
            return;
        }
    }

    private void b() {
        this.a = null;
        this.a = null;
        System.gc();
    }
}
