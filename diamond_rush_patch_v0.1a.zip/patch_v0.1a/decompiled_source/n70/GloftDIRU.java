/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.midlet.MIDlet
 *  javax.microedition.midlet.MIDletStateChangeException
 */
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class GloftDIRU
extends MIDlet {
    public static byte[] a = null;
    public k a;
    public Display a;

    public GloftDIRU() {
        a = this.getAppProperty("MIDlet-Version").getBytes();
        this.a = new k(this);
    }

    public final void startApp() throws MIDletStateChangeException {
        if (this.a == null) {
            this.a = Display.getDisplay((MIDlet)this);
        }
        this.a.setCurrent((Displayable)this.a);
        this.a.bv();
    }

    public final void pauseApp() {
        this.a.bu();
        this.notifyPaused();
    }

    public final void destroyApp(boolean bl) throws MIDletStateChangeException {
        if (Display.getDisplay((MIDlet)this) != null) {
            Display.getDisplay((MIDlet)this).setCurrent(null);
        }
        this.notifyDestroyed();
    }

    public final void a() {
        this.a.bs();
        this.a.a.c();
        this.b();
        try {
            this.destroyApp(true);
            return;
        }
        catch (MIDletStateChangeException mIDletStateChangeException) {
            return;
        }
    }

    public final void b() {
        this.a = null;
        this.a = null;
        System.gc();
    }
}
