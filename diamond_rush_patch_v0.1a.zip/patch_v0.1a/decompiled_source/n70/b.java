/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 */
import javax.microedition.lcdui.Graphics;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class b {
    public static int[] a = new int[4096];
    public static boolean a = false;
    public static boolean b = false;
    public static boolean c = false;
    public static boolean d = false;
    public static int a = 16;
    public static int b = 16;
    public static int c = 1;
    public static int d = 2;
    public static int e = 256;
    public static int f = 65536;
    public static int g = 0x1000000;
    public static int h = 0x2000000;
    public static int i = c | e | f | g;
    public static short a = (short)512;
    public static short b = (short)1024;
    public static short c = (short)5632;
    public static short d = (short)22018;
    public static short e = (short)10225;
    public static short f = (short)22258;
    public static byte a = 1;
    public static byte b = (byte)2;
    public static byte c = (byte)16;
    public static int j = 192;
    public static int k = 2;
    public static byte d = (byte)32;
    public byte[] a;
    public byte[] b;
    public short[] a;
    public byte[] c;
    public byte[] d;
    public byte[] e;
    public short[] b;
    public byte[] f;
    public int[][] a;
    private int s;
    public int[][] b;
    public int l;
    public int m;
    public boolean e;
    public short g;
    public byte[] g;
    public short[] c;
    public f[][] a;
    public static int n;
    public static int o;
    public static byte[] h;
    public int p = 0;
    public static int q;
    public static int r;

    public final void a(byte[] byArray, int n) {
        try {
            int n2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            int n9;
            short s;
            System.gc();
            ++n;
            ++n;
            boolean bl = false;
            ++n;
            ++n;
            ++n;
            boolean bl2 = false;
            int n10 = ++n;
            int n11 = ++n;
            ++n;
            short s2 = (short)((byArray[n10] & 0xFF) + ((byArray[n11] & 0xFF) << 8));
            if (s2 > 0) {
                this.a = new byte[s2 << 1];
                System.arraycopy(byArray, n, this.a, 0, this.a.length);
                n += this.a.length;
            }
            if ((s = (short)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8))) > 0) {
                this.d = new byte[s << 2];
                System.arraycopy(byArray, n, this.d, 0, this.d.length);
                n += this.d.length;
            }
            if ((n9 = (int)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8))) > 0) {
                this.b = new byte[n9];
                this.a = new short[n9];
                for (n8 = 0; n8 < n9; ++n8) {
                    this.b[n8] = byArray[n++];
                    int n12 = ++n;
                    int n13 = ++n;
                    ++n;
                    this.a[n8] = (short)((byArray[n12] & 0xFF) + ((byArray[n13] & 0xFF) << 8));
                }
                n8 = n9 << 2;
                this.c = new byte[n8];
                for (n7 = 0; n7 < n8; ++n7) {
                    this.c[n7] = byArray[n++];
                }
            }
            short s3 = (short)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8));
            n8 = s3;
            if (s3 > 0) {
                this.f = new byte[n8 * 5];
                System.arraycopy(byArray, n, this.f, 0, this.f.length);
                n += this.f.length;
            }
            short s4 = (short)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8));
            n7 = s4;
            if (s4 > 0) {
                this.e = new byte[n7];
                this.b = new short[n7];
                for (n6 = 0; n6 < n7; ++n6) {
                    this.e[n6] = byArray[n++];
                    int n14 = ++n;
                    int n15 = ++n;
                    ++n;
                    this.b[n6] = (short)((byArray[n14] & 0xFF) + ((byArray[n15] & 0xFF) << 8));
                }
            }
            if (s2 <= 0) {
                System.gc();
                return;
            }
            n6 = (short)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8));
            this.l = byArray[n++] & 0xFF;
            int n16 = byArray[n++] & 0xFF;
            this.b = new int[a][];
            block11: for (n5 = 0; n5 < this.l; ++n5) {
                this.b[n5] = new int[n16];
                switch (n6) {
                    case -30584: {
                        for (n4 = 0; n4 < n16; ++n4) {
                            n3 = byArray[n++] & 0xFF;
                            n3 += (byArray[n++] & 0xFF) << 8;
                            n3 += (byArray[n++] & 0xFF) << 16;
                            if (((n3 += (byArray[n++] & 0xFF) << 24) & 0xFF000000) != -16777216) {
                                this.e = true;
                            }
                            this.b[n5][n4] = n3;
                        }
                        continue block11;
                    }
                    case 17476: {
                        for (n4 = 0; n4 < n16; ++n4) {
                            n3 = byArray[n++] & 0xFF;
                            if (((n3 += (byArray[n++] & 0xFF) << 8) & 0xF000) != 61440) {
                                this.e = true;
                            }
                            this.b[n5][n4] = (n3 & 0xF000) << 16 | (n3 & 0xF000) << 12 | (n3 & 0xF00) << 12 | (n3 & 0xF00) << 8 | (n3 & 0xF0) << 8 | (n3 & 0xF0) << 4 | (n3 & 0xF) << 4 | n3 & 0xF;
                        }
                        continue block11;
                    }
                    case 21781: {
                        for (n4 = 0; n4 < n16; ++n4) {
                            n3 = byArray[n++] & 0xFF;
                            int n17 = n++;
                            n2 = -16777216;
                            if (((n3 += (byArray[n17] & 0xFF) << 8) & 0x8000) != 32768) {
                                n2 = 0;
                                this.e = true;
                            }
                            this.b[n5][n4] = n2 | (n3 & 0x7C00) << 9 | (n3 & 0x3E0) << 6 | (n3 & 0x1F) << 3;
                        }
                        continue block11;
                    }
                    case 25861: {
                        for (n4 = 0; n4 < n16; ++n4) {
                            n3 = byArray[n++] & 0xFF;
                            int n18 = n++;
                            n2 = -16777216;
                            if ((n3 += (byArray[n18] & 0xFF) << 8) == 63519) {
                                n2 = 0;
                                this.e = true;
                            }
                            this.b[n5][n4] = n2 | (n3 & 0xF800) << 8 | (n3 & 0x7E0) << 5 | (n3 & 0x1F) << 3;
                        }
                        continue block11;
                    }
                }
            }
            this.g = (short)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8));
            if (s2 > 0) {
                this.c = new short[s2];
                n5 = 0;
                n4 = n;
                for (n3 = 0; n3 < s2; ++n3) {
                    n2 = (short)((byArray[n4++] & 0xFF) + ((byArray[n4++] & 0xFF) << 8));
                    this.c[n3] = (short)n5;
                    n4 += n2;
                    n5 += n2;
                }
                this.g = new byte[n5];
                for (n3 = 0; n3 < s2; ++n3) {
                    n2 = (short)((byArray[n++] & 0xFF) + ((byArray[n++] & 0xFF) << 8));
                    System.arraycopy(byArray, n, this.g, this.c[n3] & 0xFFFF, n2);
                    n += n2;
                }
            }
            if (a) {
                this.a = new int[b][];
                this.s = -1;
            }
            System.gc();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            exception2.printStackTrace();
            return;
        }
    }

    public final void a(int n, int n2, int n3, int n4) {
        if (this.a == null) {
            return;
        }
        if (n3 == -1) {
            n3 = (this.a.length >> 1) - 1;
        }
        if (this.a == null) {
            this.a = new f[this.l][];
        }
        if (this.a[n] == null) {
            this.a[n] = new f[this.a.length >> 1];
        }
        if (n4 >= 0) {
            for (int i = n2; i <= n3; ++i) {
                this.a[n][i] = this.a[n4][i];
            }
        } else {
            int n5 = this.m;
            this.m = n;
            System.gc();
            for (int i = n2; i <= n3; ++i) {
                int[] nArray;
                int n6 = i << 1;
                int n7 = this.a[n6] & 0xFF;
                int n8 = this.a[n6 + 1] & 0xFF;
                if (n7 <= 0 || n8 <= 0 || (nArray = this.a(i, 0)) == null) continue;
                boolean bl = false;
                int n9 = n7 * n8;
                for (int j = 0; j < n9; ++j) {
                    if ((nArray[j] & 0xFF000000) == -16777216) continue;
                    bl = true;
                    break;
                }
                this.a[n][i] = f.a(nArray, n7, n8, bl);
            }
            System.gc();
            this.m = n5;
        }
        System.gc();
    }

    public final void a(int n) {
        if (this.a == null) {
            return;
        }
        if (this.a == null) {
            return;
        }
        if (this.a[n] == null) {
            return;
        }
        for (int i = 0; i < this.a[n].length; ++i) {
            this.a[n][i] = null;
        }
        this.a[n] = null;
        --this.l;
    }

    public final String toString() {
        new String();
        String string = null;
        int n = 0;
        for (int i = 0; i < this.a.length / 2; ++i) {
            n += 2 * (this.a[2 * i] & 0xFF) * (this.a[2 * i + 1] & 0xFF);
        }
        string = "raw/full: " + this.g.length + "/" + n;
        return string;
    }

    public final int a(int n, int n2) {
        return this.f[(this.b[n] + n2) * 5 + 1] & 0xFF;
    }

    public final int a(int n) {
        return this.e[n] & 0xFF;
    }

    public final int b(int n) {
        return this.b[n] & 0xFF;
    }

    public final int a(String string) {
        int n = 1;
        int n2 = string.length();
        int n3 = string.indexOf(10);
        while (n3 != -1) {
            ++n;
            n3 = n3 < n2 - 1 ? string.indexOf(10, n3 + 1) : -1;
        }
        return this.p * (n - 1) + this.a[1] * n;
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = (this.b[n] + n2) * 5;
        int n9 = this.f[n8] & 0xFF;
        if (d) {
            n9 |= (this.f[n8 + 4] & j) << k;
        }
        if ((n5 & d) != 0) {
            n6 = (n5 & a) != 0 ? (n6 += this.f[n8 + 2]) : (n6 -= this.f[n8 + 2]);
            n7 = (n5 & b) != 0 ? (n7 += this.f[n8 + 3]) : (n7 -= this.f[n8 + 3]);
        }
        this.a(graphics, n9, n3 - n6, n4 - n7, n5 ^ this.f[n8 + 4] & 0xF, n6, n7);
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6) {
        int n7 = this.b[n] & 0xFF;
        for (int i = 0; i < n7; ++i) {
            this.b(graphics, n, i, n2, n3, n4, n5, n6);
        }
    }

    public final void b(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = this.a[n] + n2 << 2;
        int n9 = this.d[n8 + 3] & 0xFF;
        int n10 = this.d[n8] & 0xFF;
        if (c) {
            n10 |= (n9 & j) << k;
        }
        n3 = (n5 & a) != 0 ? (n3 -= this.d[n8 + 1]) : (n3 += this.d[n8 + 1]);
        n4 = (n5 & b) != 0 ? (n4 -= this.d[n8 + 2]) : (n4 += this.d[n8 + 2]);
        if (b && (n9 & c) != 0) {
            this.a(graphics, n10, n3, n4, n5 ^ n9 & 0xF, n6, n7);
            return;
        }
        if ((n5 & a) != 0) {
            n3 -= this.a[n10 << 1] & 0xFF;
        }
        if ((n5 & b) != 0) {
            n4 -= this.a[(n10 << 1) + 1] & 0xFF;
        }
        this.a(graphics, n10, n3, n4, n5 ^ n9 & 0xF);
    }

    public final synchronized void a(Graphics graphics, int n, int n2, int n3, int n4) {
        if (a && this.s >= 0) {
            n = this.a[this.s][n];
        }
        int n5 = n << 1;
        int n6 = this.a[n5] & 0xFF;
        int n7 = this.a[n5 + 1] & 0xFF;
        if (n6 <= 0 || n7 <= 0) {
            return;
        }
        f f2 = null;
        f2 = this.a != null && this.a[this.m] != null ? this.a[this.m][n] : f.a(this.a(n, 0), n6, n7, this.e);
        if (f2 == null) {
            return;
        }
        if ((n4 & (a | b)) != 0) {
            f2.a(n4, false);
        }
        f2.a(graphics, n2, n3, 0, n4, this.e);
    }

    public final int[] a(int n, int n2) {
        int[] nArray;
        block14: {
            int n3;
            int n4;
            int n5;
            byte[] byArray;
            int[] nArray2;
            block18: {
                block17: {
                    block16: {
                        block15: {
                            block13: {
                                if (this.g == null || this.c == null) {
                                    return null;
                                }
                                int n6 = n << 1;
                                int n7 = this.a[n6] & 0xFF;
                                int n8 = this.a[n6 + 1] & 0xFF;
                                nArray = a;
                                nArray2 = this.b[this.m];
                                if (nArray2 == null) {
                                    return null;
                                }
                                byArray = this.g;
                                n5 = this.c[n] & 0xFFFF;
                                n4 = 0;
                                n3 = n7 * n8;
                                if (this.g != e) break block13;
                                while (n4 < n3) {
                                    int n9;
                                    if ((n9 = byArray[n5++] & 0xFF) > 127) {
                                        int n10 = byArray[n5++] & 0xFF;
                                        int n11 = nArray2[n10];
                                        n9 -= 128;
                                        while (n9-- > 0) {
                                            nArray[n4++] = n11;
                                        }
                                        continue;
                                    }
                                    nArray[n4++] = nArray2[n9];
                                }
                                break block14;
                            }
                            if (this.g != c) break block15;
                            while (n4 < n3) {
                                nArray[n4++] = nArray2[byArray[n5] >> 4 & 0xF];
                                nArray[n4++] = nArray2[byArray[n5] & 0xF];
                                ++n5;
                            }
                            break block14;
                        }
                        if (this.g != b) break block16;
                        while (n4 < n3) {
                            nArray[n4++] = nArray2[byArray[n5] >> 6 & 3];
                            nArray[n4++] = nArray2[byArray[n5] >> 4 & 3];
                            nArray[n4++] = nArray2[byArray[n5] >> 2 & 3];
                            nArray[n4++] = nArray2[byArray[n5] & 3];
                            ++n5;
                        }
                        break block14;
                    }
                    if (this.g != a) break block17;
                    while (n4 < n3) {
                        nArray[n4++] = nArray2[byArray[n5] >> 7 & 1];
                        nArray[n4++] = nArray2[byArray[n5] >> 6 & 1];
                        nArray[n4++] = nArray2[byArray[n5] >> 5 & 1];
                        nArray[n4++] = nArray2[byArray[n5] >> 4 & 1];
                        nArray[n4++] = nArray2[byArray[n5] >> 3 & 1];
                        nArray[n4++] = nArray2[byArray[n5] >> 2 & 1];
                        nArray[n4++] = nArray2[byArray[n5] >> 1 & 1];
                        nArray[n4++] = nArray2[byArray[n5] & 1];
                        ++n5;
                    }
                    break block14;
                }
                if (this.g != d) break block18;
                while (n4 < n3) {
                    nArray[n4++] = nArray2[byArray[n5++] & 0xFF];
                }
                break block14;
            }
            if (this.g != f) break block14;
            while (n4 < n3) {
                int n12;
                if ((n12 = byArray[n5++] & 0xFF) > 127) {
                    n12 -= 128;
                    while (n12-- > 0) {
                        nArray[n4++] = nArray2[byArray[n5++] & 0xFF];
                    }
                    continue;
                }
                int n13 = nArray2[byArray[n5++] & 0xFF];
                while (n12-- > 0) {
                    nArray[n4++] = n13;
                }
            }
        }
        return nArray;
    }

    public final void a(String string) {
        n = 0;
        o = this.a[1] & 0xFF;
        int n = 0;
        int n2 = q >= 0 ? q : 0;
        int n3 = r >= 0 ? r : string.length();
        for (int i = n2; i < n3; ++i) {
            int n4;
            int n5 = string.charAt(i);
            if (n5 > 32) {
                n5 = h[n5] & 0xFF;
            } else {
                if (n5 == 32) {
                    n += (this.a[0] & 0xFF) + this.d[1];
                    continue;
                }
                if (n5 == 10) {
                    if (n > b.n) {
                        b.n = n;
                    }
                    n = 0;
                    o += this.p + (this.a[1] & 0xFF);
                    continue;
                }
                if (n5 == 1) {
                    ++i;
                    continue;
                }
                if (n5 != 2) continue;
                n5 = string.charAt(++i);
            }
            if (n5 >= this.b(0)) {
                n4 = n5 - this.b(0);
                n += (this.c[(n4 << 2) + 2] & 0xFF) - (this.c[n4 << 2] & 0xFF) + this.d[1];
                continue;
            }
            n4 = (this.d[n5 << 2] & 0xFF) << 1;
            n += (this.a[n4] & 0xFF) - this.d[(n5 << 2) + 1] + this.d[1];
        }
        if (n > b.n) {
            b.n = n;
        }
        if (b.n > 0) {
            b.n -= this.d[1];
        }
    }

    public final void a(Graphics graphics, String string, int n, int n2, int n3) {
        n2 -= this.d[2];
        if ((n3 & 0x2B) != 0) {
            this.a(string);
            if ((n3 & 8) != 0) {
                n -= b.n;
            } else if ((n3 & 1) != 0) {
                n -= b.n >> 1;
            }
            if ((n3 & 0x20) != 0) {
                n2 -= o;
            } else if ((n3 & 2) != 0) {
                n2 -= o >> 1;
            }
        }
        int n4 = n;
        int n5 = n2;
        int n6 = this.m;
        int n7 = q >= 0 ? q : 0;
        int n8 = r >= 0 ? r : string.length();
        for (int i = n7; i < n8; ++i) {
            int n9;
            int n10 = string.charAt(i);
            if (n10 > 32) {
                n10 = h[n10] & 0xFF;
            } else {
                if (n10 == 32) {
                    n4 += (this.a[0] & 0xFF) + this.d[1];
                    continue;
                }
                if (n10 == 10) {
                    n4 = n;
                    n5 += this.p + (this.a[1] & 0xFF);
                    continue;
                }
                if (n10 == 1) {
                    this.m = string.charAt(++i);
                    continue;
                }
                if (n10 != 2) continue;
                n10 = string.charAt(++i);
            }
            if (n10 >= this.b(0)) {
                n9 = n10 - this.b(0);
                this.a(graphics, n9, n4, n5, 0, 0, 0);
                n4 += (this.c[(n9 << 2) + 2] & 0xFF) - (this.c[n9 << 2] & 0xFF) + this.d[1];
                continue;
            }
            n9 = (this.d[n10 << 2] & 0xFF) << 1;
            this.b(graphics, 0, n10, n4, n5, 0, 0, 0);
            n4 += (this.a[n9] & 0xFF) - this.d[(n10 << 2) + 1] + this.d[1];
        }
        this.m = n6;
    }

    public final void b(Graphics graphics, String string, int n, int n2, int n3) {
        int n4;
        int n5 = 0;
        int n6 = string.length();
        int[] nArray = new int[100];
        for (n4 = 0; n4 < n6; ++n4) {
            if (string.charAt(n4) != '\n') continue;
            nArray[n5++] = n4;
        }
        nArray[n5++] = n6;
        n4 = this.p + (this.a[1] & 0xFF);
        if ((n3 & 0x20) != 0) {
            n2 -= n4 * (n5 - 1);
        } else if ((n3 & 2) != 0) {
            n2 -= n4 * (n5 - 1) >> 1;
        }
        for (int i = 0; i < n5; ++i) {
            q = i > 0 ? nArray[i - 1] + 1 : 0;
            r = nArray[i];
            this.a(graphics, string, n, n2 + i * n4, n3);
        }
        q = -1;
        r = -1;
    }

    public final void a(boolean bl) {
        int n;
        this.a = null;
        this.b = null;
        this.a = null;
        this.c = null;
        this.d = null;
        this.e = null;
        this.b = null;
        this.f = null;
        if (this.a != null) {
            for (n = 0; n < this.a.length; ++n) {
                this.a[n] = null;
            }
            this.a = null;
        }
        if (this.b != null) {
            for (n = 0; n < this.b.length; ++n) {
                this.b[n] = null;
            }
            this.b = null;
        }
        this.g = null;
        this.c = null;
        if (bl && this.a != null) {
            for (n = 0; n < this.a.length; ++n) {
                if (this.a[n] == null) continue;
                for (int i = 0; i < this.a[n].length; ++i) {
                    this.a[n][i] = null;
                }
            }
            this.a = null;
        }
    }

    static {
        q = -1;
        r = -1;
    }
}
