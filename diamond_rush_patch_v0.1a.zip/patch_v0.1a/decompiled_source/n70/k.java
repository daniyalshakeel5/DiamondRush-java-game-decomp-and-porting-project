/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nokia.mid.ui.FullCanvas
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 *  javax.microedition.rms.RecordStore
 */
import com.nokia.mid.ui.FullCanvas;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Hashtable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordStore;

/*
 * Duplicate member names - consider using --renamedupmembers true
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class k
extends FullCanvas
implements Runnable {
    public static boolean a;
    public static k a;
    public int a;
    public int b;
    public boolean b;
    public boolean c;
    public int c;
    public int d;
    public String a;
    public boolean d;
    public int e;
    public int f;
    public int g;
    public int h;
    public int i;
    public String b;
    public String c;
    public int j;
    public boolean e;
    public boolean f;
    public byte a;
    public int k;
    public int l;
    public int m;
    public int n;
    public int o;
    public int p;
    public int q;
    public static boolean[] a;
    public int r;
    public static boolean[] b;
    public boolean g;
    public int s;
    public int t;
    public int u;
    public int v;
    public int w;
    public int x;
    public int y;
    public int z;
    public boolean h;
    public int A;
    public int B;
    public int C;
    public int D;
    public int E = 0;
    public int F;
    public int G;
    public int H;
    public boolean i;
    public boolean j;
    public int I;
    public int J;
    public int K;
    public int L;
    public int M;
    public int N;
    public int O;
    public byte b;
    public byte c;
    public byte d;
    public byte e;
    public byte f;
    public byte g;
    public boolean k;
    public int P;
    public int Q;
    public int R;
    public static byte[] a;
    public static byte[] b;
    public static byte[] c;
    public int S;
    public int T;
    public byte h;
    public static boolean l;
    public int U;
    public int V;
    public static int W;
    public boolean m;
    public boolean n;
    public int X;
    public int Y;
    public static byte[] d;
    public byte i;
    public int Z;
    public int aa;
    public int ab;
    public int ac;
    public boolean o;
    public int ad;
    public int ae;
    public int af;
    public int ag;
    public int ah;
    public int ai;
    public boolean p;
    public boolean q;
    public boolean r;
    public boolean s;
    public int aj;
    public int ak;
    public static byte[] e;
    public int al;
    public int am;
    public int an;
    public byte j;
    public byte k;
    public int ao;
    public int ap;
    public int aq;
    public int ar;
    public int as;
    public int at;
    public int au;
    public int av;
    public int aw;
    public int ax;
    public int ay;
    public int az;
    public int aA;
    public int aB;
    public int aC;
    public int aD;
    public int aE;
    public int aF;
    public int aG;
    public int aH;
    public int aI;
    public int aJ;
    public int aK;
    public int aL;
    public int aM;
    public int aN;
    public static byte l;
    public int aO;
    public boolean t;
    public static int aP;
    public static int aQ;
    public long a;
    public boolean u;
    public int aR;
    public int aS;
    public int aT;
    public int aU;
    public int aV;
    public boolean v;
    public int aW;
    public int aX;
    public boolean w;
    public byte m;
    public int aY;
    public long b = 1;
    public int aZ;
    public int ba = 0;
    public int bb;
    public int bc = 0;
    public int bd;
    public int be;
    public int bf;
    public int bg;
    public int bh;
    public byte n;
    public int bi;
    public int bj;
    public int bk;
    public int bl;
    public int bm;
    public int bn;
    public int bo = -1;
    public boolean x;
    public int bp;
    public String d;
    public boolean y;
    public int bq;
    public int br;
    public int bs;
    public int bt;
    public int bu;
    public int bv;
    public int bw;
    public int bx;
    public int by;
    public int bz;
    public int bA;
    public int bB;
    public int bC;
    public int bD;
    public int bE;
    public boolean z = 0;
    public int bF = 0;
    public int bG;
    public int bH;
    public int bI;
    public int bJ;
    public int bK;
    public int bL;
    public int bM;
    public int bN;
    public int bO;
    public int bP;
    public int bQ;
    public int bR;
    public int bS;
    public int bT;
    public int bU;
    public int bV;
    public int bW;
    public int bX;
    public int bY = 0;
    public int bZ = 0;
    public int ca = 0;
    public int cb = 0;
    public int cc = 0;
    public int cd = 0;
    public boolean A = 0;
    public int ce;
    public int cf;
    public a a;
    public byte o;
    public byte p;
    public boolean B = false;
    public int cg;
    public int ch;
    public int ci;
    public int cj;
    public static Graphics a;
    public static f[][] a;
    public static f[][] b;
    public static b[] a;
    public static b a;
    public static byte[] f;
    public static i[] a;
    public static b b;
    public static byte[] g;
    public static byte[] h;
    public long c = 1;
    public long d;
    public long e;
    public boolean C = false;
    public static byte[] i;
    public static byte[] j;
    public static int[][] a;
    public static int[][] b;
    public static byte[][] a;
    public static byte[][] b;
    public static byte[][] c;
    public static byte[] k;
    public boolean D = 0;
    public int ck;
    public int cl;
    public int cm;
    public int cn;
    public static byte[] l;
    public static byte[] m;
    public static int co;
    public static int cp;
    public static byte[] n;
    public static int[][] c;
    public static int[][] d;
    public static byte[][] d;
    public static byte[][] e;
    public static byte[] o;
    public final j a;
    public d a;
    public static d[] a;
    public static byte[] p;
    public final Thread a;
    public static GloftDIRU a;
    public int cq = -1;
    public int cr = -1;
    public int cs;
    public int ct;
    public int cu;
    public static b c;
    public int cv;
    public byte q;
    public static boolean E;
    public long f;
    public long g;
    public long h = false;
    public boolean F = false;
    public boolean G = false;
    public boolean H = false;
    public boolean I = false;
    public boolean J = false;
    public boolean K = false;
    public boolean L = false;
    public boolean M = false;
    public boolean N = false;
    public int cw = -1;
    public int cx;
    public int cy;
    public boolean O = 0;
    public boolean P = false;
    public int cz;
    public int cA;
    public boolean Q = false;
    public boolean R = false;
    public int cB;
    public static Image a;
    public static Graphics b;
    public static int cC;
    public static int cD;
    public static int cE;
    public static int cF;
    public static int cG;
    public static int cH;
    public int cI;
    public int cJ;
    public int cK;
    public int cL;
    public static f a;
    public static int cM;
    public static int cN;
    public static int cO;
    public int cP = -1;
    public int cQ = -1;
    public int cR = -1;
    public int cS = -1;
    public int cT = -1;
    public int cU = -1;
    public boolean S = true;
    public long i = 0;
    public int cV;
    public int cW;
    public int cX;
    public int cY = 2;
    public int cZ = 0;
    public int da;
    public int db;
    public int dc = 3;
    public int dd = -1;
    public long j = 0L;
    public int de = -1;
    public static Image b;
    public static Graphics c;
    public static boolean T;
    public static boolean U;
    public long k = 0L;
    public boolean V = 0;
    public boolean W;
    public boolean X;
    public boolean Y;
    public boolean Z = false;
    public static int df;
    public static int dg;
    public static int dh;
    public byte r = false;
    public byte s = false;
    public boolean aa;
    public static byte[] q;
    public static byte[] r;
    public long l = 0;
    public boolean ab;
    public int di;
    public boolean ac;
    public long m = true;
    public long n = 0;
    public boolean ad;
    public long o = 0;
    public boolean ae;
    public boolean af;
    public boolean ag;
    public boolean ah;
    public String e = false;
    public int dj;
    public int dk;
    public int dl;
    public int dm;
    public static boolean ai;
    public static int dn;
    public static int do;
    public static int dp;
    public static int dq;
    public static f[] a;
    public g a;
    public boolean aj;
    public boolean ak;
    public int dr;
    public int ds;
    public int dt;
    public byte t = false;
    public int du;
    public int dv;
    public int dw;
    public int dx;
    public int dy;
    public byte u = 10;
    public int dz;
    public int dA;
    public byte v = 0;
    public byte w = 0;
    public int dB;
    public int dC;
    public int dD;
    public byte x = 0;
    public int dE;
    public int dF;
    public int dG;
    public byte y = 0;
    public int dH;
    public int dI;
    public static b d;
    public static int[][] e;
    public static long[] a;
    public static long[] b;
    public static int[][] f;
    public static long[] c;
    public static long[] d;
    public static boolean al;
    public int dJ;
    public int dK;
    public static long[][] a;
    public static StringBuffer a;
    public static StringBuffer b;
    public static StringBuffer c;
    public static Image c;
    public static Graphics d;
    public int dL;
    public int dM;
    public int dN;
    public int dO;
    public int dP;
    public int dQ;
    public int dR;
    public int dS;
    public int dT;
    public int dU;
    public int dV;
    public boolean am;
    public boolean an;
    public int dW;
    public int dX;
    public int dY;
    public int dZ;
    public static int ea;
    public int eb;
    public int ec;
    public int ed;
    public int ee;
    public int ef;
    public int eg;
    public int eh;
    public int ei;
    public boolean ao;
    public boolean ap;
    public boolean aq;
    public int[] a = null;
    public int ej;
    public int ek;
    public int el;
    public int em;
    public int en;
    public boolean ar;
    public boolean as;
    public boolean at;
    public long p = false;
    public int eo;
    public String f = true;
    public StringBuffer d = true;
    public boolean au;
    public boolean av;
    public int ep;
    public int eq;
    public static final short[][] a;
    public static final int[] b;
    public static final int[][] g;
    public static String[] a;
    public static byte[] s;
    public static final String[] b;
    public static int er;
    public long q = 0;
    public String g = 0;
    public int es;
    public int et;
    public int eu;
    public int ev;
    public static int[] c;
    public static int[] d;
    public static int[] e;
    public static int[] f;
    public static int[] g;
    public static int[] h;

    public k(GloftDIRU gloftDIRU) {
        this.h = this.f;
        this.i = this.g;
        this.d = (byte)3;
        this.e = (byte)3;
        this.f = (byte)2;
        int[] nArray = new int[]{0, 0, 0, 0, 0};
        this.aa = false;
        this.l = 0L;
        this.di = 0;
        this.m = 0L;
        this.n = 0L;
        this.ad = false;
        this.ah = false;
        this.dj = 0;
        this.aj = false;
        this.ak = true;
        this.dr = -1;
        this.dA = -1;
        this.v = (byte)3;
        this.dL = 100;
        this.am = true;
        this.ao = true;
        this.ap = true;
        this.aq = true;
        this.el = 2;
        this.en = 2;
        this.as = true;
        this.at = true;
        this.p = 0L;
        this.eo = -1;
        this.d = new StringBuffer();
        this.au = true;
        this.av = true;
        this.q = System.currentTimeMillis();
        a = this;
        this.aA = -1;
        this.aC = -1;
        this.aE = -1;
        a = new i[6];
        a = new b[61];
        this.cc();
        a = new f[33][];
        b = new f[2][];
        a = gloftDIRU;
        this.a = new j();
        l = true;
        this.v();
        this.a = new Thread(this);
        this.a.start();
    }

    public final void a(int n, int n2, int n3) {
        this.aC = -1;
        this.aF = -1;
        this.aE = -1;
        i i2 = a[(this.aU & 0x4000) == 0 ? 0 : 3];
        int n4 = i2.f;
        if (n4 == 40) {
            return;
        }
        if (n4 == 48) {
            return;
        }
        if (n4 == 47) {
            return;
        }
        if (this.b <= 0L && this.aY == 0 && this.bk == 0 && this.k != 6 && (this.aU & 0x70) == 0 || this.aV > 0) {
            ++this.be;
            this.a((byte)(this.m - n));
            if (this.bn == 0 && this.m == 0) {
                this.m = 0L;
                this.cq = this.bG;
                this.cr = this.bH;
                c = null;
            }
            this.aU = this.aU & 0xFFFFFF8F | n2;
            this.C(3);
            switch (n2) {
                case 16: {
                    this.ak = 0;
                    this.aj = 0;
                    this.aV = 5;
                    k.a[this.aR][this.aS] = 9;
                    this.aU = this.aU & 0xFFFFFF8F | 0;
                    k.b[this.aR][this.aS] = 0x8400000;
                    k.c[this.aR][this.aS] = 24;
                    return;
                }
                case 64: {
                    this.m(1000);
                    return;
                }
            }
            this.m(10);
            if (n3 != 0) {
                byte by = (byte)n3;
                do {
                    int n5;
                    int n6;
                    if (a[n6 = this.aR - g[by]][n5 = this.aS - g[by + 8]] >= 0 || (byte)(a[n6][n5] & 0xFF) >= 0) continue;
                    this.aR = n6;
                    this.aS = n5;
                    this.aT = 18;
                    this.j = 0;
                    this.aU = this.aU & 0xFFFFFFF8 | by | 0x800;
                    return;
                } while ((by = by >= 4 ? (byte)1 : (byte)(by + 1)) != n3);
            }
        }
    }

    public final void a(byte by) {
        this.m = by;
        if (this.m <= 0) {
            this.m = 0;
        } else if (this.m > i[8]) {
            this.m = i[8];
        }
        this.v();
    }

    public final void a(int n) {
        this.br = this.bq;
        this.y = false;
        this.bs = 0;
        this.bq = n;
        this.cV = 0;
        if (n >= 0) {
            this.ad();
        }
    }

    public final boolean a(int n) {
        return (W & n) != 0;
    }

    public final void keyPressed(int n) {
        int n2 = this.e(n);
        W |= n2;
        this.c = false;
    }

    public final void keyReleased(int n) {
        W &= ~this.e(n);
        this.c = true;
    }

    public final void a() {
        this.a = System.currentTimeMillis();
        aP = 0;
        aQ = 0;
        this.Z = 0;
    }

    public final void a(long l) {
        if (l <= 0L) {
            return;
        }
        System.currentTimeMillis();
        try {
            Thread.sleep(l);
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void run() {
        try {
            this.a = System.currentTimeMillis();
            this.a();
            this.B();
            while (!this.A) {
                if (this.ad) {
                    Thread.yield();
                    continue;
                }
                this.f = System.currentTimeMillis();
                try {
                    this.b();
                }
                catch (Exception exception) {
                    Exception exception2 = exception;
                    exception.toString();
                    exception2.printStackTrace();
                }
                if (this.A) break;
                if (l != 2) {
                    ++aP;
                }
                this.g = System.currentTimeMillis();
                if (this.h > 100L) {
                    this.a(152L - this.h - this.g);
                    this.u = true;
                    this.h = 0L;
                    continue;
                }
                this.repaint();
                this.serviceRepaints();
                this.u = false;
                if (l != 2) {
                    ++aQ;
                }
                this.h = Math.abs(System.currentTimeMillis() - this.f);
                this.a(76L - (System.currentTimeMillis() - this.f));
            }
            this.u();
            this.a.c();
            a.a();
            return;
        }
        catch (Exception exception) {
            Exception exception3 = exception;
            exception.toString();
            return;
        }
    }

    public final void b() throws Exception {
        this.cC();
        this.aJ();
        switch (l) {
            case 22: {
                this.cA();
                return;
            }
            case 21: {
                this.B(this.bu++);
                this.a();
                return;
            }
            case 20: {
                if (aP <= 30) break;
                this.B = true;
                this.J = true;
                this.H = true;
                this.cn();
                return;
            }
            case 35: {
                this.p(this.bu++);
                this.a();
                if (this.bu != 12) break;
                l = (byte)17;
                this.aO = 0;
                this.a.c(0);
                this.a.d();
                return;
            }
            case 17: {
                this.aX();
                return;
            }
            case 31: {
                return;
            }
            case 16: {
                this.C = true;
                this.n();
                W = 0;
                return;
            }
            case 0: {
                k.a[0] = new i(k.a("/ui.f", 0), 0, 0, null);
                a[0].a(0);
                l = (byte)6;
                this.a();
                return;
            }
            case 6: {
                if (aP < 60) {
                    a[0].b();
                    return;
                }
                a = this.a("/lang.f", 115);
                this.cE();
                k.a[18] = k.a("/ui.f", 3);
                this.da = k.a[18].c[14] & 0xFF;
                this.u();
                this.a(3);
                l = (byte)7;
                return;
            }
            case 7: {
                if (!this.y) break;
                l = (byte)8;
                this.bu = 0;
                this.bt = 22;
                return;
            }
            case 1: {
                this.aT();
                return;
            }
            case 3: {
                this.A = true;
                return;
            }
            case 9: {
                try {
                    if ((j[0] & 1) == 0) {
                        this.aj = true;
                    }
                    this.z();
                    int n = this.bt == 8 ? this.bu : this.bu - 14;
                    this.l(n);
                    ++this.bu;
                    this.W = true;
                    if (++n == 8) {
                        if (this.F) {
                            l = (byte)4;
                            if (this.bq == -1) {
                                this.aO = 0;
                                this.a(0);
                            } else {
                                this.aO = 2;
                            }
                        } else {
                            l = (byte)30;
                            this.F = true;
                        }
                        this.a.c(4);
                        this.a.d();
                    }
                }
                catch (Exception exception) {
                    Exception exception2 = exception;
                    exception.toString();
                }
                this.a();
                return;
            }
            case 11: {
                this.J = true;
                this.H = true;
                l = (byte)5;
                this.R = true;
                this.a();
                return;
            }
            case 5: {
                if (this.C && this.bu <= 5) {
                    int n;
                    this.j(this.bu++);
                    for (n = 0; n < 3; ++n) {
                        k.b[n] = false;
                    }
                    for (n = 1; n < 3; ++n) {
                        k.a[n] = false;
                    }
                    this.a();
                    if (this.bu == 5) {
                        this.N = true;
                        this.M = true;
                        this.L = true;
                        this.ap = 0;
                        this.aq = 13;
                        W = 0;
                    }
                } else {
                    this.i();
                }
                this.a();
                return;
            }
            case 8: {
                this.c(this.bu++);
                this.a();
                return;
            }
            case 2: 
            case 12: {
                return;
            }
            case 15: {
                this.g();
                return;
            }
            case 27: {
                this.h();
                return;
            }
            case 28: {
                try {
                    this.b(this.bu);
                    ++this.bu;
                    if (this.bu == 11) {
                        l = (byte)27;
                    }
                }
                catch (Exception exception) {
                    Exception exception3 = exception;
                    exception.toString();
                }
                this.a();
                return;
            }
            case 29: {
                this.d();
            }
        }
    }

    public final void c() {
        if (this.O >= this.d) {
            this.b = (byte)-1;
        } else if (this.O <= -this.d) {
            this.b = 1;
        }
        this.O += this.b * this.f;
        if (this.N >= this.e) {
            this.c = (byte)-1;
        } else if (this.O <= -this.e) {
            this.c = 1;
        }
        this.N += this.c * this.g;
    }

    public final void d() {
        switch (this.L) {
            case 0: {
                if (System.currentTimeMillis() - this.a < 3000L) break;
                ++this.L;
                this.a();
                return;
            }
            case 1: {
                if (aP % 6 >= 3) {
                    this.M += 0x199999;
                    this.au = false;
                } else {
                    this.au = true;
                }
                if (System.currentTimeMillis() - this.a < 5000L) break;
                ++this.L;
                this.au = true;
                this.a();
                return;
            }
            case 2: {
                this.c();
                if (System.currentTimeMillis() - this.a < 10000L) break;
                this.N = 0;
                this.O = 0;
                this.a();
                ++this.L;
                return;
            }
            case 3: {
                if (System.currentTimeMillis() - this.a < 1000L) break;
                ++this.L;
                return;
            }
            case 4: {
                if (System.currentTimeMillis() - this.a < 1000L) break;
                ++this.L;
                return;
            }
            case 5: {
                if (System.currentTimeMillis() - this.a < 1000L) break;
                ++this.L;
                return;
            }
            case 6: {
                if (System.currentTimeMillis() - this.a < 1000L) break;
                ++this.L;
                this.a();
                return;
            }
            case 7: {
                if (System.currentTimeMillis() - this.a < 1000L) break;
                c.a = new byte[9][10];
                ++this.L;
                c.b(3);
                this.a.c(4);
                this.a.d();
                this.a();
                return;
            }
            case 8: {
                c.a(3);
                this.au = true;
                if (System.currentTimeMillis() - this.a < 15000L) break;
                ++this.L;
                this.a();
                return;
            }
            case 9: {
                this.au = true;
                c.a(3);
                if (System.currentTimeMillis() - this.a < 12000L) break;
                ++this.L;
                this.a();
                return;
            }
            case 10: {
                this.u();
                this.a(0);
                l = (byte)22;
                this.aO = 0;
                this.a.f();
            }
        }
    }

    public final void e() {
        this.G = false;
        k.a(a[17], true);
        k.a[17] = null;
        int n = a.length;
        for (int i2 = 0; i2 < n; ++i2) {
            k.a[i2] = null;
        }
        a = null;
        k.a(a[10], true);
        k.a[10] = null;
        k.a(a[46], true);
        k.a[46] = null;
        k.a(a[55], true);
        k.a[55] = null;
        k.a[8] = null;
        k.a(a[59], true);
        k.a[3] = null;
        k.a(a[17], true);
        k.a[17] = null;
        System.gc();
    }

    public final void b(int n) {
        switch (n) {
            case 0: {
                if (!this.K) break;
                this.t();
                return;
            }
            case 1: {
                if (!this.H) break;
                this.cm();
                return;
            }
            case 2: {
                if (!this.M) break;
                this.E();
                return;
            }
            case 3: {
                if (!this.L) break;
                System.gc();
                this.L = false;
                return;
            }
            case 4: {
                this.u();
                a = k.a("/demoui.f", 0);
                if (a[10] == null) {
                    k.a[10] = k.a("/mmv.f", 0);
                }
                if (a[46] == null) {
                    k.a[46] = k.a("/mmv.f", 5);
                }
                this.o = 176 - this.c(a[10], 0) >> 1;
                this.p = 208 - this.b(a[10], 0) - 48 >> 1;
                return;
            }
            case 5: {
                if (a[55] == null) {
                    k.a[55] = k.a("/mmv.f", 4);
                    this.m = this.a(a[55], 0);
                    b = a[55];
                }
                if (a[18] != null) break;
                k.a[18] = k.a("/ui.f", 3);
                return;
            }
            case 6: {
                if (a[54] == null) {
                    k.a[54] = k.a("/mmv.f", 1);
                }
                this.v = this.c(a[54], 0) >> 1;
                this.w = this.b(a[54], 0) >> 1;
                return;
            }
            case 7: {
                if (a[53] != null) break;
                k.a[53] = k.a("/mmv.f", 2);
                return;
            }
            case 8: {
                if (a[52] != null) break;
                k.a[52] = k.a("/mmv.f", 3);
                return;
            }
            case 9: {
                try {
                    b b2 = k.a("/" + 0 + ".f", 3, 0);
                    k.a[8] = b2.a[0];
                    b2 = k.a("/cm.f", 2, 0);
                    b2.a(0, 0, -1, -1);
                    b2.a(1, 0, 0, -1);
                    k.a[59] = b2;
                    c.b = b2.a[0].length;
                    b2.g = null;
                    if (a[17] == null) {
                        k.a[17] = k.a("/ms.f", 0);
                    }
                    return;
                }
                catch (Exception exception) {
                    Exception exception2 = exception;
                    exception.toString();
                    return;
                }
            }
            case 10: {
                int n2;
                if (a[9] == null) {
                    k.a[9] = k.a("/cm.f", 7);
                }
                this.y = this.a(a[9], 5);
                byte by = i[2];
                for (n2 = 0; n2 < 3; ++n2) {
                    if ((by & 1 << n2) == 0) continue;
                    k.b[n2] = true;
                }
                this.t = 10;
                this.u = 10;
                by = i[1];
                if ((by & 1) != 0) {
                    k.a[1] = true;
                } else {
                    n2 = k.a(i, 6);
                    if (n2 >= h.b[1]) {
                        i[1] = (byte)(i[1] | 1);
                        this.A();
                        this.q = 1;
                        this.e = 1;
                    } else {
                        k.a[1] = false;
                    }
                }
                if ((by & 2) != 0) {
                    k.a[2] = true;
                } else {
                    n2 = k.a(i, 6);
                    if (n2 >= h.b[2]) {
                        i[1] = (byte)(i[1] | 2);
                        this.A();
                        this.q = 2;
                        this.e = 2;
                    } else {
                        k.a[2] = false;
                    }
                }
                this.f = h.d[this.e << 1];
                this.g = h.d[(this.e << 1) + 1];
                this.h = this.f;
                this.i = this.g;
                this.f();
                this.f = true;
                this.au = true;
            }
        }
    }

    public final void f() {
        boolean bl;
        this.b = this.e == 3 ? a[82] + " " + a[79] : ((bl = this.b(this.e)) ? a[82] + " " + a[79] : h.b[this.e] + " " + a[114].toLowerCase() + " " + a[79]);
        switch (this.e) {
            case 0: {
                this.c = a[28];
                return;
            }
            case 1: {
                this.c = a[29];
                return;
            }
            case 2: {
                this.c = a[30];
                return;
            }
            case 3: {
                this.c = a[31];
            }
        }
    }

    public final boolean b(int n) {
        if (n == 0 || n == 3) {
            return true;
        }
        int n2 = k.a(i, 6);
        return n2 >= h.b[n];
    }

    public final void g() {
        if (this.J > 0 || this.K > 0) {
            StringBuffer stringBuffer = new StringBuffer();
            if (this.J > 0) {
                stringBuffer.append(a[92]).append("\n");
                switch (this.J) {
                    case 1: {
                        stringBuffer.append(a[29]);
                        i[2] = (byte)(i[2] | 8);
                        break;
                    }
                    case 2: {
                        stringBuffer.append(a[30]);
                        i[2] = (byte)(i[2] | 8);
                        i[2] = (byte)(i[2] | 0x10);
                    }
                }
                this.A();
                this.J = 0;
            }
            if (this.K > 0) {
                if (stringBuffer.length() > 0) {
                    stringBuffer.append("\n\n");
                }
                stringBuffer.append(a[99]).append("\n").append(a[85 + this.K - 1]);
                this.K = 0;
            }
            if (stringBuffer.length() > 0) {
                this.a(stringBuffer.toString(), -1, -1, 5000, 4273165, 0);
            }
        }
    }

    public final void h() {
        if (!this.u) {
            this.h = this.f;
            this.i = this.g;
        }
        if (this.e) {
            W = 0;
            int n = this.k - this.f;
            int n2 = this.l - this.g;
            this.f += n / (8 - this.a);
            this.g += n2 / (8 - this.a);
            this.a = (byte)(this.a + 1);
            if (this.a == 8) {
                this.f = this.k;
                this.g = this.l;
                this.e = false;
                this.a = 0;
                this.f = true;
                this.f();
                return;
            }
        } else {
            switch (this.j) {
                case -1: {
                    break;
                }
                case 4: {
                    switch (this.e) {
                        case 0: {
                            this.G = true;
                            this.H = true;
                            this.a.f();
                            this.ap = 0;
                            this.k = false;
                            l = (byte)15;
                            ea = this.a(this.ap);
                            this.cn();
                            break;
                        }
                        case 1: {
                            if (!this.b(this.e)) break;
                            this.G = true;
                            this.H = true;
                            this.a.f();
                            this.ap = 1;
                            this.aq = 0;
                            l = (byte)15;
                            ea = this.a(this.ap);
                            this.cn();
                            this.o = true;
                            this.k = false;
                            if (i[9] >= 1) break;
                            k.i[9] = 1;
                            break;
                        }
                        case 2: {
                            if (!this.b(this.e)) break;
                            this.G = true;
                            this.H = true;
                            this.a.f();
                            this.ap = 2;
                            this.aq = 0;
                            this.k = false;
                            l = (byte)15;
                            ea = this.a(this.ap);
                            this.cn();
                            this.o = true;
                            if (i[9] >= 2) break;
                            k.i[9] = 2;
                            break;
                        }
                        case 3: {
                            l = (byte)18;
                        }
                    }
                    break;
                }
                default: {
                    int n = h.a[this.j][this.e];
                    if (n == -1) break;
                    this.e = n;
                    this.e = true;
                    this.k = h.d[this.e * 2];
                    this.l = h.d[this.e * 2 + 1];
                }
            }
            this.j = -1;
        }
    }

    public final void c(int n) {
        if (n < 11) {
            if (n == 0) {
                this.a.a();
            }
            this.a.a(n);
            if (n == 10) {
                this.a.b();
            }
            System.gc();
            return;
        }
        switch (n) {
            case 11: {
                k.a[9] = k.a("/cm.f", 7);
                return;
            }
            case 12: {
                k.a[0] = k.a("/ui.f", 2);
                return;
            }
            case 13: {
                k.b[0] = k.a("/demoui.f", 0, 0);
                k.b[1] = k.a("/demoui.f", 0, 1);
                return;
            }
            case 14: {
                l = (byte)9;
                this.a(-1);
                a = new StringBuffer(a[8]);
                a.delete(a.length() - 1, a.length());
                b = new StringBuffer(a[20]);
                b.delete(b.length() - 1, b.length());
                c = new StringBuffer("1");
            }
        }
    }

    public final String[] a(String string, int n) {
        byte[] byArray = k.a(string, 0);
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        String[] stringArray = new String[n];
        while (n4 < n) {
            if (byArray[n2 + n3] == 0) {
                try {
                    stringArray[n4] = new String(byArray, n2, n3, "ISO-8859-1");
                }
                catch (Exception exception) {
                    Exception exception2 = exception;
                    exception.toString();
                    exception2.printStackTrace();
                }
                n2 += n3 + 1;
                n3 = 0;
                ++n4;
                continue;
            }
            ++n3;
        }
        return stringArray;
    }

    public final void i() {
        try {
            int n = this.bu;
            if (this.C) {
                n -= 5;
            }
            ++this.bu;
            switch (n) {
                case 0: {
                    if (this.N) {
                        this.A();
                    }
                    return;
                }
                case 1: {
                    if (this.M) {
                        this.E();
                    }
                    return;
                }
                case 2: {
                    if (this.L) {
                        System.gc();
                        this.L = false;
                    }
                    return;
                }
                case 3: {
                    a[41].a(1);
                    a[41].a(2);
                    return;
                }
                case 4: {
                    if (this.J) {
                        this.u();
                    }
                    return;
                }
                case 5: {
                    if (this.H) {
                        this.cm();
                    }
                    return;
                }
                case 6: {
                    int n2 = this.c();
                    if (n2 < 1) {
                        this.V = n2;
                    } else if ((this.V + 9) % 9 < 1) {
                        this.V = 1;
                    }
                    this.A(this.V % 9);
                    return;
                }
                case 7: {
                    this.x();
                    return;
                }
                case 8: {
                    this.N();
                    this.G();
                    return;
                }
                case 9: {
                    this.bx();
                    return;
                }
                case 10: {
                    String string = "/" + this.ap + ".f";
                    this.a = k.a(string);
                    this.ce = this.a.a();
                    k.n = new byte[this.ce << 3];
                    this.a.a(k.n);
                    return;
                }
            }
            int n3 = n - 10 - 1;
            if (n3 < 4) {
                this.d(n3);
                this.bv = 0;
                return;
            }
            if ((n3 -= 4) >= 0 && n3 < 43) {
                this.f(n3);
                return;
            }
            if ((n3 -= 43) >= 0 && n3 < 8) {
                this.e(n3);
                if (n3 == 7) {
                    this.a.a();
                    this.a = null;
                    System.gc();
                }
                return;
            }
            if ((n3 -= 8) >= 0 && n3 < 16) {
                if (n3 < a.length) {
                    k.a[n3] = new d(this);
                    a[n3].a(p[n3]);
                }
                if (n3 == 15 && a.length >= 16) {
                    for (int i2 = 16; i2 < a.length; ++i2) {
                        k.a[i2] = new d(this);
                        a[i2].a(p[i2]);
                    }
                }
                return;
            }
            if ((n3 -= 16) >= 0 && n3 < 3) {
                switch (this.i) {
                    case 1: {
                        this.h(n3);
                        if (n3 == 2) {
                            this.a.a();
                            this.a = null;
                        }
                        return;
                    }
                    case 3: {
                        if (n3 > 0) {
                            return;
                        }
                        b b2 = k.a("/mmv.f", 1, 0);
                        k.a[31] = b2.a[0];
                        k.a[5] = new i(k.a("/mm1.f", 0), 0, 0, null);
                        a[5].a(0);
                        return;
                    }
                    case 4: {
                        if (n3 >= 2) {
                            return;
                        }
                        this.g(n3);
                        b b3 = k.a("/mmv.f", 3, 0);
                        k.a[32] = b3.a[0];
                        k.a[20] = k.a("/gen0.f", 7, 0);
                        if (n3 == 1) {
                            this.a.a();
                            this.a = null;
                        }
                        return;
                    }
                    case 5: {
                        b b4 = k.a("/mmv.f", 2, 0);
                        k.a[30] = b4.a[0];
                        k.a[20] = k.a("/gen0.f", 7, 0);
                        k.a[5] = new i(k.a("/b1.f", 0), 0, 0, null);
                        a[5].a(10);
                        return;
                    }
                }
                return;
            }
            switch (n3 -= 3) {
                case 0: {
                    k.n = null;
                    this.a(a[12] != null || a[6] != null || a[58] != null || this.i == 1 || this.i == 4 || this.i == 5);
                    break;
                }
                case 1: {
                    this.c = 0L;
                    this.d = 0L;
                    this.e = 0L;
                    this.bw = 0;
                    ++this.V;
                    this.i(this.V < 3 ? this.V : 3);
                    this.A();
                    break;
                }
                case 2: {
                    c = new int[this.ax][this.ay];
                    d = new byte[this.ax][this.ay];
                    e = new byte[this.ax][this.ay];
                    d = new int[this.ax][this.ay];
                    if (m == null) break;
                    o = new byte[m.length];
                    break;
                }
                case 3: {
                    this.cg();
                    break;
                }
                case 4: {
                    this.bn = 0;
                    this.T = 0;
                    this.S = 0;
                    this.bZ();
                    break;
                }
                case 5: {
                    this.bp = aP + 39;
                    this.d = a[38] + "\n" + this.P + " " + a[39];
                    this.v();
                    break;
                }
                case 6: {
                    k.a(a, true);
                    a = null;
                    System.gc();
                    break;
                }
                case 7: {
                    this.C = false;
                    f = null;
                    System.gc();
                    this.a.c(1 + this.ap);
                    this.a.d();
                    l = 1;
                }
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final int a() {
        return i[8] - 4;
    }

    public final void a(boolean bl) {
        try {
            a a2 = k.a("/o.f");
            int n = a2.a();
            byte[] byArray = new byte[n << 3];
            a2.a(byArray);
            int n2 = k.b(byArray, 4);
            byte[] byArray2 = new byte[n2];
            a2.a(byArray2);
            if (!bl) {
                a2.a();
                a2 = null;
                System.gc();
            }
            b b2 = new b();
            b2.a(byArray2, 0);
            this.cw = this.a();
            b2.a(this.cw, 0, -1, -1);
            b2.m = this.cw;
            b2.g = null;
            k.a[0] = new i(b2, 0, 0, null);
            System.gc();
            if (bl) {
                n2 = k.b(byArray, 12);
                byArray2 = new byte[n2];
                a2.a(byArray2);
                a2.a();
                System.gc();
                b2 = new b();
                b2.a(byArray2, 0);
                b2.a(0, 0, -1, -1);
                b2.g = null;
                k.a[3] = new i(b2, 0, 0, null);
                System.gc();
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final int b() {
        return a[this.bq][this.bs << 1];
    }

    public final void j() {
        k.a[41].m = 0;
        this.y = true;
        switch (this.bq) {
            case 0: {
                this.q();
                return;
            }
            case 3: {
                this.p();
                return;
            }
            case 7: {
                this.k();
                return;
            }
            case 2: {
                this.o();
                return;
            }
            case 1: {
                this.m();
                return;
            }
            case 5: {
                this.l();
            }
        }
    }

    public final void k() {
        block0 : switch (this.b()) {
            case 0: {
                if (this.br == 0) {
                    l = (byte)4;
                }
                this.a(this.br);
                break;
            }
            case 1: {
                switch (this.aO) {
                    case 1: {
                        this.n();
                        break block0;
                    }
                    case 3: {
                        l = (byte)15;
                        this.J = true;
                        this.H = true;
                        this.cn();
                        break block0;
                    }
                    case 4: {
                        this.u();
                        l = (byte)9;
                        this.bt = 8;
                        this.a(-1);
                        this.bu = 0;
                        break block0;
                    }
                    case 5: {
                        l = (byte)3;
                        this.a.c();
                        a.notifyDestroyed();
                    }
                }
            }
        }
        this.aO = -1;
    }

    public final void l() {
        switch (this.b()) {
            case 0: {
                short s;
                boolean bl = this.a.b = !this.a.b;
                if (this.a.b) {
                    s = 32;
                    this.C(6);
                } else {
                    this.a.f();
                    s = 33;
                }
                k.a(5, 0, s);
                return;
            }
            case 1: {
                l = !l;
                short s = 51;
                if (l) {
                    s = 50;
                    k.s(200);
                }
                k.a(5, 1, s);
            }
        }
    }

    public final void m() {
        switch (this.b()) {
            case 1: {
                this.a(7);
                this.aO = 1;
                return;
            }
            case 0: {
                l = 1;
                c = null;
                b = null;
                c = null;
                return;
            }
            case 3: {
                if (this.aq == 13 && this.ap == 0) break;
                this.a(7);
                this.aO = 3;
                return;
            }
            case 4: {
                this.a(7);
                this.aO = 4;
                return;
            }
            case 5: {
                this.a(7);
                this.aO = 5;
                return;
            }
            case 2: {
                this.a(5);
                return;
            }
            case 6: {
                l = (byte)33;
                this.au = true;
                return;
            }
            default: {
                this.y = false;
            }
        }
    }

    public final void n() {
        if (this.C) {
            this.bt = 97;
            this.bu = 0;
        } else {
            this.bt = 92;
            this.bu = 0;
        }
        this.J = true;
        this.w = false;
        l = (byte)11;
        this.j = 0;
        this.k = 0;
        this.aU = 0;
        this.aD = -1;
        this.aC = -1;
        this.b = 0L;
    }

    public final void o() {
        switch (this.b()) {
            case 0: {
                this.a.f();
                this.ap = 0;
                this.k = false;
                l = (byte)15;
                ea = this.a(this.ap);
                this.H = true;
                this.cn();
                return;
            }
            case 1: {
                this.a.f();
                this.ap = 1;
                this.aq = 0;
                l = (byte)15;
                ea = this.a(this.ap);
                this.H = true;
                this.cn();
                this.o = true;
                this.k = false;
                if (i[9] >= 1) break;
                k.i[9] = 1;
                return;
            }
            case 2: {
                this.a.f();
                this.ap = 2;
                this.aq = 0;
                this.k = false;
                l = (byte)15;
                ea = this.a(this.ap);
                this.H = true;
                this.cn();
                this.o = true;
                if (i[9] < 2) {
                    k.i[9] = 2;
                }
                if (i[8] >= 8) break;
                k.i[8] = 8;
                return;
            }
            case 3: {
                this.a(4);
                return;
            }
            default: {
                l = (byte)3;
                this.a.c();
                a.a();
            }
        }
    }

    public final void p() {
        short s = 0;
        switch (this.b()) {
            case 0: {
                this.a.b = true;
                s = 32;
                break;
            }
            case 1: {
                this.a.b = false;
                s = 33;
            }
        }
        this.aO = 0;
        k.a(5, 0, s);
    }

    public final void q() {
        switch (this.b()) {
            case 1: {
                this.a.f();
                this.z();
                if (i != null && this.a()) {
                    this.V = 0;
                    this.M = true;
                    this.o = true;
                    this.bu = 0;
                    l = (byte)28;
                    return;
                }
            }
            case 0: {
                this.a.f();
                if (!this.a()) {
                    this.aK();
                    return;
                }
                this.Q = true;
                this.C = false;
                l = (byte)31;
                return;
            }
            case 5: {
                this.a(7);
                this.aO = 5;
                return;
            }
            case 6: {
                l = (byte)10;
                return;
            }
            case 2: {
                this.a(5);
                return;
            }
            case 4: {
                l = (byte)22;
                this.aO = 0;
                this.a.f();
                return;
            }
            case 3: {
                l = (byte)33;
                this.a.f();
                this.au = true;
                return;
            }
        }
        this.y = false;
    }

    public final void r() {
        --this.bs;
        if (this.bs < 0) {
            this.bs = (a[this.bq].length >> 1) - 1;
        }
    }

    public final void s() {
        this.bs = (this.bs + 1) % (a[this.bq].length >> 1);
    }

    public final void t() {
        this.K = false;
        if (a != null) {
            int n = a.length;
            for (int i2 = 0; i2 < n; ++i2) {
                this.a(a[i2]);
                k.a[i2] = null;
            }
        }
        a = null;
        k.a(a[42], true);
        k.a(a[43], true);
        System.gc();
    }

    public final void a(d d2) {
        int n;
        if (d2 == null) {
            return;
        }
        if (d.a != null) {
            for (n = 0; n < d.a.length; ++n) {
                k.a(d.a[n], true);
                d.a[n] = null;
            }
        }
        if (d2.a != null) {
            for (n = 0; n < d2.a.length; ++n) {
                d2.a[n] = null;
            }
            d2.a = null;
        }
        d2.a = null;
    }

    public static final void a(b b2, boolean bl) {
        if (b2 == null) {
            return;
        }
        b2.a(bl);
    }

    public final void u() {
        int n;
        int n2;
        this.J = false;
        this.n = true;
        this.D = false;
        this.dj = 0;
        this.e = null;
        m = null;
        l = null;
        this.X = 0;
        this.Y = 0;
        d = null;
        a = null;
        e = null;
        this.a = null;
        k.n = null;
        c = null;
        d = null;
        b = null;
        a = null;
        p = null;
        k = null;
        if (a != null) {
            n2 = a.length;
            for (n = 0; n < n2; ++n) {
                this.a(a[n]);
                k.a[n] = null;
            }
        }
        a = null;
        if (this.a != null) {
            this.a(this.a);
            this.a = null;
        }
        if (a != null) {
            for (n2 = 0; n2 < 33; ++n2) {
                if (a[n2] == null) continue;
                n = a[n2].length;
                for (int i2 = 0; i2 < n; ++i2) {
                    k.a[n2][i2] = null;
                }
                k.a[n2] = null;
            }
        }
        k.a(d, true);
        System.gc();
        if (a != null) {
            for (n2 = 0; n2 < 61; ++n2) {
                if (n2 == 41 || n2 == 0 || n2 == 9 || n2 == 18) continue;
                k.a(a[n2], true);
                k.a[n2] = null;
            }
        }
        if (a != null) {
            for (n2 = 0; n2 < 6; ++n2) {
                if (a[n2] == null) continue;
                k.a(k.a[n2].a, true);
                k.a[n2].a = null;
                k.a[n2] = null;
            }
        }
        b = null;
        a = null;
        b = null;
        a = null;
        c = null;
        c = null;
        d = null;
        d = null;
        e = null;
        o = null;
        this.c = 0L;
        this.bw = 0;
        this.aA = -1;
        this.aC = -1;
        this.aE = -1;
        this.aF = -1;
        b = null;
        this.bM = -1;
        this.d = null;
        this.v = (byte)3;
        e = null;
        f = null;
        a = null;
        c = null;
        b = null;
        d = null;
        this.ak = false;
        this.dr = -1;
        this.ds = 0;
        this.dt = 0;
        this.t = 0;
        this.dw = 0;
        this.dx = 0;
        this.dy = 0;
        this.u = 0;
        this.dz = 0;
        this.dA = -1;
        this.k = false;
        e = null;
        this.ac();
        System.gc();
    }

    public final void v() {
        this.n = true;
    }

    public final void d(int n) throws Exception {
        int n2 = k.b(k.n, n * 8 + 4);
        byte[] byArray = new byte[n2];
        this.a.a(byArray);
        b b2 = new b();
        b2.a(byArray, 0);
        boolean bl = false;
        b2.a(0, 0, -1, -1);
        switch (n) {
            case 0: {
                if ((this.d & 1L) == 0L) break;
                k.a[60] = b2;
                break;
            }
            case 1: {
                if ((this.d & 2L) == 0L) break;
                k.a[16] = b2;
                break;
            }
            case 2: {
                k.a[0] = null;
                k.a[42] = b2;
                break;
            }
            case 3: {
                k.a[8] = b2.a[0];
            }
        }
        b2.g = null;
    }

    public final void e(int n) {
        try {
            if (n == 0) {
                this.a.a();
                this.a = null;
                System.gc();
                this.a = k.a("/cm.f");
                this.ce = this.a.a();
                k.n = new byte[this.ce << 3];
                this.a.a(k.n);
            }
            int n2 = k.b(k.n, n * 8 + 4);
            byte[] byArray = new byte[n2];
            this.a.a(byArray);
            b b2 = new b();
            b2.a(byArray, 0);
            b2.a(0, 0, -1, -1);
            switch (n) {
                case 6: {
                    k.a[43] = b2;
                    k.a[20] = null;
                    break;
                }
                case 5: {
                    if ((this.e & 0x20L) == 0L) break;
                    k.a[18] = b2.a[0];
                    break;
                }
                case 2: {
                    b2.a(1, 0, 0, -1);
                    k.a[59] = b2;
                    break;
                }
                case 1: {
                    switch (this.ap) {
                        case 1: 
                        case 2: {
                            if (this.ap == 0) break;
                            b2.a(this.ap, 0, -1, -1);
                            b2.a(0);
                            b2.m = this.ap;
                        }
                    }
                    k.a[56] = b2;
                    break;
                }
                case 3: {
                    k.a[13] = b2;
                    this.w();
                    break;
                }
                case 0: {
                    if ((this.e & 0x20L) == 0L) break;
                    k.a[11] = b2.a[0];
                    break;
                }
                case 4: {
                    k.a[5] = b2.a[0];
                }
            }
            b2.g = null;
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void w() {
        if ((this.d & 1L) == 0L) {
            for (int i2 = 0; i2 < 5; ++i2) {
                k.a[13].a[0][i2] = null;
            }
        }
    }

    public final void f(int n) {
        try {
            if (n % 10 == 0) {
                this.a.a();
                this.a = null;
                StringBuffer stringBuffer = new StringBuffer("/gen").append(this.bv).append(".f");
                this.a = k.a(stringBuffer.toString());
                this.ce = this.a.a();
                k.n = new byte[this.ce << 3];
                this.a.a(k.n);
                this.cf = 0;
                ++this.bv;
            }
            int n2 = n - (this.bv - 1) * 10;
            int n3 = k.b(k.n, n2 * 8 + 4);
            if ((this.c & 1L << n) != 0L) {
                if (this.cf != 0) {
                    this.a.a(this.cf);
                    this.cf = 0;
                }
                byte[] byArray = new byte[n3];
                this.a.a(byArray);
                b b2 = new b();
                b2.a(byArray, 0);
                if ((n != 28 || this.ae) && (n != 24 || this.ag)) {
                    b2.a(0, 0, -1, -1);
                }
                int n4 = -1;
                int n5 = -1;
                switch (n) {
                    case 41: {
                        n4 = 38;
                        break;
                    }
                    case 42: {
                        n4 = 39;
                        break;
                    }
                    case 0: {
                        n4 = 33;
                        break;
                    }
                    case 36: {
                        n4 = 35;
                        break;
                    }
                    case 1: {
                        n4 = 34;
                        break;
                    }
                    case 38: {
                        n4 = 36;
                        break;
                    }
                    case 16: 
                    case 18: {
                        n4 = 37;
                        break;
                    }
                    case 40: {
                        n4 = 2;
                        break;
                    }
                    case 32: {
                        n4 = 32;
                        break;
                    }
                    case 23: {
                        n4 = 30;
                        break;
                    }
                    case 37: {
                        n4 = 29;
                        break;
                    }
                    case 35: {
                        n4 = 28;
                        break;
                    }
                    case 34: {
                        n4 = 27;
                        break;
                    }
                    case 33: {
                        n4 = 22;
                        break;
                    }
                    case 31: {
                        n5 = 29;
                        break;
                    }
                    case 30: {
                        n4 = 15;
                        break;
                    }
                    case 28: {
                        if (this.af) {
                            b2.a(1, 0, -1, -1);
                        }
                        n4 = 45;
                        break;
                    }
                    case 29: {
                        n5 = 26;
                        break;
                    }
                    case 2: {
                        if (this.ae) {
                            k.a[24] = b2.a[0];
                        }
                        if (!this.af) break;
                        b2.a(1, 0, -1, -1);
                        k.a[25] = b2.a[1];
                        break;
                    }
                    case 6: {
                        n5 = 21;
                        break;
                    }
                    case 27: {
                        n5 = 19;
                        break;
                    }
                    case 26: {
                        d = b2;
                        break;
                    }
                    case 25: {
                        n5 = 17;
                        break;
                    }
                    case 5: {
                        n4 = 58;
                        break;
                    }
                    case 3: {
                        n4 = 7;
                        break;
                    }
                    case 39: {
                        n4 = 6;
                        break;
                    }
                    case 8: {
                        n4 = 5;
                        break;
                    }
                    case 24: {
                        k.a[15] = null;
                        b2.a(1, 0, -1, -1);
                        n4 = 57;
                        k.a[14] = null;
                        break;
                    }
                    case 22: {
                        n4 = 8;
                        break;
                    }
                    case 20: {
                        n5 = 13;
                        break;
                    }
                    case 4: 
                    case 21: {
                        if (this.ap == 2) break;
                        n4 = 3;
                        break;
                    }
                    case 7: {
                        if (this.ap == 2) {
                            b2.a = null;
                            b2.a(1, 0, -1, -1);
                            b2.m = 1;
                        }
                        n4 = 20;
                        break;
                    }
                    case 14: {
                        n5 = 6;
                        break;
                    }
                    case 10: {
                        k.a[4] = new i(b2, 0, 0, null);
                        a[4].a(0);
                        break;
                    }
                    case 9: {
                        n4 = 12;
                        break;
                    }
                    case 15: 
                    case 17: {
                        if ((this.bw & 2) != 0) {
                            if (this.ap == 2) {
                                b2.a = null;
                                b2.a(2, 0, -1, -1);
                                b2.m = 2;
                            }
                            n4 = 4;
                        }
                        if ((this.bw & 1) == 0) break;
                        k.a[21] = new b();
                        a[21].a(byArray, 0);
                        a[21].a(1, 0, -1, -1);
                        k.a[21].m = 1;
                        k.a[21].g = null;
                        break;
                    }
                    case 13: {
                        n4 = 1;
                        break;
                    }
                    case 11: {
                        n4 = 11;
                        break;
                    }
                    case 19: {
                        n5 = 7;
                        break;
                    }
                    case 12: {
                        n5 = 10;
                    }
                }
                if (n4 != -1) {
                    k.a[n4] = b2;
                }
                if (n5 != -1) {
                    k.a[n5] = b2.a[0];
                }
                b2.g = null;
            } else {
                this.cf += n3;
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void g(int n) {
        try {
            if (n == 0) {
                this.a = k.a("/b0.f");
                this.ce = this.a.a();
                k.n = new byte[this.ce * 8];
                this.a.a(k.n);
            }
            int n2 = k.b(k.n, n * 8 + 4);
            byte[] byArray = new byte[n2];
            this.a.a(byArray);
            b b2 = new b();
            b2.a(byArray, 0);
            b2.a(0, 0, -1, -1);
            b2.g = null;
            switch (n) {
                case 0: {
                    k.a[5] = new i(b2, 0, 0, null);
                    break;
                }
                case 1: {
                    k.a[40] = b2;
                }
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void h(int n) {
        try {
            if (n == 0) {
                this.a = k.a("/mm0.f");
                this.ce = this.a.a();
                k.n = new byte[this.ce * 8];
                this.a.a(k.n);
            }
            int n2 = k.b(k.n, n * 8 + 4);
            byte[] byArray = new byte[n2];
            this.a.a(byArray);
            b b2 = new b();
            b2.a(byArray, 0);
            b2.a(0, 0, -1, -1);
            b2.g = null;
            switch (n) {
                case 2: {
                    k.a[27] = b2.a[0];
                    break;
                }
                case 1: {
                    k.a[2] = new i(b2, 0, 0, null);
                    a[2].a(0);
                    break;
                }
                case 0: {
                    k.a[1] = new i(b2, 0, 0, null);
                    a[1].a(2);
                }
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final int c() {
        byte by = i[12];
        return by;
    }

    public final void i(int n) {
        k.i[12] = (byte)n;
    }

    public final boolean a() {
        if (i == null) {
            return false;
        }
        return i[13] != 0;
    }

    public final void b(boolean bl) {
        k.i[13] = bl ? (byte)1 : 0;
        this.A();
    }

    public final void x() {
        this.bc = this.c(this.ap, this.aq);
    }

    public final void y() {
        this.I = false;
        this.D();
        this.a(this.ap, ea);
        this.b(this.ap, this.aq, this.bd + this.b(this.ap, this.aq));
        this.A();
    }

    public final void z() {
        try {
            RecordStore recordStore = RecordStore.openRecordStore((String)"DiamondRush", (boolean)true);
            i = recordStore.getRecord(1);
            this.cy = i.length;
            recordStore.closeRecordStore();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void A() {
        this.N = false;
        try {
            RecordStore recordStore = RecordStore.openRecordStore((String)"DiamondRush", (boolean)true);
            if (recordStore.getNumRecords() == 0) {
                recordStore.addRecord(i, 0, this.cy);
            } else {
                recordStore.setRecord(1, i, 0, this.cy);
            }
            recordStore.closeRecordStore();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void B() {
        Exception exception;
        RecordStore recordStore = null;
        try {
            recordStore = RecordStore.openRecordStore((String)"Preferences", (boolean)false);
        }
        catch (Exception exception2) {
            exception = exception2;
            exception2.toString();
        }
        j = new byte[1];
        if (recordStore == null) {
            try {
                recordStore = RecordStore.openRecordStore((String)"Preferences", (boolean)true);
                k.j[0] = 0;
                this.cx = j.length;
                recordStore.closeRecordStore();
                this.C();
                return;
            }
            catch (Exception exception3) {
                exception = exception3;
                exception3.toString();
                return;
            }
        }
        try {
            j = recordStore.getRecord(1);
            this.cx = j.length;
            recordStore.closeRecordStore();
            return;
        }
        catch (Exception exception4) {
            exception = exception4;
            exception4.toString();
            return;
        }
    }

    public final void C() {
        try {
            RecordStore recordStore = RecordStore.openRecordStore((String)"Preferences", (boolean)true);
            if (recordStore.getNumRecords() == 0) {
                recordStore.addRecord(j, 0, this.cx);
            } else {
                recordStore.setRecord(1, j, 0, this.cx);
            }
            recordStore.closeRecordStore();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void j(int n) {
        try {
            String string = null;
            switch (n) {
                case 0: 
                case 1: {
                    RecordStore recordStore = null;
                    try {
                        recordStore = RecordStore.openRecordStore((String)"DiamondRush", (boolean)false);
                    }
                    catch (Exception exception) {
                        Exception exception2 = exception;
                        exception.toString();
                    }
                    if (recordStore == null) {
                        this.O = true;
                    } else {
                        this.O = false;
                        recordStore.closeRecordStore();
                    }
                    if (n == 0) break;
                    i = new byte[1000];
                    k.i[3] = 5;
                    k.i[8] = 4;
                    k.i[9] = 0;
                    k.i[10] = 0;
                    this.cy = 14;
                    this.cy += 6;
                    break;
                }
                case 2: {
                    string = "/map_angkor.out";
                }
                case 3: {
                    if (string == null) {
                        string = "/map_scotland.out";
                    }
                }
                case 4: {
                    if (string == null) {
                        string = "/map_tibet.out";
                    }
                    this.a = k.a(b[n - 2]);
                    this.a.a();
                    int n2 = n - 2;
                    int n3 = this.cy;
                    k.i[14 + n2 * 2] = (byte)(this.cy & 0xFF);
                    k.i[14 + n2 * 2 + 1] = (byte)(this.cy >> 8);
                    int n4 = this.a.a();
                    k.i[this.cy++] = (byte)n4;
                    k.i[this.cy++] = 0;
                    this.cH();
                    this.a(string);
                    k.i[this.cy++] = (byte)this.dL;
                    this.cm();
                    this.cy += n4 << 1;
                    for (int i2 = 0; i2 < n4; ++i2) {
                        int n5;
                        int n6;
                        int n7 = this.cy;
                        k.i[n3 + 3 + i2 * 2] = (byte)(n7 & 0xFF);
                        k.i[n3 + 3 + i2 * 2 + 1] = (byte)(n7 >> 8);
                        byte by = 0;
                        byte by2 = 0;
                        int n8 = this.a(this.a);
                        int n9 = this.a(this.a);
                        byte[] byArray = new byte[n8 * n9];
                        this.a.a(byArray);
                        for (n6 = 0; n6 < n9; ++n6) {
                            for (n5 = 0; n5 < n8; ++n5) {
                                if (byArray[n5 + n6 * n8] != 2) continue;
                                by2 = (byte)(by2 + 1);
                            }
                        }
                        i[0] = (byte)(i[0] + by2);
                        k.i[this.cy++] = 0;
                        k.i[this.cy++] = by2;
                        k.i[this.cy++] = 0;
                        this.a.a(n8 * n9);
                        n6 = this.cy;
                        this.cy += 2;
                        this.a.a(byArray);
                        for (n5 = 0; n5 < n9; ++n5) {
                            for (int i3 = 0; i3 < n8; ++i3) {
                                if (byArray[i3 + n5 * n8] != 14 && byArray[i3 + n5 * n8] != 33) continue;
                                k.i[this.cy++] = (byte)i3;
                                k.i[this.cy++] = (byte)n5;
                                by = (byte)(by + 1);
                            }
                        }
                        k.i[n6] = 0;
                        k.i[n6 + 1] = by;
                    }
                    this.a.a();
                    this.a = null;
                    System.gc();
                }
            }
            return;
        }
        catch (Exception exception) {
            Exception exception3 = exception;
            exception.toString();
            return;
        }
    }

    public final void D() {
        k.i[3] = (byte)this.ao;
        k.i[11] = this.q;
    }

    public final void E() {
        this.M = false;
        this.ao = i[3];
        this.q = i[11];
        this.bb = k.a(i, 4);
    }

    public final byte a(int n, int n2) {
        int n3 = this.a(n, n2);
        return i[n3 + 2];
    }

    public final void a(int n, int n2, byte by) {
        int n3 = this.a(n, n2);
        int n4 = n3 + 2;
        i[n4] = (byte)(i[n4] | by);
    }

    public final void a(int n, int n2) {
        int n3 = this.b(n) + 1;
        if (i[n3] < n2) {
            k.i[n3] = (byte)n2;
        }
    }

    public final int a(int n) {
        int n2 = this.b(n) + 1;
        if (n2 >= 0 && n2 <= i.length) {
            return i[this.b(n) + 1];
        }
        return 0;
    }

    public final int b(int n) {
        if (n < 0) {
            n = 0;
        } else if (n >= 3) {
            n = 2;
        }
        return k.a(i, 14 + n * 2);
    }

    public final int a(int n, int n2) {
        return k.a(i, this.b(n) + 3 + n2 * 2);
    }

    public final int b(int n, int n2) {
        return i[this.a(n, n2) + 0];
    }

    public final void b(int n, int n2, int n3) {
        k.i[this.a((int)n, (int)n2) + 0] = (byte)n3;
    }

    public final int c(int n, int n2) {
        return i[this.a(n, n2) + 1];
    }

    public final void a(int n, int n2, int n3, int n4) {
        int n5 = this.a(n, n2);
        int n6 = i[n5 + 4];
        for (int i2 = 0; i2 < n6; ++i2) {
            if (i[n5 + 5 + 2 * i2 + 0] != n3 || i[n5 + 5 + 2 * i2 + 1] != n4) continue;
            k.i[n5 + 5 + 2 * i2 + 0] = 0;
            k.i[n5 + 5 + 2 * i2 + 1] = 0;
            int n7 = n5 + 3;
            i[n7] = (byte)(i[n7] + 1);
            return;
        }
    }

    public final boolean a(int n, int n2, int n3, int n4) {
        int n5 = this.a(n, n2);
        int n6 = i[n5 + 4];
        for (int i2 = 0; i2 < n6; ++i2) {
            if (i[n5 + 5 + 2 * i2 + 0] != n3 || i[n5 + 5 + 2 * i2 + 1] != n4) continue;
            return false;
        }
        return true;
    }

    public final void F() {
        this.ad = 13;
        this.af = 4;
        this.ai = 408;
        this.i = (byte)5;
        this.c |= 0x80L;
        this.c |= 8L;
        this.ac = false;
        this.D = 16;
        this.E = 16;
        this.F = 19;
        this.G = 18;
    }

    public final void G() throws Exception {
        cE = -1;
        E = false;
        this.d = true;
        this.az = 0;
        this.bl = 0;
        this.c = 0L;
        this.d = 0L;
        this.e = 0L;
        this.Q = 0;
        this.R = 0;
        this.i = 0;
        this.P = (this.a(this.ap, this.aq) & 2) != 0;
        this.cn = 0;
        switch (this.ap) {
            case 0: {
                if (this.aq == 5) {
                    this.i = 1;
                    this.aa = 816;
                    this.ab = 0;
                    break;
                }
                if (this.aq == 13) {
                    this.i = (byte)2;
                    this.s = false;
                    break;
                }
                if (this.aq != 8) break;
                this.i = (byte)4;
                this.ad = 0;
                this.af = 3;
                this.ag = 0;
                this.ae = 0;
                this.j = false;
                this.c |= 8L;
                this.c |= 0x400L;
                this.D = 2;
                this.E = 12;
                this.F = 15;
                this.G = 5;
                break;
            }
            case 1: {
                if (this.aq != 9) break;
                this.F();
                break;
            }
            case 2: {
                if (this.aq != 10) break;
                this.bm();
                this.ah = 360;
                this.i = (byte)3;
                this.c |= 0x80L;
                this.c |= 8L;
            }
        }
        this.p = false;
        this.q = false;
        this.r = false;
        this.P = 0;
        this.bg = -1;
        this.bh = -1;
        this.n = 0;
        this.bi = 0;
        this.bj = 0;
        this.bk = 0;
        this.am = 45;
        this.m = i[8];
        this.k = 0;
        this.bb = 0;
        this.be = 0;
        this.bf = 0;
        this.bd = 0;
        this.aY = 0;
        this.aU = 0;
        this.aV = 0;
        this.aW = 0;
        this.aX = 0;
        co = -1;
        m = null;
        l = null;
        this.a = k.a(b[this.ap]);
        this.a.a();
        boolean bl = false;
        while (!bl) {
            int n = this.a.a();
            byte[] byArray = new byte[4];
            for (int i2 = 0; i2 < n && !bl; ++i2) {
                this.a.a(byArray);
                int n2 = k.a(byArray, 0);
                int n3 = k.a(byArray, 2);
                if (i2 == this.aq) {
                    int n4;
                    int n5;
                    this.ax = n2;
                    this.ay = n3;
                    a = null;
                    c = null;
                    a = null;
                    System.gc();
                    a = new byte[this.ax][this.ay];
                    c = new byte[this.ax][this.ay];
                    a = new int[this.ax][this.ay];
                    byArray = new byte[this.ax * this.ay];
                    this.a.a(byArray);
                    for (n5 = 0; n5 < this.ax; ++n5) {
                        for (n4 = 0; n4 < this.ay; ++n4) {
                            k.a[n5][n4] = byArray[n5 + n4 * this.ax];
                        }
                    }
                    b = new byte[this.ax][this.ay];
                    b = new int[this.ax][this.ay];
                    this.a.a(byArray);
                    for (n5 = 0; n5 < this.ax; ++n5) {
                        for (n4 = 0; n4 < this.ay; ++n4) {
                            k.b[n5][n4] = byArray[n5 + n4 * this.ax];
                        }
                    }
                    this.a.a(byArray);
                    for (n5 = 0; n5 < this.ax; ++n5) {
                        for (n4 = 0; n4 < this.ay; ++n4) {
                            k.a[n5][n4] = byArray[n5 + n4 * this.ax];
                        }
                    }
                    byArray = null;
                    bl = true;
                    continue;
                }
                this.a.a(n2 * n3 * 3);
            }
        }
        this.a.a();
        this.a = null;
        this.at = 0;
        this.av = 0;
        this.ar = 0;
        this.au = 0;
        this.aw = 0;
        this.as = 0;
        this.bq();
        System.gc();
    }

    public final void H() {
        int n = this.dW;
        int n2 = this.dX;
        long l = a[n][n2];
        int n3 = this.a(l, (byte)6, (byte)5);
        int n4 = this.a(l, (byte)11, (byte)3);
        int n5 = 14;
        if (this.aq >= this.dL) {
            this.a(this.ap, this.aq, (byte)2);
        }
        if (n4 > 1) {
            int n6 = 0;
            while (n6 < n4) {
                int n7;
                int n8;
                int n9 = this.a(l, (byte)n5, (byte)4);
                long l2 = a[n9][n8 = this.a(l, (byte)(n5 += 4), (byte)4)];
                int n10 = this.a(l2, (byte)3, (byte)3);
                if (n10 == 1 && (n7 = this.a(l2, (byte)6, (byte)5)) > n3) {
                    ea = n7;
                    this.cz = n;
                    this.cA = n2;
                    this.a(this.ap, ea, (byte)64);
                    this.aa = true;
                }
                ++n6;
                n5 += 4;
            }
        } else {
            ea = this.aq;
        }
    }

    public final synchronized void paint(Graphics graphics) {
        try {
            a = graphics;
            k.a(a, 0, 0, 176, 208);
            switch (l) {
                case 24: {
                    break;
                }
                case 34: {
                    break;
                }
                case 22: {
                    this.cB();
                    break;
                }
                case 33: {
                    this.I();
                    break;
                }
                case 20: {
                    this.a(a, a[41], a[48], 88, 104, 3, 20, true);
                    break;
                }
                case 17: {
                    this.aV();
                    break;
                }
                case 10: {
                    this.a(a);
                    break;
                }
                case 4: {
                    this.L();
                    break;
                }
                case 7: {
                    this.af();
                    break;
                }
                case 30: {
                    this.a(a, 1);
                    if (aP % 20 < 10) break;
                    a[41].a(a, a[82], 88, 173, 17);
                    break;
                }
                case 2: {
                    this.af();
                    break;
                }
                case 5: {
                    if (!this.R) {
                        k.a(a, 0, 181, 176, 27);
                        this.ai();
                        k.a(a, 0, 0, 176, 208);
                    } else {
                        this.ai();
                    }
                    if (f == null || !this.R) break;
                    this.cl();
                    break;
                }
                case 28: {
                    this.bt = 11;
                    this.ai();
                    break;
                }
                case 8: 
                case 9: 
                case 21: 
                case 35: {
                    this.ai();
                    break;
                }
                case 6: {
                    this.aG();
                    break;
                }
                case 1: {
                    this.P();
                    break;
                }
                case 12: {
                    this.M();
                    break;
                }
                case 0: 
                case 3: {
                    break;
                }
                case 15: {
                    this.co();
                    break;
                }
                case 18: {
                    this.cy();
                    this.au = true;
                    l = (byte)25;
                    this.eo = this.c;
                    this.f = a[110] + " " + k.a(i, 4) + " " + a[109];
                }
                case 25: {
                    this.cz();
                    break;
                }
                case 26: {
                    break;
                }
                case 27: {
                    this.K();
                    break;
                }
                case 31: {
                    if (!this.Q) break;
                    this.Q = false;
                    a.setColor(0);
                    a.fillRect(0, 0, 176, 208);
                    k.a[41].p = 5;
                    a[41].b(a, k.a(a[this.O ? 69 : 68], 156), 88, 104, 3);
                    this.ah();
                    this.ag();
                    break;
                }
                case 16: {
                    this.ai();
                    break;
                }
                case 29: {
                    this.J();
                }
            }
            this.cD();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            System.out.println("Exception in paint: " + exception2);
            exception2.printStackTrace();
            return;
        }
    }

    public final void I() {
        if (this.au) {
            b b2 = a[41];
            boolean bl = false;
            boolean bl2 = false;
            int n = 0;
            k.a[103] = k.a(a[103], 170);
            k.a[4] = k.a(a[4], 170);
            k.a[106] = k.a(a[106], 170);
            a.setColor(0);
            k.a(a, 0, 0, 176, 208);
            a.fillRect(0, 0, 176, 208);
            b2.b(a, a[4], 88, 3, 17);
            b2.p = 0;
            b2.a(a[103]);
            int n2 = b.o;
            b2.b(a, a[103], 88, 20, 17);
            n = 20 + (n2 + 17);
            String string = k.a(a[104] + '\n' + a[105], 170);
            b2.a(string);
            n2 = b.o;
            b2.b(a, string, 88, n, 17);
            n += n2 + 17;
            b2.a(a[106]);
            n2 = b.o;
            b2.b(a, a[106], 88, n, 17);
            string = k.a(a[107] + '\n' + a[108], 170);
            b2.b(a, string, 88, n += n2 + 17, 17);
            this.ag();
            this.au = false;
        }
    }

    public final void a(Graphics graphics, boolean bl, int n, int n2) {
        int n3;
        k.a(graphics, 0, 0, 176, 208);
        int n4 = 0;
        int n5 = 0;
        boolean bl2 = false;
        boolean bl3 = false;
        if (n != 0 || n2 != 0) {
            n4 -= 24;
            n5 -= 24;
        }
        int n6 = 0;
        for (n3 = n5; n3 < 208; n3 += 24) {
            boolean bl4 = false;
            for (int i2 = n4; i2 < 176; i2 += 24) {
                k.a(graphics, a[8][0], i2 + n, n3 + n2, 0);
            }
        }
        a[10].a(graphics, 0, this.o + n, this.p + n2, 0, 0, 0);
        if (bl) {
            for (n3 = 0; n3 < 208; n3 += 24) {
                for (n6 = 0; n6 < 176; n6 += 24) {
                    a[17].a(graphics, 16, n6, n3, 0, 0, 0);
                }
            }
        }
    }

    public final void a(Graphics graphics, boolean bl) {
        this.a(graphics, bl, 0, 0);
    }

    public final void J() {
        int n;
        int n2;
        if (this.au) {
            this.a(a, false, this.N, this.O);
            a[17].a(a, 11, 88 + h.c[6] + this.N, 80 + h.c[7] + this.O, 0, 0, 0);
            n2 = 0;
            for (n = 0; n < 3; ++n) {
                n2 = 52 + n;
                a[n2].a(a, 0, h.c[n << 1] + 88 - this.v + this.N, h.c[(n << 1) + 1] + 80 - this.w + this.O, 0, 0, 0);
            }
        }
        switch (this.L) {
            case 1: {
                if (this.au) break;
                a.setColor(this.M);
                a.fillRect(0, 0, 176, 208);
                for (n = 0; n < 3; ++n) {
                    n2 = 52 + n;
                    a[n2].a(a, 0, h.c[n << 1] + 88 - this.v, h.c[(n << 1) + 1] + 80 - this.w, 0, 0, 0);
                }
                break;
            }
            case 2: {
                return;
            }
            case 3: {
                return;
            }
            case 4: {
                return;
            }
            case 5: {
                return;
            }
            case 6: {
                return;
            }
            case 7: {
                return;
            }
            case 8: {
                c.a(a);
                return;
            }
            case 9: 
            case 10: {
                c.a(a);
                n2 = k.a[41].p;
                k.a[41].p = 3;
                String string = a[40] + "\n" + a[97];
                string = k.a(string, 156);
                a[41].a(string);
                k.b(a, (176 - b.n >> 1) - 3, (208 - b.o >> 1) - 3, b.n + 6, b.o + 6, 7096587, 0);
                a[41].b(a, string, 88, 104, 3);
                k.a[41].p = n2;
            }
        }
    }

    public final void K() {
        int n;
        int n2;
        block12: {
            block10: {
                block11: {
                    if (this.au || this.f) {
                        k.a(a, 0, 0, 176, 208);
                        this.a(a, false);
                        a[17].a(a, 11, 88 + h.c[6], 80 + h.c[7], 0, 0, 0);
                        this.ag();
                        this.ah();
                        a[41].a(a, a[27].toLowerCase(), 156, 201, 10);
                        this.au = false;
                    } else {
                        k.a(a, this.h + 88, this.i + 80, 14, 22);
                        a[10].a(a, 0, this.o, this.p, 0, 0, 0);
                    }
                    if (this.q == 0) break block10;
                    this.f = false;
                    this.au = true;
                    for (n2 = 0; n2 < this.q; ++n2) {
                        if (!this.b(n2)) continue;
                        a[10].a(a, n2 + 1, this.o, this.p, 0, 0, 0);
                    }
                    k.a(a, 0, 0, 176, 208);
                    if (this.z >= this.y) break block11;
                    a[9].a(a, 5, this.z, h.c[this.q << 1] + 88 - 12, h.c[(this.q << 1) + 1] + 68, 0, 0, 0);
                    ++this.z;
                    break block12;
                }
                if (this.n % this.m >= this.m >> 1) {
                    a[10].a(a, this.q + 1, this.o, this.p, 0, 0, 0);
                    ++this.r;
                }
                if (this.r < 15) break block12;
                k.a[this.q] = true;
                this.r = 0;
                this.q = 0;
                this.z = 0;
                this.f();
                this.f = true;
                this.au = false;
                break block12;
            }
            for (n2 = 0; n2 < 3; ++n2) {
                if (!a[n2]) continue;
                a[10].a(a, n2 + 1, this.o, this.p, 0, 0, 0);
            }
        }
        for (n = 0; n < 3; ++n) {
            if (!b[n]) continue;
            n2 = 52 + n;
            if (this.s == n) continue;
            a[n2].a(a, 0, h.c[n << 1] + 88 - this.v, h.c[(n << 1) + 1] + 80 - this.w, 0, 0, 0);
        }
        if (this.s != -1) {
            this.au = true;
            if (this.c(this.s)) {
                this.s = -1;
                if (b[0] && b[1] && b[2]) {
                    this.a();
                    this.au = true;
                    this.h = true;
                    l = (byte)29;
                }
            }
            return;
        }
        this.n %= this.m;
        k.a(a, this.f + 88, 80 + this.g, 14, 22);
        a[55].a(a, 0, this.n, 88 + this.f, 80 + this.g, 0, 0, 0);
        ++this.n;
        if (this.f) {
            n = k.a[41].p;
            k.a[41].p = 1;
            String string = this.b + "\n" + this.c;
            string = k.a(string, 156);
            a[41].a(string);
            int n3 = (176 - b.n >> 1) - 3;
            int n4 = 166 - (b.o >> 1) - 3;
            int n5 = b.n + 6;
            int n6 = b.o + 6;
            k.a(a, n3, n4, n5, n6);
            k.b(a, n3, n4, n5, n6, 7096587, 0);
            a[41].b(a, string, 88, 166, 3);
            k.a[41].p = n;
            this.f = false;
        }
    }

    public final boolean c(int n) {
        int n2 = 52 + n;
        int n3 = h.c[n << 1] + 88;
        int n4 = h.c[(n << 1) + 1] + 80;
        int n5 = n4 - this.u;
        int n6 = n3 - this.t;
        if (n5 < 0) {
            this.u -= 2;
            if (this.u <= n4) {
                this.u = n4;
            }
        } else if (n5 > 0) {
            this.u += 2;
            if (this.u >= n4) {
                this.u = n4;
            }
        }
        if (n6 < 0) {
            this.t -= 3;
            if (this.t <= n3) {
                this.t = n3;
            }
        } else if (n6 > 0) {
            this.t += 3;
            if (this.t >= n3) {
                this.t = n3;
            }
        }
        a[n2].a(a, 0, this.t - this.v, this.u - this.w, 0, 0, 0);
        if (this.t == n3 && this.u == n4) {
            this.t = n3;
            this.u = n4;
            if (this.x < 20) {
                if (this.x % 2 == 1) {
                    int n7 = 838860;
                    a.setColor(0 + n7 * this.x);
                    a.fillRect(0, 0, 176, 208);
                }
                ++this.x;
                return false;
            }
            if (this.z < this.y) {
                a[9].a(a, 5, this.z, h.c[n << 1] + 88 - 12, h.c[(n << 1) + 1] + 68, 0, 0, 0);
                ++this.z;
                return false;
            }
            this.z = 0;
            this.x = 0;
            return true;
        }
        return false;
    }

    public final void L() {
        this.af();
    }

    public final void a(Graphics graphics, int n) {
        a[19].a(graphics, n, 88, 104, 0, 0, 3);
    }

    public final void M() {
        a.setColor(0);
        a.fillRect(0, 0, 176, 208);
        b b2 = a[41];
        b2.a(a, a[35], 88, 30, 17);
        if (this.i == 2) {
            b2.a(a, a[26], 176, 208, 40);
        } else {
            b2.a(a, a[1], 176, 208, 40);
            String string = a[111] + " " + (k.a(i, 4) < 500 ? k.a(i, 4) : 500);
            String string2 = new String(a[109]);
            b2.a(a, string, 88, 140, 17);
            b2.a(a, string2, 88, 152, 17);
        }
        this.as();
    }

    public final void a(Graphics graphics) {
        int n = this.ar % cC;
        int n2 = this.as % cD;
        int n3 = (this.ar + 176) % cC;
        int n4 = (this.as + 180) % cD;
        if (n3 > n) {
            if (n4 > n2) {
                this.a(graphics, n, n2, 176, 180, 0, 0);
                return;
            }
            this.a(graphics, n, n2, 176, 180 - n4, 0, 0);
            this.a(graphics, n, 0, 176, n4, 0, 180 - n4);
            return;
        }
        if (n4 > n2) {
            this.a(graphics, n, n2, 176 - n3, 180, 0, 0);
            this.a(graphics, 0, n2, n3, 180, 176 - n3, 0);
            return;
        }
        this.a(graphics, n, n2, 176 - n3, 180 - n4, 0, 0);
        this.a(graphics, n, 0, 176 - n3, n4, 0, 180 - n4);
        this.a(graphics, 0, n2, n3, 180 - n4, 176 - n3, 0);
        this.a(graphics, 0, 0, n3, n4, 176 - n3, 180 - n4);
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6) {
        k.a(graphics, a, n5 - n, n6 - n2, 0);
    }

    public final void N() {
        boolean bl = false;
        boolean bl2 = false;
        cC = 216;
        cD = 216;
        a = Image.createImage((int)cC, (int)cD);
        b = a.getGraphics();
    }

    public final void b(int n, int n2) {
        int n3 = this.ar - this.ar % 24;
        int n4 = this.as - this.as % 24;
        int n5 = this.ar + cC - 24 - (this.ar + cC - 24) % 24;
        int n6 = this.as + cD - 24 - (this.as + cD - 24) % 24;
        int n7 = n * 24;
        int n8 = n2 * 24;
        if (n7 >= n3 && n7 <= n5 && n8 >= n4 && n8 <= n6) {
            int n9 = a[n][n2] & 0xFF;
            byte by = a[n][n2];
            if (by < 80) {
                if (n9 == 4 || n9 == 16 || n9 == 15) {
                    this.c(n, n2);
                    return;
                }
                k.a(b, a[8][0], n7 % cC, n8 % cD, 0);
            }
        }
    }

    public final void c(int n, int n2) {
        int n3 = this.ar - this.ar % 24;
        int n4 = this.as - this.as % 24;
        int n5 = this.ar + cC - 24 - (this.ar + cC - 24) % 24;
        int n6 = this.as + cD - 24 - (this.as + cD - 24) % 24;
        int n7 = n * 24;
        int n8 = n2 * 24;
        if (n7 >= n3 && n7 <= n5 && n8 >= n4 && n8 <= n6) {
            this.a(n7, n8, n7, n8, false);
        }
    }

    public static final int c(int n) {
        switch (n) {
            case 0: {
                return 42;
            }
            case 20: {
                return 43;
            }
            case 22: {
                k.a[45].m = 0;
                return 45;
            }
            case 23: {
                k.a[45].m = 1;
                return 45;
            }
            case 4: {
                return 56;
            }
            case 15: {
                k.a[57].m = 0;
                return 57;
            }
            case 14: {
                k.a[57].m = 1;
                return 57;
            }
            case 16: {
                return 58;
            }
            case 2: {
                k.a[59].m = 0;
                return 59;
            }
            case 3: {
                k.a[59].m = 1;
                return 59;
            }
            case 1: {
                return 60;
            }
        }
        return -1;
    }

    public final void a(int n, int n2, int n3, int n4, boolean bl) {
        Graphics graphics = null;
        int n5 = 0;
        int n6 = 0;
        graphics = b;
        int n7 = cC;
        int n8 = cD;
        n5 = n % n7;
        n6 = n2 % n8;
        this.bA = n6 - 24;
        this.bJ = n2 / 24 - 1;
        for (int i2 = n2; i2 <= n4; i2 += 24) {
            this.bz = n5 - 24;
            this.bI = n / 24 - 1;
            this.bA += 24;
            ++this.bJ;
            if (this.bA >= n8) {
                this.bA = 0;
            }
            for (int i3 = n; i3 <= n3; i3 += 24) {
                int n9;
                this.bz += 24;
                ++this.bI;
                if (this.bz >= n7) {
                    this.bz = 0;
                }
                if (this.bI < 0 || this.bI >= this.ax || this.bJ < 0 || this.bJ >= this.ay) continue;
                this.bK = a[this.bI][this.bJ];
                this.bL = a[this.bI][this.bJ] & 0xFF;
                if (this.bK < 80 && !bl) {
                    k.a(graphics, a[8][0], this.bz, this.bA, 0);
                }
                if (this.bL > -1 && this.bL < 38) {
                    switch (this.bL) {
                        case 4: {
                            this.aG = 20;
                            this.aH = 7;
                            this.bQ = 0;
                            this.bP = 0;
                            break;
                        }
                        case 27: {
                            this.aG = 21;
                            this.aH = 0;
                            this.bQ = 0;
                            this.bP = 0;
                            break;
                        }
                        case 15: {
                            if (this.cg != 0) break;
                            this.aG = 14;
                            this.aH = 0 + this.cg * 5 / 10;
                            break;
                        }
                        case 16: {
                            if (this.cg != 9) break;
                            this.aG = 15;
                            this.aH = 4 - this.cg * 5 / 10;
                            if (this.aH >= 0) break;
                            this.aH = 0;
                        }
                    }
                }
                if (this.aG != -1) {
                    if (a[this.aG] == null) {
                        a[k.c(this.aG)].a(graphics, this.aH, this.bz + this.bP, this.bA + this.bQ, this.bR, 0, 0);
                    } else {
                        k.a(graphics, a[this.aG][this.aH], this.bz + this.bP, this.bA + this.bQ, this.bR);
                    }
                    this.bR = 0;
                    this.aG = -1;
                    this.bQ = 0;
                    this.bP = 0;
                }
                if (this.bK != -1 && !bl) {
                    n9 = this.bK - 80;
                    if (n9 >= 0) {
                        this.aI = 0;
                        this.aJ = n9;
                    } else {
                        switch (this.bK) {
                            case 10: {
                                a[16].a(graphics, 0, this.bz, this.bA, 0, 0, 0);
                                break;
                            }
                            case 1: {
                                if (b[this.bI][this.bJ] != 0 || e != null && e[this.bI][this.bJ] != 0) break;
                                this.at();
                                this.aJ -= this.bT;
                                this.bQ = 0;
                                break;
                            }
                            case 0: {
                                if (b[this.bI][this.bJ] != 0 || e != null && e[this.bI][this.bJ] != 0) break;
                                this.at();
                                break;
                            }
                            case 34: {
                                if (this.cg != 9) break;
                                this.aI = 14;
                                this.aJ = 0 + this.cg * 5 / 10;
                                break;
                            }
                            case 35: {
                                if (this.cg != 0) break;
                                this.aI = 15;
                                this.aJ = 4 - this.cg * 5 / 10;
                                if (this.aJ >= 0) break;
                                this.aJ = 0;
                            }
                        }
                    }
                    if (this.aI != -1) {
                        if (a[this.aI] == null) {
                            a[k.c(this.aI)].a(graphics, this.aJ, this.bz + this.bP, this.bA + this.bQ, this.bR, 0, 0);
                        } else {
                            k.a(graphics, a[this.aI][this.aJ], this.bz + this.bP, this.bA + this.bQ, this.bR);
                        }
                        this.aI = -1;
                        this.bR = 0;
                        this.bQ = 0;
                        this.bP = 0;
                    }
                }
                if (this.i == 2) {
                    this.c(graphics);
                }
                if (this.bL < 20 || this.bL >= 26) continue;
                n9 = this.bL - 20;
                a[3].a(graphics, n9, 0, this.bz, this.bA, 0, 0, 0);
            }
        }
    }

    public final void b(Graphics graphics) {
        for (int i2 = -1; i2 < 9; ++i2) {
            for (int i3 = -1; i3 < 9; ++i3) {
                int n;
                this.bI = i3 + this.cI;
                this.bJ = i2 + this.cJ;
                if (this.bI < 0 || this.bI >= this.ax || this.bJ < 0 || this.bJ >= this.ay) continue;
                this.bK = a[this.bI][this.bJ];
                this.bL = a[this.bI][this.bJ] & 0xFF;
                this.bz = i3 * 24 - this.cK;
                this.bA = i2 * 24 - this.cL;
                this.O();
                if (this.bL > -1 && this.bL < 38) {
                    switch (this.bL) {
                        case 35: {
                            this.T();
                            break;
                        }
                        case 34: {
                            a[27].a(graphics, 2, 0, this.bz, this.bA, 0, 0, 0);
                            break;
                        }
                        case 14: 
                        case 33: {
                            this.k(this.bL);
                            break;
                        }
                        case 6: {
                            this.av();
                            if (this.bA + 24 >= 180) break;
                            graphics.clipRect(this.bz, this.bA, 24, 24);
                            break;
                        }
                        case 15: {
                            if (this.cg == 0 || this.cg > 5) break;
                            this.aG = 14;
                            this.aH = 0 + this.cg * 5 / 10;
                            break;
                        }
                        case 16: {
                            if (this.cg == 9 || this.cg < 5) break;
                            this.aG = 15;
                            this.aH = 4 - this.cg * 5 / 10;
                            if (this.aH >= 0) break;
                            this.aH = 0;
                            break;
                        }
                        case 7: {
                            this.aA();
                            break;
                        }
                        case 4: {
                            if (a[this.bI][this.bJ] >> 8 < this.az) break;
                            this.Y();
                            break;
                        }
                        case 5: 
                        case 28: {
                            this.aG = 11;
                            this.aH = 0;
                            break;
                        }
                        case 8: 
                        case 9: {
                            this.az();
                            break;
                        }
                        case 3: {
                            n = (a[this.bI][this.bJ] >> 8) - 1;
                            if (n < 0) break;
                            this.aG = 12;
                            this.aH = (byte)n;
                            break;
                        }
                        case 37: {
                            a[27].a(graphics, 2, 0, this.bz, this.bA, 0, 0, 0);
                            this.T();
                        }
                    }
                    if (this.aG != -1) {
                        if (a[this.aG] == null) {
                            a[k.c(this.aG)].a(graphics, this.aH, this.bz + this.bP, this.bA + this.bQ, this.bR, 0, 0);
                        } else {
                            k.a(graphics, a[this.aG][this.aH], this.bz + this.bP, this.bA + this.bQ, this.bR);
                        }
                        this.bR = 0;
                        this.aG = -1;
                        k.a(graphics, 0, -this.bm, 176, 180);
                        this.bQ = 0;
                        this.bP = 0;
                    } else if (b != null) {
                        if (this.bM != -1) {
                            b.a(graphics, this.bM, this.bN, this.bz + this.bP, this.bA + this.bQ, 0, 0, 0);
                            this.bM = -1;
                        }
                        b = null;
                        this.bQ = 0;
                        this.bP = 0;
                    }
                }
                if (this.bK == -1) continue;
                n = this.bK - 80;
                if (n < 0) {
                    int n2 = b[this.bI][this.bJ];
                    boolean bl = false;
                    switch (this.bK) {
                        case 49: {
                            this.au();
                            break;
                        }
                        case 48: {
                            this.R();
                            break;
                        }
                        case 21: {
                            this.U();
                            break;
                        }
                        case 46: {
                            this.V();
                            break;
                        }
                        case 45: {
                            this.aD();
                            break;
                        }
                        case 44: {
                            this.W();
                            this.bN = 0;
                            break;
                        }
                        case 12: {
                            this.X();
                            break;
                        }
                        case 36: {
                            this.ab();
                            break;
                        }
                        case 18: {
                            this.aa();
                            break;
                        }
                        case 34: {
                            if (this.cg == 9 || this.cg < 5) break;
                            this.aI = 14;
                            this.aJ = 0 + this.cg * 5 / 10;
                            break;
                        }
                        case 35: {
                            if (this.cg == 0 || this.cg > 5) break;
                            this.aI = 15;
                            this.aJ = 4 - this.cg * 5 / 10;
                            if (this.aJ >= 0) break;
                            this.aJ = 0;
                            break;
                        }
                        case 28: {
                            this.aF();
                            break;
                        }
                        case 16: {
                            this.aC();
                            break;
                        }
                        case 14: {
                            this.aB();
                            break;
                        }
                        case 32: {
                            this.ay();
                            break;
                        }
                        case 11: {
                            this.ax();
                            break;
                        }
                        case 30: {
                            b = a[20];
                            this.bM = 0;
                            this.bN = 0 + (n2 - 1) * 7 / 16;
                            break;
                        }
                        case 37: {
                            this.aI = 17;
                            this.aJ = 0 + (n2 - 1) * 3 / 8;
                            break;
                        }
                        case 23: {
                            b = a[12];
                            this.bN = 0;
                            this.b((byte)23);
                            break;
                        }
                        case 22: {
                            b = a[12];
                            this.bN = 1;
                            this.b((byte)22);
                            break;
                        }
                        case 43: {
                            this.c((byte)this.bK);
                            break;
                        }
                        case 19: {
                            this.c((byte)this.bK);
                            break;
                        }
                        case 10: {
                            break;
                        }
                        case 47: {
                            this.at();
                            break;
                        }
                        case 9: {
                            this.at();
                            if ((b[this.bI][this.bJ] & 0xFC00000) != 0x8400000) break;
                            this.bP += this.aj;
                            this.bQ += this.ak;
                            break;
                        }
                        case 4: {
                            break;
                        }
                        case 5: {
                            break;
                        }
                        case 2: {
                            break;
                        }
                        case 1: {
                            if ((b[this.bI][this.bJ] & Integer.MIN_VALUE) == 0 && this.bT == 0) break;
                            this.at();
                            break;
                        }
                        case 0: {
                            if ((b[this.bI][this.bJ] & Integer.MIN_VALUE) == 0) break;
                            this.at();
                            break;
                        }
                        case 6: {
                            break;
                        }
                        case 7: {
                            break;
                        }
                        case 8: {
                            this.at();
                        }
                    }
                }
                if (this.aI != -1) {
                    if (a[this.aI] == null) {
                        a[k.c(this.aI)].a(graphics, this.aJ, this.bz + this.bP, this.bA + this.bQ, this.bR, 0, 0);
                    } else {
                        k.a(graphics, a[this.aI][this.aJ], this.bz + this.bP, this.bA + this.bQ, this.bR);
                    }
                    this.aI = -1;
                    this.bR = 0;
                    this.bQ = 0;
                    this.bP = 0;
                    continue;
                }
                if (b == null) continue;
                if (this.bI == this.cq && this.bJ == this.cr) {
                    c = b;
                    this.cv = this.bM;
                    this.cu = this.bN;
                    this.ct = this.bz + this.bP;
                    this.cs = this.bA + this.bQ;
                }
                if (this.bM != -1) {
                    b.a(graphics, this.bM, this.bN, this.bz + this.bP, this.bA + this.bQ, this.bO, 0, 0);
                    this.bM = -1;
                } else {
                    b.a(graphics, this.bN, this.bz + this.bP, this.bA + this.bQ, this.bO, 0, 0);
                }
                b = null;
                this.bO = 0;
                this.bQ = 0;
                this.bP = 0;
            }
        }
    }

    public final void O() {
        k.a(a, 0, 0, 176, 180);
    }

    public final void P() {
        int n;
        int n2;
        Graphics graphics = a;
        int n3 = aP;
        this.bS = (this.aU & 0x1000) == 0 ? this.k : (byte)0;
        this.bm = 0;
        this.O();
        if (this.bl > 0) {
            this.bm = this.bl * n3 % ((this.bl >> 1) + 1) % 12;
        }
        if (this.bm > this.as) {
            this.bm = this.as;
        }
        this.as -= this.bm;
        this.cI = this.ar / 24;
        this.cJ = this.as / 24;
        this.cK = this.ar % 24;
        this.cL = this.as % 24;
        this.bT = (n3 & 0x3F) >> 1;
        if (this.bT >= 4) {
            this.bT = 0;
        }
        int n4 = this.ar - this.cK;
        int n5 = this.as - this.cL;
        int n6 = this.ar + cC - 24 - (this.ar + cC - 24) % 24;
        int n7 = this.as + cD - 24 - (this.as + cD - 24) % 24;
        if (cE == -1) {
            this.a(n4, n5, n6, n7, false);
            cE = n4;
            cF = n6;
            cG = n5;
            cH = n7;
        }
        if (cE != n4) {
            if (cE < n4) {
                n2 = cF + 24;
                n = n6;
            } else {
                n2 = n4;
                n = cE - 24;
            }
            this.a(n2, n5, n, n7, false);
            cE = n4;
            cF = n6;
        }
        if (cG != n5) {
            if (cG < n5) {
                n2 = cH + 24;
                n = n7;
            } else {
                n2 = n5;
                n = cG - 24;
            }
            this.a(n4, n2, n6, n, false);
            cG = n5;
            cH = n7;
        }
        this.a(graphics);
        this.O();
        this.b(graphics);
        if (E) {
            graphics.setColor(0);
            graphics.fillRect(0, 0, 176, 208);
            this.as();
            if (a != null) {
                k.a(graphics, a, cM, cN, cO);
            }
            if (this.S != this.T) {
                for (n4 = this.S; n4 != this.T; n4 &= 7) {
                    n5 = a[n4 << 1] * 24 - this.ar;
                    n6 = a[(n4 << 1) + 1] * 24 - this.as;
                    if (c[n4] < 0) {
                        b b2 = a[2];
                        b2.a(graphics, 0, this.a(b2, 0, (int)b[n4]), n5, n6, 0, 0, 0);
                    } else {
                        a[9].a(graphics, c[n4], b[n4], n5, n6, 0, 0, 0);
                    }
                    ++n4;
                }
            }
            k.a(a, 0, 0, 176, 208);
            this.Z();
            return;
        }
        this.as();
        if (this.k) {
            this.d(this.cK, this.cL);
        }
        if (a != null) {
            k.a(graphics, a, cM, cN, cO);
        }
        if (this.al > 0) {
            this.Q();
        }
        if (this.i != 0) {
            this.aj();
        }
        for (n4 = -1; n4 < 9; ++n4) {
            for (n5 = -1; n5 < 9; ++n5) {
                int n8;
                n2 = n5 + this.cI;
                n = n4 + this.cJ;
                if (n2 < 0 || n2 >= this.ax || n < 0 || n >= this.ay) continue;
                n6 = a[n2][n] & 0xFF;
                n7 = a[n2][n];
                if (n6 >= 38 && n6 < 80) continue;
                boolean bl = false;
                int n9 = n5 * 24 - this.cK;
                int n10 = n4 * 24 - this.cL;
                switch (n6) {
                    case 36: {
                        n8 = (a[n2][n] >> 8) - 1;
                        n8 = (0 + n8 * 7) / 16;
                        a[20].a(graphics, 0, n8, n9, n10, 0, 0, 0);
                        break;
                    }
                    case 31: {
                        int n11 = a[n2][n] >> 8;
                        b b3 = a[15];
                        int n12 = (aP >> 1) % (b3.e[n11] & 0xFF);
                        b3.a(a, n11, n12, n9, n10, 0, 0, 0);
                        break;
                    }
                    case 32: {
                        a[16].a(a, 0, a[n2][n] >> 8 & 0xFF, n9, n10, 0, 0, 0);
                        break;
                    }
                    default: {
                        byte by = (byte)(n6 - 80);
                        if (by < 0) break;
                        a[42].a(graphics, by, n9, n10, 0, 0, 0);
                    }
                }
                n8 = (a[n2][n] & 0xF0000000) >> 28;
                if (n8 > 0) {
                    a[13].a(graphics, 0, n8, n9, n10, 0, 0, 0);
                }
                if (n7 != 54) continue;
                a[7].a(graphics, 0, this.a(a[7], 0, b[n2][n]), n9, n10, 0, 0, 0);
            }
        }
        if (this.z) {
            n4 = (this.bD - this.cI) * 24 - this.cK + this.bB;
            n5 = (this.bE - this.cJ + 1) * 24 - this.cL + this.bC;
            k.a(graphics, k.a[13].a[0][0 + this.bF], n4, n5, 0);
            this.z = false;
        }
        if (this.aA != -1) {
            k.a(graphics, a[13][0], this.bx + -12, this.by + -24 + 2, 3);
            k.a(graphics, a[this.aA][this.aB], this.bx + -12, this.by + -24, 3);
        }
        if (this.S != this.T) {
            for (n4 = this.S; n4 != this.T; n4 &= 7) {
                n5 = a[n4 << 1] * 24 - this.ar;
                n6 = a[(n4 << 1) + 1] * 24 - this.as;
                if (c[n4] < 0) {
                    b b4 = a[2];
                    b4.a(graphics, 0, this.a(b4, 0, (int)b[n4]), n5, n6, 0, 0, 0);
                } else {
                    a[9].a(graphics, c[n4], b[n4], n5, n6, 0, 0, 0);
                }
                ++n4;
            }
        }
        this.as += this.bm;
        if (this.w) {
            this.a(graphics, a[41], a[40], 88, 104, 17, 19, false);
        }
        if (this.bp > aP && this.i != 2) {
            if (!this.ah && !this.g) {
                n4 = this.bp - aP;
                n5 = n4 < 13 ? (n4 - 6) * 176 / 13 : (n4 >= 33 ? (39 - n4) * 176 / 9 : 88);
                n6 = 176 - n5;
                this.a(graphics, a[41], a[b[this.ap]], n5, 15, 17, 20, false);
                this.a(graphics, a[41], a[g[this.ap][this.aq]], n6, 40, 17, 20, false);
                if (this.P > 0) {
                    this.a(graphics, a[41], this.d, 88, 125, 17, 5, true);
                }
            }
        } else if (this.Z > aP && this.q <= 2) {
            this.a(graphics, a[41], a[36], 88, 133, 17, 20, false);
        } else if (this.Z == aP && this.q <= 2) {
            this.q = (byte)(this.q + 1);
            this.D();
        }
        switch (this.i) {
            case 4: {
                this.an();
                break;
            }
            case 3: {
                if (this.ad == -1 || this.ad == 15) break;
                this.b(graphics, 5);
                break;
            }
            case 5: {
                if (this.ad == -1 || this.ad == 15 || this.ad == 13 || this.ad == 12) break;
                this.b(graphics, 4);
            }
        }
        k.a(graphics, 0, 0, 176, 208);
        if (this.a == null) {
            this.Z();
        }
        if (this.e != null) {
            this.n = true;
            this.a(graphics, a[41], this.e, 88, 163, 33, 4, true);
        }
        if (this.a != null && !E) {
            this.n = true;
            this.a.a(graphics);
        }
        if (this.bn > 0) {
            this.n = true;
            graphics.setColor(0);
            graphics.fillRect(0, 0, 176, this.bn);
            graphics.fillRect(0, 208 - this.bn, 176, this.bn);
            this.as();
            if (a != null) {
                k.a(graphics, a, cM, cN, cO);
            }
            if (c != null) {
                if (this.cv != -1) {
                    c.a(graphics, this.cv, this.cu, (this.cq - this.cI) * 24 - this.cK, (this.cr - this.cJ) * 24 - this.cL, this.bO, 0, 0);
                    return;
                }
                c.a(graphics, this.cu, this.ct, this.cs, this.bO, 0, 0);
            }
        }
    }

    public final void Q() {
        int n = this.as - 24;
        int n2 = this.as + 208;
        int n3 = this.ar;
        int n4 = this.ar + 176;
        int n5 = (aP >> 1) % a[2].a(1);
        for (int i2 = 0; i2 < e.length; i2 += 3) {
            byte by = 0;
            byte by2 = e[i2 + 2];
            int n6 = by2 * 24;
            if (n6 <= n || n6 >= n2) continue;
            byte by3 = e[i2 + 0];
            byte by4 = e[i2 + 1];
            int n7 = by3 * 24;
            int n8 = by4 * 24 + 24;
            if (!(n7 >= n3 && n7 <= n4 || n8 >= n3 && n8 <= n4) && (n7 > n3 || n8 < n4)) continue;
            int n9 = n7 - n3;
            int n10 = by3 + (by3 != 0 ? -1 : 0);
            boolean bl = true;
            if (a[n10][by2] == 48 && (b[n10][by2] & 8) != 0) {
                n9 -= 12;
                bl = false;
                if ((b[n10][by2 + 1] & 7) == 3) {
                    by = -b[n10][by2 + 1];
                } else {
                    n9 -= -b[n10][by2 + 1];
                }
            }
            int n11 = n8 - n3;
            n10 = by4 + (by4 < this.ax - 1 ? (byte)1 : 0);
            boolean bl2 = true;
            if (a[n10][by2] == 48 && (b[n10][by2] & 8) != 0) {
                n11 += 12;
                bl2 = false;
                if ((b[n10][by2 + 1] & 7) == 3) {
                    by = -b[n10][by2 + 1];
                } else {
                    n11 += -b[n10][by2 + 1];
                }
            }
            int n12 = n6 - this.as + 10 + by;
            a.setColor(1820159);
            a.drawLine(n9, n12, n11, n12);
            a.drawLine(n9, n12 += 2, n11, n12);
            a.setColor(14153215);
            a.drawLine(n9, --n12, n11, n12);
            if (bl) {
                a[2].a(a, 1, n5, n9, n12, b.a, 0, 0);
                continue;
            }
            if (!bl2) continue;
            a[2].a(a, 1, n5, n11, n12, 0, 0, 0);
        }
    }

    public final void R() {
        int n = b[this.bI][this.bJ];
        if ((n & 8) == 0) {
            b = a[32];
            int n2 = n & 7;
            boolean bl = (n & 0x10) == 0;
            this.bN = bl && n2 == 2 || !bl && n2 == 4 ? 2 : (bl ? 1 : 0);
            byte by = b[this.bI][this.bJ];
            this.bP = by * g[n2];
            this.bQ = by * g[n2 + 8];
        }
    }

    public final void S() {
        if ((b[this.bI][this.bJ] & 7) == 1 && (a[this.bI][this.bJ] & 0xFF) == 35) {
            this.bP = 0;
            this.bQ = b[this.bI][this.bJ];
        }
    }

    public final void T() {
        b = a[30];
        this.bM = 1;
        this.bN = this.a(b, 1, aP % this.a(b, 1));
    }

    public final void U() {
        int n = b[this.bI][this.bJ] & 7;
        b = a[29];
        if ((b[this.bI][this.bJ] & 8) == 0) {
            switch (n) {
                case 1: {
                    this.bN = 2;
                    break;
                }
                case 2: {
                    this.bN = 1;
                    break;
                }
                case 4: {
                    this.bN = 0;
                }
            }
            this.bP = b[this.bI][this.bJ] * g[n];
            this.bQ = b[this.bI][this.bJ] * g[8 + n];
            return;
        }
        switch (n) {
            case 1: {
                this.bM = 14;
                break;
            }
            case 2: {
                this.bM = 13;
                break;
            }
            case 4: {
                this.bM = 12;
            }
        }
        this.bN = this.a(b, this.bM, (int)b[this.bI][this.bJ]);
        int n2 = (k.b.b[this.bM] + this.bN) * 5;
        this.bP = k.b.f[n2 + 2];
        this.bQ = k.b.f[n2 + 3];
    }

    public final void V() {
        int n;
        b = a[29];
        this.bM = b[this.bI][this.bJ] & 0x1F;
        if (this.bM == 8 || this.bM == 9) {
            this.bN = 0;
            int n2 = (k.b.b[this.bM] + 0) * 5;
            this.bP = k.b.f[n2 + 2];
            this.bQ = -b[this.bI][this.bJ];
            return;
        }
        int n3 = (b[this.bI][this.bJ] & 0x1FE0) >> 5;
        this.bN = n = this.a(b, this.bM, n3);
        int n4 = (k.b.b[this.bM] + n) * 5;
        this.bP = k.b.f[n4 + 2];
        this.bQ = k.b.f[n4 + 3];
    }

    public final void W() {
        this.bM = (b[this.bI][this.bJ] & 0x38) >> 3;
        b = a[27];
        switch (this.bM) {
            case 3: {
                this.bN = 0;
                this.bQ = -b[this.bI][this.bJ];
                return;
            }
            case 1: {
                this.bN = (b[this.bI][this.bJ] >> 1) % a[27].a(1);
                return;
            }
        }
        this.bN = b[this.bI][this.bJ];
    }

    public final void X() {
        f[] fArray = a[18];
        k.a(a, fArray[0], this.bz, this.bA, 0);
        int n = 0;
        if (this.P < 10) {
            n = k.a[0].a[0][0].a >> 1;
            ++n;
        }
        this.a(a, this.bz + 19 - n, this.bA + 13, this.P, k.a[0].a[0], 0);
    }

    public final void d(int n, int n2) {
        Graphics graphics = a;
        for (int i2 = 0; i2 < 9; ++i2) {
            for (int i3 = 0; i3 < 9; ++i3) {
                int n3 = i3 + this.ar / 24;
                int n4 = i2 + this.as / 24;
                if (n3 < 0 || n3 >= this.ax || n4 < 0 || n4 >= this.ay) continue;
                int n5 = e[n3][n4];
                Object var9_9 = null;
                int n6 = i3 * 24 - n;
                int n7 = i2 * 24 - n2;
                byte by = 0;
                if (n5 <= 0) continue;
                for (int n8 = 0; n8 <= 2; n8 = (byte)(n8 + 1)) {
                    int n9;
                    int n10;
                    int n11;
                    if (this.a(n5, (byte)n8, (byte)0, (byte)3) == 0) continue;
                    by = (byte)(this.a(n5, (byte)n8, (byte)7, (byte)2) << 3);
                    if (by > 0) {
                        n11 = this.a(n5, (byte)n8, (byte)0, (byte)3);
                        n10 = this.a(n11, (byte)45, (byte)2);
                        by = n10 <= 1 ? (by = (byte)(by - 24)) : (byte)(24 - by);
                        this.O();
                        graphics.clipRect(n6, n7 + (n8 << 3), 24, 8);
                    }
                    int n12 = n9 = (n10 = (n11 = this.a(n3, n4, n5, (byte)n8)) >> 1) == 7 ? aP >> 3 & 1 : aP & 1;
                    if (n10 == 15) {
                        d.a(graphics, n11 + this.cB, n6 + by - 8, n7 + (n8 << 3) + 8, 36, 0, 0);
                        ++this.cB;
                        if (this.cB <= 2) continue;
                        this.cB = 0;
                        continue;
                    }
                    if (n10 == 14 || n10 == 11) {
                        d.a(graphics, n11 + n9, n6 + by, n7, 20, 0, 0);
                        this.O();
                        continue;
                    }
                    if (n10 == 8 && n8 == 0 && e[n3][n4 - 1] > 0) {
                        d.a(graphics, 33, n6 + by, n7, 20, 0, 0);
                        n8 = 3;
                        continue;
                    }
                    d.a(graphics, n11 + n9, n6 + by, n7 + (n8 << 3), 20, 0, 0);
                    this.O();
                }
            }
        }
    }

    public final void Y() {
        this.aG = 20;
        if (a[this.bI][this.bJ] >> 8 >= this.az) {
            this.aH = 0 + (aP >> 1) % 7;
            return;
        }
        this.aH = 7;
    }

    public final void k(int n) {
        int n2;
        int n3 = a[this.bI][this.bJ] >> 8;
        if (n3 == 255) {
            n3 = 0;
        }
        int n4 = n2 = 14 == n ? 8 : 22;
        if (a[n2] != null) {
            a[n2].a(a, 0, n3, this.bz, this.bA, 0, 0, 0);
        }
    }

    public final void Z() {
        int n;
        Object object;
        boolean bl = false;
        Graphics graphics = a;
        b b2 = a[0];
        k.a(graphics, 88, 208);
        if (this.n || l == 2) {
            object = a[0];
            if (object != null) {
                object.a(graphics, 0, 0, 0, 0, 0, 0);
                if (this.S) {
                    object.a(graphics, 19, 0, 0, 0, 0, 0);
                }
            }
            b2.a(graphics, 1, 0, 0, 0, 0, 0);
        } else {
            b2.a(graphics, 1, 0, 0, 0, 0, 0);
        }
        if (this.o) {
            b2.a(graphics, 2, 0, 0, 0, 0, 0);
            b2.a(graphics, 3 + this.ac, 0, 0, 0, 0, 0);
            this.cP = this.ac;
        }
        if (this.m != this.cQ || this.n || this.m <= 1) {
            object = k.a[0].a[0];
            n = 0;
            int n2 = this.m <= 1 ? 1 : 0;
            k.a(graphics, object[11 + n2], -17, -20, 0);
            n = 0 + object[11 + n2].a;
            int n3 = object[15].a;
            for (int i2 = 0; i2 < i[8]; ++i2) {
                if (this.m == 1 && i2 == 0 && (aP >> 2 & 1) == 0 || i2 < this.m && this.m > 1) {
                    k.a(graphics, object[15 + n2], -17 + n, -20, 0);
                } else {
                    k.a(graphics, object[13 + n2], -17 + n, -20, 0);
                }
                n += n3;
            }
            k.a(graphics, object[17 + n2], -17 + n, -20, 0);
            this.cQ = this.m;
        }
        if (this.cR != this.bb || this.cU != this.P || this.n) {
            this.cR = this.bb;
            this.cU = this.P;
            if (this.P > 0) {
                this.a(graphics, 56, -10, "" + this.bb + "/" + (this.P + this.bb), k.a[0].a[0], 0);
            } else {
                this.a(graphics, 56, -10, this.bb, k.a[0].a[0], 0);
            }
        }
        if (this.cS != this.bd || this.n) {
            this.cS = this.bd;
            this.a(graphics, 77, -10, this.bd, k.a[0].a[0], 0);
        }
        if (this.cT != this.ao || this.n) {
            this.cT = this.ao;
            this.a(graphics, -20, -10, this.ao, k.a[0].a[0], 0);
        }
        k.a(graphics, -88, -208);
        if (this.P > 0) {
            this.i = System.currentTimeMillis();
        } else if (System.currentTimeMillis() - this.i < 1500L) {
            k.a(graphics, 0, 0, 176, 208);
            this.a(graphics, a[41], a[34], 88, 133, 33, 5, true);
        }
        k.a(graphics, 0, 0, 176, 208);
        object = null;
        n = 0;
        if (this.aW > 0) {
            object = a[24][0];
            n = this.aW;
        } else if (this.aX > 0) {
            object = a[25][0];
            n = this.aX;
        }
        if (n > 0) {
            k.a(graphics, (f)object, 128, 156, 0);
            this.a(graphics, 160, 166, n, k.a[0].a[0], 0);
        }
        this.n = false;
    }

    public final void aa() {
        b = a[6];
        this.bM = 0;
        if (this.cg == 0) {
            this.bN = 0;
            return;
        }
        if (this.cg == 9) {
            this.bN = 2;
            return;
        }
        this.bN = this.ch < 0 ? 1 : 3;
    }

    public final void ab() {
        int n = b[this.bI][this.bJ] == 1 ? 1 : 0;
        b b2 = a[5];
        b2.a(a, n, (aP >> 1) % b2.a(n), this.bz, this.bA, 0, 0, 0);
    }

    public final void b(byte by) {
        i i2 = a[4];
        if (by == 23) {
            i2.a = this.bz;
            i2.e |= b.a;
        } else {
            i2.e &= ~b.a;
            i2.a = this.bz + 24;
        }
        i2.b = this.bA;
        i2.a();
        i2.a(a);
    }

    public final void l(int n) {
        switch (n) {
            case 0: {
                this.cE();
                System.gc();
                return;
            }
            case 1: {
                return;
            }
            case 2: {
                k.a[41].p = 11;
                return;
            }
            case 3: {
                this.a.c(4);
                return;
            }
            case 4: {
                return;
            }
            case 5: {
                return;
            }
            case 6: {
                if (a[19] != null) break;
                k.a[19] = k.a("/spl.f", 0);
                return;
            }
            case 7: {
                if (a[18] != null) break;
                k.a[18] = k.a("/ui.f", 3);
            }
        }
    }

    public final void ac() {
        k.a(a[19], true);
        k.a[19] = null;
        c = null;
        b = null;
        d = null;
        System.gc();
    }

    public final void ad() {
        this.cW = a[this.bq].length >> 1;
        this.cX = 0;
        for (int i2 = 0; i2 < this.cW; ++i2) {
            int n = k.a(a[41], a[a[this.bq][i2 * 2 + 1]], 0);
            if (this.bq == 0 && i2 == 3 || n <= this.cX) continue;
            this.cX = n;
        }
        this.db = 0;
        this.cV = 0;
    }

    public final void e(int n, int n2) {
        if (l == 4) {
            this.a(a, 0);
            for (int i2 = n - 1; i2 < n2 - 2; ++i2) {
                a[18].a(a, 4, i2 % 2, i2, 0, 0, 0);
            }
        }
        if (l == 2) {
            a.setColor(0);
            a.fillRect(0, n - 1, 176, n2 - 2 - (n - 1));
        }
        a.setColor(0xFFFFFF);
        a.drawLine(0, n - 1, 176, n - 1);
        a.drawLine(0, n2 - 1, 176, n2 - 1);
        a.setColor(0);
        a.drawLine(0, n - 1 - 1, 176, n - 1 - 1);
        a.drawLine(0, n2 - 2, 176, n2 - 2);
    }

    public final void ae() {
        this.W = false;
        this.V = this.a();
    }

    public final void af() {
        int n;
        int n2;
        int n3;
        int n4;
        if (this.W) {
            this.ae();
        }
        int n5 = 208 - (this.cW * 11 + 1 + 2);
        n5 += !this.V && this.bq == 0 ? 11 : 0;
        int n6 = 208;
        k.a(a, 0, 0, 176, 208);
        if (l == 2 && T && U) {
            this.S = false;
            this.P();
            this.S = true;
            U = false;
        }
        if (l == 7 || l == 2) {
            n4 = n5 - (104 - (208 - n5) / 2);
            n5 -= n4;
            n6 = 208 - n4;
        }
        if (this.bq == 7) {
            a[41].a(a, a[this.aO == 5 ? 102 : 113], 88, n5 - 15, 17);
        }
        if (l == 7) {
            if (this.de != -1 && !T) {
                n4 = n5 + this.de * 11;
                a.setColor(0);
                a.fillRect(0, n4, 176, 12);
            } else {
                a.setColor(0);
                a.fillRect(0, 0, 176, 208);
            }
        }
        long l = System.currentTimeMillis();
        if (this.dd >= 0 && l - this.j > 100L) {
            ++this.dd;
            this.j = l;
        }
        if (this.de != -1 && !T) {
            n3 = this.bq == 0 && this.de > 1 && !this.V ? 11 : 0;
            n2 = n5 + this.de * 11 - n3;
            k.a(a, 0, n2, 176, 12);
        }
        if (this.de != this.bs || T) {
            this.e(n5, n6);
        }
        for (n3 = 0; n3 < this.cW; ++n3) {
            int n7;
            if (this.de != -1 && n3 != this.de && n3 != this.bs && !T || this.bq == 0 && n3 == 1 && !this.V) continue;
            n2 = n5 + n3 * 11;
            n = n2 + 5;
            if (this.bq == 0 && n3 > 1 && !this.V) {
                n2 -= 11;
                n -= 11;
            }
            int n8 = 0;
            if (n3 == 2 && this.bq == 0) {
                n8 = 1;
            }
            if (this.i == 2 && n3 == 4 && this.bq == 1) {
                n8 = 0;
                if (n3 == this.bs) {
                    a.setColor(0x666666);
                    a.fillRect(0, n - 5, 176, 12);
                } else {
                    a.setColor(0xCCCCCC);
                    a.fillRect(0, n - 5 + 1, 176, 10);
                }
            } else if (n3 == this.bs) {
                a.setColor(13540096);
                a.fillRect(0, n - 5, 176, 12);
            }
            int n9 = 0;
            boolean bl = false;
            a[41].a(a[a[this.bq][n3 * 2 + 1]]);
            int n10 = n7 = b.n;
            int n11 = n3 == 2 && this.bq == 0 ? 114 : 146;
            if (n7 > n11) {
                bl = true;
                n7 = n11;
            }
            int n12 = 88 - n7 / 2;
            if (bl) {
                n9 = n3 == this.bs ? this.cZ : 0;
                k.a(a, n12, n2, n7, 11);
            }
            k.a[41].m = n8;
            a[41].a(a, a[a[this.bq][n3 * 2 + 1]], 88 - n7 / 2 - n9, n + 1, 6);
            if (bl) {
                k.a(a, 0, 0, 176, 208);
            }
            if (n3 == this.bs) {
                a.setColor(0xFFFFFF);
                a[18].a(a, 2, 88 - n7 / 2 - 8, n, 0, 0, 10);
                a[18].a(a, 2, 88 + n7 / 2 + 8, n, 0, 0, 6);
            }
            if (n3 != this.bs || !bl || this.cV % 2 != 0) continue;
            this.cZ += this.cY;
            if (this.cZ >= -5 && this.cZ + n11 - 5 <= n10) continue;
            this.cY = -this.cY;
            this.cZ += this.cY;
        }
        this.de = this.bs;
        ++this.cV;
        this.dc = this.dc < 0 ? 3 : --this.dc;
        if (this.dc == 0 && this.db + 1 < this.cW) {
            ++this.db;
        }
        k.a(a, 0, 0, 176, 208);
        if (this.bq == 0 && this.aj) {
            n3 = this.cV % 20;
            if (n3 >= 10) {
                a[18].a(a, 1, 1, n5 + 22 + 5 - (this.V ? 0 : 11), 0, 0, 6);
            } else if (this.bs != 2) {
                if (b == null) {
                    n2 = n5 + 22 + 1 - (this.V ? 0 : 11);
                    b = Image.createImage((int)24, (int)10);
                    c = b.getGraphics();
                    k.a(c, -1, -n2);
                    this.a(c, 0);
                    k.a(c, 1, n2);
                    for (n = 0; n < 10; ++n) {
                        a[18].a(c, 4, (n2 + n + 1) % 2, n, 0, 0, 0);
                    }
                }
                k.a(a, b, 1, n5 + 22 + 1 - (this.V ? 0 : 11), 0);
            }
        }
        if (this.bq != 0 && this.bq != 3 && this.bq != 1 && this.bq != 7) {
            this.ag();
        }
        this.ah();
        T = false;
        if (this.dd == 2) {
            if (k.l == 2) {
                T = true;
                U = true;
            }
            this.dd = -1;
            this.n = true;
            this.de = -1;
            this.j();
        }
    }

    public final void ag() {
        a[18].a(a, 0, 171 - this.da, 196, 0, 0, 0);
    }

    public final void ah() {
        a[18].a(a, 3, 2, 197, 0, 0, 0);
    }

    public final void ai() {
        Graphics graphics = a;
        graphics.setColor(0);
        graphics.fillRect(0, 0, 176, 208);
        int n = (this.bu + 1) * 166 / this.bt;
        if (n > 166) {
            n = 166;
        }
        graphics.setColor(13540096);
        a.fillRect(5, 198, n, 6);
        graphics.setColor(16554500);
        a.drawRoundRect(4, 197, 167, 6, 2, 2);
        k.a[41].m = 0;
        a[41].a(a, a[37], 88, 181, 1);
    }

    public final void aj() {
        switch (this.i) {
            case 2: {
                this.aq();
                this.ak();
                return;
            }
            case 1: {
                this.ap();
                return;
            }
            case 3: {
                this.am();
                return;
            }
            case 4: {
                this.ao();
                return;
            }
            case 5: {
                this.al();
            }
        }
    }

    public final void ak() {
        if (this.ar + 176 > 1440 && this.as + 208 > 48) {
            if (a[10] == null) {
                k.a[10] = k.a("/mmv.f", 0);
            }
            b b2 = a[10];
            if (this.d(60, 3) || this.d(61, 3)) {
                b2.a(a, 1, 1440 - this.ar, 48 - this.as, 0, 0, 0);
            }
        }
        if (this.aR > 55 && this.d) {
            a[0].a(a);
        }
    }

    public final void c(Graphics graphics) {
        if (a[10] == null) {
            k.a[10] = k.a("/mmv.f", 0);
        }
        if (this.bI >= 60 && this.bI < 65 && this.bJ >= 2 && this.bJ < 7) {
            a[10].a(graphics, 4 + (this.bJ - 2) * 5 + this.bI - 60, this.bz, this.bA, 0, 0, 0);
        }
    }

    public final void al() {
        if (this.ad != -1) {
            i i2 = a[5];
            a[5].a = this.ai - this.ar;
            i2.b = 504 - this.as;
            i2.a();
            i2.a(a);
            if (this.ad == 12) {
                int n = this.ai - this.ar + aP * this.ae % 48;
                int n2 = k.a[5].b + 24;
                a[7].a(a, 0, aP % a[7].a(1), n, n2, 0, 0, 0);
                this.j(n, n2);
            }
        }
    }

    public final void am() {
        int n;
        if (this.i == 3 && (long)aP >= this.n + 52L) {
            for (n = 14; n <= 21; ++n) {
                k.b[n][15] = 0;
                k.a[n][15] = -1;
                k.a[n][15] = 44;
                k.b[n][15] = 0;
                k.c[n][15] = 24;
            }
            this.n = 0L;
        }
        if (this.ad != 15) {
            if (this.ar + 176 + 48 >= this.ah && this.as + 208 + 48 >= 504) {
                i i2 = a[5];
                a[5].a = this.ah - this.ar;
                i2.b = 504 - this.as;
                i2.a();
                i2.a(a);
            }
            if (this.ad == 12) {
                n = this.ah - this.ar + aP * this.ae % 48;
                int n2 = k.a[5].b + 24;
                a[7].a(a, 0, aP % a[7].a(0), n, n2, 0, 0, 0);
                this.j(n, n2);
            }
        }
    }

    public final void an() {
        Graphics graphics = a;
        i i2 = a[5];
        if (this.ad == 7) {
            int n = i2.a + aP * this.ae % 48;
            int n2 = i2.b;
            if (this.H == 10) {
                n2 -= 144;
            }
            a[7].a(graphics, 1, aP % a[7].a(1), n, n2, 0, 0, 0);
            this.j(n, n2);
            return;
        }
        if (this.ad != 8 && this.ad != 0) {
            this.b(graphics, 3);
        }
    }

    public final void b(Graphics graphics, int n) {
        int n2 = n * 14 + 2;
        int n3 = 176 - n2 >> 1;
        if (this.af > 0) {
            graphics.setColor(0);
            graphics.fillRect(n3, 5, n2, 12);
            graphics.setColor(3913615);
            for (int i2 = 0; i2 < this.af; ++i2) {
                graphics.fillRect(n3 + 2 + i2 * 14, 7, 12, 8);
            }
        }
    }

    public final void ao() {
        int n;
        int n2;
        Graphics graphics = a;
        i i2 = a[5];
        i i3 = a[4];
        switch (this.ad) {
            case 1: {
                n2 = this.ae * 1;
                break;
            }
            case 2: 
            case 7: {
                n2 = 40;
                break;
            }
            case 3: {
                n2 = 40;
                break;
            }
            case 4: {
                n2 = 40 - (this.ae * 2 << 1);
                break;
            }
            case 5: {
                n2 = 15 + this.ae * 18;
                this.X = false;
                break;
            }
            case 9: {
                n2 = 15 + this.ae * 18;
                break;
            }
            case 10: {
                n2 = 15 + this.ae * 18;
                break;
            }
            case 11: {
                n2 = 15 + this.ae * 18;
                break;
            }
            default: {
                n2 = -1000;
            }
        }
        i2.a = (10 + this.ag * (2 + (this.ag > 0 ? 1 : 0))) * 24 - this.ar;
        if (this.ad == 5) {
            n = i2.b;
            i2.b = 256 - this.as - this.I - 15;
            if (this.g() == 3) {
                i2.b = n;
            }
        } else {
            i2.b = 256 - n2 - this.as;
        }
        i2.a(graphics);
        if (this.j) {
            i3.b = 96 - this.as;
            i3.a = (this.f() + 1) * 24 - this.ar;
            i3.a(graphics);
        }
        for (n = 0; n < 3; ++n) {
            int n3 = (n * (2 + (n > 0 ? 1 : 0)) + 10) * 24 - this.ar;
            if (n3 >= 176 || n3 <= -48 || this.as <= 32) continue;
            a[40].a(graphics, 1, n3, 216 - this.as, 0, 0, 0);
        }
    }

    public final void ap() {
        int n;
        int n2 = aP;
        i i2 = a[2];
        boolean bl = false;
        boolean bl2 = false;
        if (this.as + this.bm < 1008 && this.as + this.bm > 704) {
            i2.a = 240 - this.ar;
            i2.b = 1008 - this.as;
            i2.a();
            i2.a(a);
            i2.a = 336 - this.ar;
            i2.b = 1008 - this.as;
            i2.a();
            i2.e = b.a;
            i2.a(a);
        }
        if (this.bl > 10) {
            this.cG();
        }
        int n3 = this.ay * 24 - this.aa - this.as;
        int n4 = n = 168 - this.ar;
        int n5 = n + 240;
        while (n <= -24) {
            n += 24;
        }
        i i3 = a[1];
        if ((this.aa >= 816 || i3.f == 2) && this.aa > 816) {
            for (int i4 = n3 + 20; i4 < 208; i4 += 24) {
                for (int i5 = n; i5 < n5; i5 += 24) {
                    i3.a.a(a, 1, ((n2 >> 1) + i5 + i4) % 2, i5, i4, 0, 0, 0);
                }
            }
        }
        if (i2.f == 2) {
            i3.e = 0;
            i3.a = n4 + 120;
            i3.b = n3;
            i3.a();
            i3.a(a);
            i3.e = b.a;
            i3.a(a);
            this.ar();
        }
    }

    private void cG() {
        for (int i2 = 3; i2 < 13; i2 += 2) {
            int n = 10 * (2 * i2 / 5 + 1);
            int n2 = (n + aP / n) * i2 % 176;
            int n3 = 208 / n * aP % 208;
            k.a(a, a[27][i2 & 1], n2, n3, 0);
        }
    }

    public final void aq() {
        if (this.s && this.a == null && this.bo == -1) {
            a[15].a(a, 0, aP >> 1 & 3, this.bx, this.by - 24, 0, 0, 0);
        }
    }

    public final void ar() {
        Graphics graphics = a;
        int n = (aP << 3) % 160;
        int n2 = (aP / 160 & 1) == 0 ? 160 - n : 0 + n;
        graphics.setColor(255, n2, 0);
        graphics.drawRect(0, 0, 175, 207);
    }

    public final void as() {
        int n;
        if (this.D) {
            return;
        }
        int n2 = this.aR;
        int n3 = this.aS;
        int n4 = aP;
        int n5 = this.aU & 7;
        int n6 = (this.aU & 0x4000) == 0 ? 0 : 3;
        i i2 = a[n6];
        boolean bl = this.b();
        int n7 = (this.aU & 0x800) == 0 ? this.bS : this.aU & 7;
        if (!this.d) {
            return;
        }
        this.bx = n2 * 24 + g[n7] * this.aT - this.ar;
        this.by = n3 * 24 + g[n7 + 8] * this.aT - this.as;
        if ((this.b <= 0L || (n4 >> 1 & 1) == 0) && this.aV <= 0) {
            int n8;
            i2.a = this.bx;
            i2.b = this.by;
            if (e != null && bl && n5 != 1 && n5 != 3 && e[n2][n3 + 1] != 0 && this.j(n2, n3 + 1)) {
                n = (n4 >> 1) + n2;
                n8 = n % 4;
                if ((n / 4 & 1) == 1) {
                    n8 = 4 - n8;
                }
                i2.b += n8;
            }
            i2.a();
            i2.a(a);
            n = i2.f;
            E = n == 47 && i2.g == 0;
            switch (n) {
                case 40: 
                case 47: 
                case 48: {
                    if (i2.g <= (n == 40 ? 13 : 6) && n != 47) break;
                    try {
                        n8 = 0;
                        if (this.aC == 30 || this.aC == 31 || this.aC == 32) {
                            n8 = -2;
                        }
                        if (a[this.aC] == null) {
                            a[k.c(this.aC)].a(a, this.aD, i2.a + n8, i2.b - 24, 0, 0, 0);
                        } else {
                            k.a(a, a[this.aC][this.aD], i2.a + n8, i2.b - 24, 0);
                        }
                    }
                    catch (Exception exception) {
                        Exception exception2 = exception;
                        exception.toString();
                    }
                    if (this.aE <= 0) break;
                    this.a(a, i2.a + 24, i2.b - 10, this.aE, k.a[0].a[0], 0);
                    break;
                }
                case 17: 
                case 18: {
                    if (i2.g != 0) break;
                    k.a(a, a[this.aC][this.aD], i2.a, i2.b - 12, 0);
                }
            }
        }
        if (bl && a[n2][n3] == 0) {
            n = b[n2][n3] & 7;
            byte by = b[n2][n3];
            try {
                a[k.c(1)].a(a, 0 + (b[n2][n3] & 0x38), n2 * 24 - this.ar + g[n] * by, n3 * 24 - this.as + g[n + 8] * by, 0, 0, 0);
                return;
            }
            catch (Exception exception) {
                Exception exception3 = exception;
                exception.toString();
            }
        }
    }

    public final void at() {
        int n;
        int n2;
        int n3 = this.bI;
        int n4 = this.bJ;
        int n5 = n4 + 1;
        this.bB = 0;
        this.bC = 0;
        this.z = false;
        int n6 = b[n3][n4];
        int n7 = n6 & 7;
        byte by = b[n3][n4];
        if (n6 == -1) {
            n6 = -1;
        }
        this.bP += by * g[n7];
        this.bQ += by * g[n7 + 8];
        boolean bl = e != null && e[n3][n4] != 0;
        switch (this.bK) {
            case 47: {
                b = a[30];
                this.bM = 0;
                this.bN = this.a(b, 0, aP % this.a(b, 0));
                break;
            }
            case 8: {
                this.aI = 16;
                this.aJ = 0 + (aP >> 1 & 1);
                break;
            }
            case 5: {
                this.aI = 25;
                this.aJ = 0 + this.bT;
                break;
            }
            case 6: {
                this.aI = 5;
                this.aJ = 0;
                break;
            }
            case 7: {
                this.aI = 5;
                this.aJ = 1;
                break;
            }
            case 9: {
                b = a[(n6 & 0xFC00000) >> 22];
                this.bN = 0;
                break;
            }
            case 4: {
                this.aI = 24;
                this.aJ = 0 + this.bT;
                break;
            }
            case 0: {
                boolean bl2;
                n2 = (n6 & 0x38) >> 3;
                n = (n6 & 0x7000) >> 12;
                boolean bl3 = bl2 = (n6 & 0x10000) == 0;
                if (!bl && n7 == 0 && this.j(n3, n5)) {
                    boolean bl4 = false;
                    boolean bl5 = false;
                    boolean bl6 = false;
                    boolean bl7 = false;
                    boolean bl8 = false;
                    boolean bl9 = false;
                    boolean bl10 = false;
                    boolean bl11 = false;
                    boolean bl12 = false;
                    boolean bl13 = false;
                    n6 = n6 & 0xFFFF8FFF | n << 12;
                    if (bl2) {
                        n6 &= 0xFFFEFFFF;
                    } else {
                        n6 |= 0x10000;
                        n = -n;
                    }
                    this.bP = n;
                } else {
                    n6 &= 0xFFFF8FFF;
                }
                k.b[n3][n4] = n6;
                this.aI = 1;
                this.aJ = 0 + n2;
                break;
            }
            case 1: {
                this.aI = 2;
                this.aJ = 0 + this.bT;
                break;
            }
            case 2: {
                this.aw();
            }
        }
        if (bl || e != null && e[n3][n5] != 0 && this.j(n3, n5)) {
            n2 = (aP >> 1) + n3;
            n = n2 % 4;
            if ((n2 / 4 & 1) == 1) {
                n = 4 - n;
            }
            this.bQ += n;
        }
        if (((n6 & 0x200) != 0 || a[n3 - g[n7]][n5] < 0 && this.j(n3, n5) && (b[n3][n5] & 7) == 0 && n3 != this.bi && n4 != this.bj) && (this.aU & 8) == 0) {
            this.bQ += by * by / 24;
            if (this.bK != 9) {
                this.bP += -1 + aP % 3;
            }
        }
        if ((n6 & 0x200) != 0) {
            this.bP = -this.bP;
        }
        if (this.bK == 0) {
            this.bF = ((n6 & 0x1C0) >> 6) - 1;
            if (this.bF >= 0 && this.bF < 5) {
                this.z = true;
                switch (n6 & 7) {
                    case 4: {
                        this.bB = 24;
                        break;
                    }
                    case 2: {
                        this.bB = -24;
                        break;
                    }
                    default: {
                        this.bB = 0;
                    }
                }
                this.bC = 13;
                this.bD = this.bI;
                this.bE = this.bJ - 1;
            }
        }
        this.S();
    }

    public final void au() {
        int n = this.bI;
        int n2 = this.bJ;
        int n3 = b[n][n2];
        byte by = b[n][n2];
        int n4 = n3 & 7;
        this.bP = by * g[n4];
        this.bQ = by * g[n4 + 8];
        b = a[38];
        int n5 = (n3 & 0x7000) >> 12;
        if ((n5 == 2 || n5 == 4 || n4 == 2 || n4 == 4) && a[n - 1][n2] >= 0 && a[n + 1][n2] >= 0 || (n5 == 1 || n5 == 3 || n4 == 1 || n4 == 3) && a[n][n2 - 1] >= 0 && a[n][n2 + 1] >= 0) {
            this.bM = 1;
            this.bN = 0;
        } else {
            this.bM = n4 == 1 || n4 == 3 ? n4 - 1 : 0;
            this.bN = (aP >> 1) % b.a(this.bM);
        }
        this.S();
    }

    public final void c(byte by) {
        int n = b[this.bI][this.bJ];
        byte by2 = b[this.bI][this.bJ];
        int n2 = n & 7;
        this.bP = by2 * g[n2];
        this.bQ = by2 * g[n2 + 8];
        int n3 = by == 19 ? 4 : 21;
        b = a[n3];
        if (this.ap == 1) {
            int n4 = (n & 0xF8) >> 3;
            this.bM = n4 > 0 ? 2 : 0;
            this.bN = aP % b.a(this.bM);
        } else {
            int n5 = (n & 0xF8) >> 3;
            if (n5 > 0) {
                this.bM = 4;
            } else {
                this.bM = n2 - 1;
                if (this.bM < 0) {
                    this.bM = ((n & 0x7000) >> 12) - 1;
                }
            }
            this.bN = (aP >> 1) % b.a(this.bM < 0 ? 0 : this.bM);
        }
        this.S();
    }

    public final void av() {
        int n = this.bI;
        int n2 = this.bJ;
        this.aG = 26;
        this.aH = 0;
        if (this.j(n, n2) && b[n][n2] <= 12) {
            this.bQ = -(b[n][n2] - 12);
        } else if (this.d(n, n2)) {
            if ((this.aU & 0x1000) == 0) {
                if (this.aT <= 12) {
                    this.bQ = -(this.aT - 12);
                }
            } else {
                this.bQ = 12;
            }
        } else if (this.d(n - 1, n2)) {
            if (this.bS == 4 && this.aT > 12) {
                this.bQ = this.aT - 12;
            }
        } else if (this.d(n + 1, n2) && this.bS == 2 && this.aT > 12) {
            this.bQ = this.aT - 12;
        }
        this.bQ += 24;
        this.bR = 36;
    }

    public final void aw() {
        int n = a[this.bI][this.bJ] & 0xFF;
        int n2 = a[this.bI][this.bJ] >> 8;
        if (n != 14 && n != 33 || n2 > 11) {
            this.aI = 3;
            this.aJ = 0 + this.bT;
            if (n == 14) {
                this.bQ = -(a[8].a(0) - n2);
                return;
            }
            if (n == 33) {
                this.bQ = -(a[22].a(0) - n2);
            }
        }
    }

    public final void ax() {
        int n = this.bI;
        int n2 = this.bJ;
        this.aI = 6;
        int n3 = (b[n][n2] & 0xF00) >> 8;
        if (n3 >= 4) {
            this.aI = -1;
            return;
        }
        this.aJ = n3 == 0 ? 0 + (aP >> 1) % 3 : 3 + n3 - 1;
        int n4 = b[n][n2] & 7;
        this.bP = b[n][n2] * g[n4] + 2;
        this.bQ = b[n][n2] * g[n4 + 8] + 2;
        if ((b[n][n2] & 0x10) == 0) {
            switch (n4) {
                case 1: {
                    this.bP += 4;
                    break;
                }
                case 2: {
                    this.bQ += 4;
                    break;
                }
                case 3: {
                    this.bP -= 4;
                    break;
                }
                case 4: {
                    this.bQ -= 4;
                }
            }
            return;
        }
        switch (n4) {
            case 1: {
                this.bP -= 4;
                return;
            }
            case 2: {
                this.bQ -= 4;
                return;
            }
            case 3: {
                this.bP += 4;
                return;
            }
            case 4: {
                this.bQ += 4;
            }
        }
    }

    public final void ay() {
        int n;
        int n2;
        a.setColor(13883367);
        byte by = b[this.bI][this.bJ];
        if ((b[this.bI][this.bJ] & 1) != 0) {
            n2 = this.bz;
            n = this.bz + 24 - by;
            this.bN = 0;
        } else {
            n2 = this.bz + 24;
            n = this.bz + by;
            this.bN = 1;
        }
        a.drawLine(n2, this.bA + 12, n, this.bA + 12);
        if (by > 0) {
            k.a[0].a.a(a, this.bN, n, this.bA + 12 - 2, 0);
        }
    }

    public final void az() {
        int n = a[this.bI][this.bJ] >> 8;
        int n2 = this.aG = this.bL == 9 ? 22 : 23;
        if ((n & 0x200) != 0) {
            this.aH = (byte)((this.bL == 9 ? 1 : 1) + (aP >> 2) % 6);
            return;
        }
        if ((n & 0x100) != 0) {
            this.aH = 1;
            return;
        }
        this.aH = 0;
    }

    public final void aA() {
        int n = this.bI;
        int n2 = this.bJ;
        int n3 = a[n][n2] >> 8;
        int n4 = ((n3 & 0xF0) >> 4) - 1;
        if (n4 < 0) {
            n4 = 0;
        }
        if ((a[n][n2 - 1] & 0xFF) != 9 && (a[n][n2 - 1] & 0xFF) != 8) {
            a[56].a(a, n4, this.bz, this.bA, 0, 0, 0);
        }
        this.aG = 4;
        this.aH = (byte)(n4 + 3);
    }

    public final void aB() {
        int n = aP;
        int n2 = b[this.bI][this.bJ];
        int n3 = b[this.bI][this.bJ];
        if (n3 > 24) {
            n3 = 24;
        }
        int n4 = n2 & 7;
        this.bP = n3 * g[n4];
        this.bQ = n3 * g[n4 + 8];
        if ((n2 & 8) == 0) {
            this.aI = 10;
            this.aJ = (n >> 1) % 3;
            if (n4 != 3) {
                int n5 = (n >> 1) % 5;
                k.a(a, a[10][3 + n5], this.bz + this.bP - n5 * 4, this.bA + (this.bQ + 24), 36);
                return;
            }
        } else {
            this.aI = 10;
            this.aJ = 2 - (n >> 1) % 3;
            if (n4 != 3) {
                int n6 = (n >> 1) % 5;
                k.a(a, a[10][8 + n6], this.bz + 24 - 12 + this.bP + n6 * 3, this.bA + (this.bQ + 24), 36);
                if ((n >> 1 & 1) == 0 && a[this.bI - 1][this.bJ] >= 0) {
                    --this.bP;
                    ++this.bQ;
                }
            }
        }
    }

    public final void aC() {
        int n;
        b b2;
        if (a[this.bI][this.bJ + 1] == 16) {
            return;
        }
        int n2 = b[this.bI][this.bJ];
        b = b2 = a[1];
        byte by = b[this.bI][this.bJ];
        int n3 = 0;
        int n4 = this.bM = (n2 & 7) == 4 ? 1 : 0;
        if (by != 0) {
            n = 0;
            for (int i2 = 36 - by; i2 > 0; i2 -= b2.a(this.bM, n)) {
                n3 = n++;
            }
        }
        this.bN = n3;
        n = (b2.b[this.bM] + n3) * 5;
        this.bP = b2.f[n + 2];
    }

    public final void aD() {
        int n = b[this.bI][this.bJ];
        b = a[28];
        this.bM = n & 0xF;
        int n2 = (b[this.bI][this.bJ] & 0x1FE000) >> 13;
        if (this.bM == 10) {
            int n3 = 0;
            int n4 = b.a(this.bM);
            int n5 = 0;
            for (int i2 = n2; i2 > 0; i2 -= b.a(this.bM, n5)) {
                n3 = n5;
                n5 = (n5 + 1) % n4;
            }
            this.bN = n3;
        } else {
            int n6;
            this.bN = n6 = this.a(b, this.bM, n2);
            int n7 = (k.b.b[this.bM] + n6) * 5;
            this.bP = k.b.f[n7 + 2];
            this.bQ = k.b.f[n7 + 3];
        }
        this.S();
    }

    public final int a(b b2, int n, int n2) {
        int n3 = 0;
        int n4 = 0;
        while (n2 > 0) {
            n2 -= b2.a(n, n4);
            n3 = n4++;
        }
        return n3;
    }

    public final int b(b b2, int n, int n2) {
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            n3 += b2.a(n, i2);
        }
        return n3;
    }

    public final void aE() {
        int n;
        int n2;
        int n3;
        int n4;
        boolean bl;
        int n5 = this.bG;
        int n6 = this.bH;
        k.c[n5][n6] = 24;
        int n7 = (b[n5][n6] & 0x1C00) >> 10;
        int n8 = b[n5][n6] & 0xF;
        int n9 = 0;
        boolean bl2 = bl = (a[n5][n6] & 0xFF) == 35;
        if (n8 == 10) {
            n9 = 65;
        } else {
            n4 = a[28].a(n8);
            for (n3 = 0; n3 < n4; ++n3) {
                n9 += a[28].a(n8, n3);
            }
        }
        n4 = (b[n5][n6] & 0x1FE000) >> 13;
        k.b[n5][n6] = b[n5][n6] & 0xFFE01FFF | ++n4 << 13;
        k.b[n5][n6] = n8 >= 4 && n8 <= 9 ? 12 : 0;
        if (n4 > n9 >> 1) {
            if (!bl) {
                if (this.d(n5, n6) && n8 != 10) {
                    switch (n8) {
                        case 4: 
                        case 5: {
                            n3 = 1;
                            break;
                        }
                        case 6: {
                            n3 = 2;
                            break;
                        }
                        case 7: 
                        case 8: {
                            n3 = 3;
                            break;
                        }
                        case 9: {
                            n3 = 4;
                            break;
                        }
                        default: {
                            n3 = h[this.aU & 7];
                        }
                    }
                    this.a(1, 48, n3);
                }
                if (this.i(n5, n6)) {
                    k.a[n5][n6] = -1;
                    this.o(n5, n6);
                    return;
                }
            }
            if (n4 >= n9) {
                boolean bl3;
                int n10;
                int n11;
                boolean bl4;
                this.p(n5, n6);
                n2 = this.a(n5, n6, this.aR, this.aS, true);
                boolean bl5 = false;
                switch (n8) {
                    case 0: 
                    case 3: 
                    case 4: 
                    case 7: 
                    case 9: {
                        bl5 = true;
                    }
                }
                boolean bl6 = bl4 = n2 == 4;
                if (bl5 != bl4) {
                    n = bl4 ? 3 : 2;
                    n11 = n5;
                    n10 = n6;
                } else {
                    n11 = n5 - g[n2];
                    n10 = n6 - g[8 + n2];
                    if (bl4) {
                        if (this.d(n11, n10) && n8 != 0) {
                            n = 0;
                            n11 = n5;
                            n10 = n6;
                        } else {
                            switch (n2) {
                                case 1: {
                                    n = 4;
                                    break;
                                }
                                case 4: {
                                    n = 9;
                                    break;
                                }
                                case 3: {
                                    n = 7;
                                    break;
                                }
                                default: {
                                    n = 0;
                                    break;
                                }
                            }
                        }
                    } else if (this.d(n11, n10) && n8 != 1) {
                        n = 1;
                        n11 = n5;
                        n10 = n6;
                    } else {
                        switch (n2) {
                            case 1: {
                                n = 5;
                                break;
                            }
                            case 2: {
                                n = 6;
                                break;
                            }
                            case 3: {
                                n = 8;
                                break;
                            }
                            default: {
                                n = 1;
                            }
                        }
                    }
                }
                if (!(bl3 = a[n11][n10] < 0) || bl) {
                    if (n11 != n5 || n10 != n6) {
                        n = 0;
                    }
                    n11 = n5;
                    n10 = n6;
                }
                k.a[n5][n6] = -1;
                k.b[n11][n10] = 0;
                k.b[n11][n10] = n7 << 10 | n;
                k.b[n11][n10] = b[n11][n10] & 0xFFE01FFF;
                k.a[n11][n10] = 45;
            }
        }
        if (bl) {
            if (this.d(n5, n6) && n8 != 10) {
                this.a(1, 48, (int)h[this.aU & 7]);
                return;
            }
        } else {
            n = n5;
            n2 = n6;
            switch (n8) {
                case 7: 
                case 8: {
                    --n2;
                    break;
                }
                case 10: {
                    n = -1;
                    n2 = -1;
                    break;
                }
                case 9: {
                    ++n;
                    break;
                }
                case 6: {
                    --n;
                    break;
                }
                case 0: 
                case 1: 
                case 2: 
                case 3: {
                    break;
                }
                case 4: 
                case 5: {
                    ++n2;
                }
            }
            if (this.d(n, n2)) {
                this.a(1, 48, (int)h[this.aU & 7]);
            }
        }
    }

    public final void aF() {
        int n;
        int n2;
        int n3 = -1;
        int n4 = 3;
        int n5 = b[this.bI][this.bJ];
        if ((n5 & 7) == 3) {
            n3 = 1;
            n4 = 0;
        }
        if ((n5 & 8) == 0) {
            n2 = this.aL;
            n = this.aK;
        } else {
            n2 = this.aN;
            n = this.aM;
        }
        for (int i2 = 0; i2 < n2; ++i2) {
            a[11].a(a, n4 + i2 * n3, this.bz + 3, this.bA + n3 * (n - i2 * 24), 0, 0, 0);
        }
        if (n3 == 1) {
            a[42].a(a, a[this.bI][this.bJ - 1] - 80, this.bz, this.bA - 24, 0, 0, 0);
            return;
        }
        a[42].a(a, a[this.bI][this.bJ + 1] - 80, this.bz, this.bA + 24, 0, 0, 0);
    }

    public final void aG() {
        i i2 = a[0];
        a.setColor(0);
        a.fillRect(0, 0, 176, 208);
        i2.b = 80;
        boolean bl = false;
        int n = 0;
        if (aP > 22) {
            i2.a = 105;
            i2.a(1);
            int n2 = (aP - 22) * 4;
            if (n2 > 29) {
                n2 = 29;
                if (aP < 42) {
                    int n3 = 42 - aP;
                    n = 0 + n3 * n3 % ((n3 >> 1) + 1);
                    i2.a.a(a, 10, 106, 80 + n, 0, 0, 0);
                } else {
                    i2.a.a(a, 4, 106, 80, 0, 0, 0);
                }
                i2.g = 0;
            } else {
                i2.a.a(a, 10, 106, 80, 0, 0, 0);
            }
            i2.b = 80 + n2;
        } else {
            i2.a = aP * 4 - 1 + 18;
        }
        i2.b += n;
        i2.a(a);
        i2.a.a(a, 5, 106, 104 + n, 0, 0, 0);
    }

    public final void a(Graphics graphics, int n, int n2, int n3, f[] fArray, int n4) {
        if (n3 == 0) {
            f f2 = k.a[0].a[0][0];
            k.a(graphics, f2, n, n2, 24);
            return;
        }
        while (n3 > 0) {
            int n5 = n3 % 10;
            n3 /= 10;
            f f3 = fArray[n5 + n4];
            k.a(graphics, f3, n -= f3.a, n2, 0);
        }
    }

    public final void a(Graphics graphics, int n, int n2, String string, f[] fArray, int n3) {
        for (int i2 = string.length() - 1; i2 >= 0; --i2) {
            int n4 = string.charAt(i2);
            if (n4 == 47) {
                n4 = 58;
            }
            n4 = (char)(n4 - 48);
            f f2 = fArray[n4 + n3];
            k.a(graphics, f2, n, n2, 24);
            n -= f2.a;
        }
    }

    public final boolean b() {
        return this.aR > 0 && this.aR < this.ax - 1 && this.aS > 0 && this.aS < this.ay - 1;
    }

    public final void m(int n) {
        int n2 = k.a[0].f;
        if (n2 != 19 && (this.aU & 0x4000) == 0 && (this.aU & 0x800) == 0) {
            if (this.b()) {
                int n3 = e == null ? 0 : this.a(e[this.aR][this.aS], (byte)0, (byte)3, (byte)4);
                if (n3 == 8 || n3 == 7) {
                    switch (n) {
                        case 0: 
                        case 1: 
                        case 2: 
                        case 3: 
                        case 4: 
                        case 5: 
                        case 6: 
                        case 7: 
                        case 8: 
                        case 9: 
                        case 11: 
                        case 24: 
                        case 25: 
                        case 26: 
                        case 27: {
                            n = 36 + (this.aU & 7) - 1;
                        }
                    }
                } else if (a[this.aR][this.aS + 1] < 0 || a[this.aR][this.aS + 1] == 14) {
                    switch (n) {
                        case 14: {
                            n = 28;
                            break;
                        }
                        case 16: {
                            n = 29;
                            break;
                        }
                        case 42: {
                            n = 46;
                            break;
                        }
                        case 44: {
                            n = 45;
                            break;
                        }
                        case 1: {
                            n = 35;
                            break;
                        }
                        case 3: {
                            n = 34;
                            break;
                        }
                        case 0: {
                            n = 0;
                            break;
                        }
                        case 2: {
                            n = 2;
                            break;
                        }
                        case 22: {
                            n = 31;
                            break;
                        }
                        case 20: {
                            n = 30;
                            break;
                        }
                        case 23: {
                            n = 33;
                            break;
                        }
                        case 21: {
                            n = 32;
                        }
                    }
                }
            }
            if (n == 1000) {
                a[3].a(0);
                this.aU |= 0x4000;
            } else {
                a[0].a(n);
            }
            if (n2 != n) {
                this.am = 45;
            }
        }
    }

    public final void aH() {
        if (this.a(32976)) {
            W = 0;
            this.au = true;
            this.n(this.c);
            return;
        }
        if (this.a(32)) {
            W = 0;
            l = (byte)27;
            this.au = true;
            this.f = true;
            W = 0;
            return;
        }
        if (this.a(4097)) {
            this.o(-1);
        } else if (this.a(262146)) {
            this.o(1);
        }
        W = 0;
        int n = this.d(this.c);
        if (n == 0) {
            this.d = -1;
            this.a = a[81];
            this.au = true;
            return;
        }
        this.d = h.a[this.c];
        this.d.delete(0, this.d.length());
        this.d.append(this.d);
        this.a = a[90];
        this.au = true;
    }

    public final int d(int n) {
        byte by = i[8];
        if (by >= 4 + n + 1) {
            return 0;
        }
        int n2 = k.a(i, 4);
        if (n2 < h.a[n]) {
            return -1;
        }
        return 1;
    }

    public final void n(int n) {
        this.eo = -1;
        switch (this.d(n)) {
            case -1: {
                this.a = a[89];
                return;
            }
            case 0: {
                this.a = a[81];
                return;
            }
            case 1: {
                this.bb = k.a(i, 4) - h.a[this.c];
                this.f = null;
                System.gc();
                this.f = a[110] + " " + this.bb + " " + a[109];
                k.i[4] = (byte)(this.bb & 0xFF);
                k.i[5] = (byte)(this.bb >> 8 & 0xFF);
                k.i[8] = (byte)(4 + n + 1);
                this.A();
                this.d = -1;
                this.a = a[81];
                this.Y = true;
                this.a(a[91], -1, -1, 5000, 4273165, 0);
            }
        }
    }

    public final void o(int n) {
        this.c += n;
        if (this.c < 0) {
            this.c = 3;
        }
        if (this.c == 4) {
            this.c = 0;
        }
    }

    public final void aI() {
        if (this.a(32)) {
            l = (byte)4;
            this.a(4);
        }
        W = 0;
    }

    public final void aJ() {
        if (W == 0) {
            this.j = 0;
            return;
        }
        if (this.h()) {
            this.c(true);
            W = 0;
            return;
        }
        switch (l) {
            case 33: {
                this.aL();
                break;
            }
            case 26: {
                this.aI();
                break;
            }
            case 18: {
                break;
            }
            case 25: {
                this.aH();
                break;
            }
            case 24: {
                break;
            }
            case 34: {
                break;
            }
            case 12: {
                this.aO();
                break;
            }
            case 4: {
                this.aQ();
                break;
            }
            case 30: {
                if (!this.a(32784)) break;
                l = (byte)4;
                if (this.bq == -1) {
                    this.aO = 0;
                    this.a(0);
                } else {
                    this.aO = 2;
                }
                W = 0;
                break;
            }
            case 2: 
            case 7: 
            case 32: {
                this.aQ();
                break;
            }
            case 1: {
                if (this.g || this.ah) {
                    W = 0;
                }
                this.aP();
                break;
            }
            case 10: {
                break;
            }
            case 15: {
                this.cw();
                break;
            }
            case 17: 
            case 20: {
                if (!this.a(32976)) break;
                if (this.aO == 5) {
                    this.aZ();
                    this.u();
                }
                this.t = true;
                W = 0;
                break;
            }
            case 27: {
                this.aM();
                break;
            }
            case 31: {
                if (this.a(32)) {
                    this.bu = 0;
                    this.bt = 8;
                    l = (byte)9;
                    this.a(-1);
                } else if (this.a(64)) {
                    this.aK();
                }
                W = 0;
            }
        }
        if (this.c) {
            return;
        }
        if ((this.aU & 7) != 0) {
            this.b = 6;
        }
    }

    public final void aK() {
        this.C = true;
        l = (byte)16;
        this.bu = 0;
        this.bt = 6;
        this.ao = 0;
        this.bd = 0;
        this.bb = 0;
        this.o = false;
        this.V = 0;
        ea = 0;
    }

    public final void aL() {
        if (this.a(32)) {
            if (this.bq == 0) {
                l = (byte)4;
                this.a(0);
            }
            if (this.bq == 1) {
                l = (byte)2;
                T = true;
                this.n = true;
                this.a(1);
            }
        }
    }

    public final void aM() {
        if (this.s != -1 || this.q != 0) {
            W = 0;
            return;
        }
        if (this.a(32976)) {
            this.j = 4;
        } else if (this.a(32)) {
            this.u();
            l = (byte)9;
            this.bt = 8;
            this.a(-1);
            this.bu = 0;
        } else if (this.a(4097)) {
            this.j = 0;
        } else if (this.a(262146)) {
            this.j = 2;
        } else if (this.a(16388)) {
            this.j = 3;
        } else if (this.a(65544)) {
            this.j = 1;
        }
        W = 0;
    }

    public final void aN() {
        if (this.ap == 0 && this.aq == 13) {
            this.a = null;
            this.aR = 60;
            this.aS = 3;
            return;
        }
        this.as = this.a(524288);
        this.B = !this.as;
        this.bf = 0;
        this.be = 0;
        this.w = true;
        this.aR = this.ax + 5 + 1;
    }

    public final void aO() {
        if (!this.a(64)) {
            return;
        }
        this.ao = 5;
        k.i[3] = (byte)this.ao;
        if (this.i == 2) {
            this.n();
            return;
        }
        this.e(4, -500);
        l = (byte)15;
        this.J = true;
        this.H = true;
        this.cn();
    }

    /*
     * Unable to fully structure code
     */
    public final void aP() {
        block83: {
            block85: {
                block89: {
                    block91: {
                        block90: {
                            block88: {
                                block87: {
                                    block86: {
                                        block84: {
                                            block82: {
                                                if (this.Z && (this.a(524288) || this.a(131072))) {
                                                    this.aN();
                                                }
                                                if (this.cn != 0 && !this.a(64) || this.an != 0 || this.w || this.m <= 0 || k.a[0].f == 19 || this.D) {
                                                    k.W = 0;
                                                    return;
                                                }
                                                if (this.a != null) {
                                                    if (this.a(32784)) {
                                                        this.a.a();
                                                    } else if (this.a(64)) {
                                                        this.a.b = true;
                                                    }
                                                    k.W = 0;
                                                    return;
                                                }
                                                if (this.aV <= 0) break block82;
                                                var1_1 = true;
                                                if (this.a(4097)) {
                                                    this.ak = -5;
                                                } else if (this.a(262146)) {
                                                    this.ak = 5;
                                                } else if (this.a(16388)) {
                                                    this.aj = -5;
                                                } else if (this.a(65544)) {
                                                    this.aj = 5;
                                                } else if (!this.a(32784)) {
                                                    if (this.a(64)) {
                                                        this.bt();
                                                        k.W = 0;
                                                    } else {
                                                        var1_1 = false;
                                                    }
                                                }
                                                if (var1_1) {
                                                    --this.aV;
                                                    if (this.aV == 0) {
                                                        if ((byte)(k.a[this.aR][this.aS] & 255) < 0) {
                                                            k.a[this.aR][this.aS] = 32;
                                                        }
                                                        if (k.a[this.aR][this.aS] == 9) {
                                                            k.a[this.aR][this.aS] = -1;
                                                        }
                                                        this.b = 26L;
                                                        this.aT = 0;
                                                        this.aU = this.aU & -113 | 0;
                                                        this.m(this.e());
                                                    }
                                                    k.W = 0;
                                                    return;
                                                }
                                                break block83;
                                            }
                                            if (!this.a(4097)) break block84;
                                            this.j = 1;
                                            break block85;
                                        }
                                        if (!this.a(262146)) break block86;
                                        this.j = (byte)3;
                                        break block85;
                                    }
                                    if (!this.a(16388)) break block87;
                                    this.j = (byte)4;
                                    break block85;
                                }
                                if (!this.a(65544)) break block88;
                                this.j = (byte)2;
                                break block85;
                            }
                            if (!this.a(32784)) break block89;
                            k.W = 0;
                            if (this.bU != this.aR || this.bV != this.aS || (k.a[this.aR][this.aS] & 255) != 4) break block90;
                            this.ca();
                            break block85;
                        }
                        var1_2 = k.e == null ? 0 : this.a(k.e[this.aR][this.aS], (byte)0, (byte)3, (byte)4);
                        if (var1_2 == 8 || var1_2 == 7) break block85;
                        var2_4 = this.aU & 7;
                        var3_5 = -1;
                        var4_6 = -1;
                        var5_7 = false;
                        if (k.i[9] < 2) break block91;
                        var6_8 = 0;
                        for (var7_9 = 0; var7_9 < 2; ++var7_9) {
                            var8_11 = var7_9 == 0 ? 1 : -1;
                            if ((var8_11 <= 0 || this.aR >= this.ax - 3) && (var8_11 >= 0 || this.aR <= 3)) continue;
                            block15: for (var9_13 = 1; var9_13 <= 3; ++var9_13) {
                                var10_14 = this.aR + var8_11 * var9_13;
                                var11_15 = k.a[var10_14][this.aS];
                                var12_16 = k.a[var10_14][this.aS] & 255;
                                if (var12_16 == 7 && (k.a[var10_14][this.aS] >> 8 & 240) == 0) {
                                    var9_13 = 4;
                                    continue;
                                }
                                if (var11_15 == 48 && (k.b[var10_14][this.aS] & 8) != 0) continue;
                                switch (var11_15) {
                                    case 11: 
                                    case 19: 
                                    case 43: {
                                        if (var8_11 <= 0) ** GOTO lbl95
                                        var6_8 |= 2;
                                        ** GOTO lbl97
lbl95:
                                        // 1 sources

                                        if (var8_11 < 0) {
                                            var6_8 |= 4;
                                        }
                                    }
lbl97:
                                    // 5 sources

                                    case 0: 
                                    case 1: 
                                    case 8: 
                                    case 9: 
                                    case 14: 
                                    case 47: 
                                    case 48: {
                                        if (var9_13 != 1) {
                                            if (var4_6 < 0) {
                                                var4_6 = var8_11 > 0 ? 2 : 4;
                                                var9_13 = 4;
                                                continue block15;
                                            }
                                            var5_7 = true;
                                            var4_6 = var6_8 == 2 ? 2 : (var6_8 == 4 ? 4 : -1);
                                            var9_13 = 4;
                                            continue block15;
                                        }
                                        var9_13 = 4;
                                        continue block15;
                                    }
                                    case -1: {
                                        continue block15;
                                    }
                                    default: {
                                        var9_13 = 4;
                                    }
                                }
                            }
                        }
                    }
                    if (k.i[9] >= 1) {
                        this.j = (byte)5;
                        var6_8 = 0;
                        var7_10 = new int[]{0, 1, 0, -1, 1, 1, -1, -1, 0, 2, 0, -2};
                        var8_12 = new int[]{-1, 0, 1, 0, -1, 1, 1, -1, -2, 0, 2, 0};
                        var13_17 = new int[]{0, 0, 0, 0, 3, 6, 12, 9, 1, 2, 4, 8};
                        for (var14_18 = 0; var14_18 < var7_10.length; ++var14_18) {
                            var15_19 = this.aR + var7_10[var14_18];
                            var16_20 = this.aS + var8_12[var14_18];
                            if (var15_19 < 0 || var15_19 >= this.ax || var16_20 < 0 || var16_20 >= this.ay) continue;
                            var17_21 = k.b[var15_19][var16_20] & 7;
                            var18_22 = false;
                            var19_23 = -1;
                            var20_24 = false;
                            switch (k.a[var15_19][var16_20]) {
                                case 9: 
                                case 18: 
                                case 30: {
                                    if (var13_17[var14_18] != 0) break;
                                    var20_24 = true;
                                    break;
                                }
                                case 46: 
                                case 49: 
                                case 50: {
                                    if (var13_17[var14_18] != 0) break;
                                    ++var6_8;
                                    var20_24 = true;
                                    break;
                                }
                                case 19: 
                                case 43: {
                                    if ((k.b[var15_19][var16_20] & 248) != 0) break;
                                    var18_22 = true;
                                    break;
                                }
                                case 45: {
                                    if ((k.b[var15_19][var16_20] & 15) == 10) break;
                                    var18_22 = true;
                                }
                            }
                            if (var18_22) {
                                if (var13_17[var14_18] == 0) {
                                    var19_23 = var14_18 + 1;
                                } else if (k.b[var15_19][var16_20] >= 12) {
                                    if ((var13_17[var14_18] & 1) != 0 && var17_21 == 3) {
                                        if (var7_10[var14_18] == 0) {
                                            var19_23 = 1;
                                        } else if (var7_10[var14_18] < 0) {
                                            var19_23 = 4;
                                        } else if (var7_10[var14_18] > 0) {
                                            var19_23 = 2;
                                        }
                                    } else if ((var13_17[var14_18] & 8) != 0 && var17_21 == 2) {
                                        if (var8_12[var14_18] == 0) {
                                            var19_23 = 4;
                                        } else if (var8_12[var14_18] < 0) {
                                            var19_23 = 1;
                                        } else if (var8_12[var14_18] > 0) {
                                            var19_23 = 3;
                                        }
                                    }
                                }
                                if (var19_23 != -1) {
                                    var20_24 = true;
                                    ++var6_8;
                                }
                            }
                            if (!var20_24) continue;
                            if (var6_8 == 0) {
                                if (var2_4 == var14_18 + 1) {
                                    var3_5 = var2_4;
                                    continue;
                                }
                                if (var3_5 >= 0) continue;
                                var3_5 = var14_18 + 1;
                                continue;
                            }
                            if (var6_8 == 1) {
                                var3_5 = var19_23;
                                continue;
                            }
                            var3_5 = var2_4;
                            break;
                        }
                    }
                    if (var3_5 > 0 && var4_6 == var2_4) {
                        this.j = (byte)6;
                        this.aU = this.aU & -8 | var2_4;
                    } else if (var3_5 > 0 && var4_6 < 0 && !var5_7) {
                        this.aU = this.aU & -8 | var3_5;
                    } else if (var3_5 < 0 && var4_6 > 0 && !var5_7) {
                        this.j = (byte)6;
                        this.aU = this.aU & -8 | var4_6;
                    } else if (var5_7 && (var2_4 == 2 || var2_4 == 4)) {
                        this.j = (byte)6;
                        this.aU = this.aU & -8 | var2_4;
                    } else if (var5_7 && var4_6 > 0) {
                        this.j = (byte)6;
                        this.aU = this.aU & -8 | var4_6;
                    }
                    if (this.j == 6 && (k.a[this.aR][this.aS] & 255) == 2 && k.a[this.aR][this.aS] >> 8 == 1) {
                        this.aA = -1;
                        this.b(this.aR, this.aS, (byte)2);
                    }
                    break block85;
                }
                if (this.a(256)) {
                    this.aA = -1;
                    var1_3 = k.a[0].f;
                    if (var1_3 == 36 + (this.aU & 7) - 1) {
                        if ((k.a[this.aR][this.aS] & 255) == 4) {
                            this.ca();
                        } else {
                            this.C(0);
                            this.m(19);
                        }
                    }
                    switch (var1_3) {
                        case 0: 
                        case 1: 
                        case 2: 
                        case 3: 
                        case 34: 
                        case 35: {
                            if ((k.a[this.aR][this.aS] & 255) == 4) {
                                this.ca();
                                break;
                            }
                            this.C(0);
                            this.m(19);
                        }
                    }
                } else if (this.a(32)) {
                    this.bt();
                    k.W = 0;
                }
            }
            if (this.j != 5 && this.k == 0 && this.b == 0 && this.j != (this.aU & 7)) {
                this.aU |= 4096;
            }
        }
    }

    public final void aQ() {
        if (this.dd >= 0 && this.dd <= 2) {
            W = 0;
            return;
        }
        boolean bl = false;
        if (this.a(4097)) {
            if (System.currentTimeMillis() - this.k < 300L) {
                return;
            }
            this.r();
            if (this.bq == 0 && this.bs == 1 && !this.V) {
                this.r();
            }
        } else if (this.a(262146)) {
            if (System.currentTimeMillis() - this.k < 300L) {
                return;
            }
            this.s();
            if (this.bq == 0 && this.bs == 1 && !this.V) {
                this.s();
            }
        } else if (this.a(32976)) {
            if (this.dd < 0 || this.dd > 2) {
                this.dd = 0;
                this.j = System.currentTimeMillis();
            }
        } else if (this.a(32)) {
            this.aR();
        }
        W = 0;
    }

    public final void aR() {
        switch (this.bq) {
            case -1: {
                return;
            }
            case 5: {
                T = true;
                U = false;
                if (l == 2) {
                    this.a(1);
                    this.v();
                    U = true;
                }
                if (l != 4) break;
                this.a(0);
                return;
            }
            case 2: {
                l = (byte)9;
                this.a(0);
                this.bt = 8;
                this.bu = 0;
                return;
            }
            case 4: {
                this.a(2);
            }
        }
    }

    public final void c(int n, int n2, int n3) {
        int[] nArray = new int[]{0, 1, -1, 0, 0};
        int[] nArray2 = new int[]{0, 0, 0, 1, -1};
        boolean bl = false;
        boolean bl2 = i[9] >= 8;
        boolean bl3 = false;
        switch (a[n][n2]) {
            case 9: {
                if ((this.aU & 0x2000) != 0) break;
                this.aU |= 0x2000;
                bl = true;
                this.f(n, n2);
                break;
            }
            case 18: {
                bl = this.c();
                break;
            }
            case 0: {
                bl3 = true;
                break;
            }
            case 30: {
                bl = true;
                if (b[n][n2] != 0) break;
                this.C(9);
                k.b[n][n2] = 1;
                break;
            }
            case 10: {
                if (this.v != 3 || b[n][n2] > 0) break;
                bl = true;
                k.b[n][n2] = 1;
                this.b(n, n2);
                break;
            }
            case 16: {
                bl = true;
                bl3 = true;
                break;
            }
            default: {
                if (a[n][n2] - 80 < 0 && ((a[n][n2] & 0xFF) != 7 || (a[n][n2] >> 8 & 0xF0) != 0)) break;
                bl3 = true;
                bl = true;
            }
        }
        if (bl3) {
            this.C(7);
            this.m(41 + (this.aU & 7) - 1);
        }
        if (!bl) {
            for (int i2 = 0; i2 < 5; ++i2) {
                int n4;
                int n5 = n + nArray[i2];
                int n6 = n2 + nArray2[i2];
                if (n5 < 0 || n5 >= this.ax || n6 < 0 || n6 >= this.ay) continue;
                byte by = a[n5][n6];
                boolean bl4 = false;
                boolean bl5 = false;
                switch (by) {
                    case 1: {
                        if (n5 != this.aR - g[this.aU & 7] || n6 != this.aS - g[(this.aU & 7) + 8]) break;
                        bl5 = true;
                        break;
                    }
                    case 19: 
                    case 43: 
                    case 45: 
                    case 46: 
                    case 49: {
                        boolean bl6;
                        n4 = b[n5][n6] & 7;
                        byte by2 = n4 == 0 ? (byte)0 : b[n5][n6];
                        boolean bl7 = bl6 = by != 49 && by != 46;
                        if (this.a(n, n2, 0, 0, n5, n6, n4, by2)) {
                            bl5 = true;
                            bl4 = bl6;
                        }
                        if (!bl5) break;
                        this.C(4);
                    }
                }
                if (bl2 && bl5 && (n5 != this.aR || n6 != this.aS)) {
                    boolean bl8 = this.b(n5, n6);
                    n4 = bl8 ? 1 : 0;
                    if (!bl8) continue;
                    this.aU |= 0x2000;
                    continue;
                }
                if (!bl4) continue;
                this.aU |= 0x2000;
                if (by == 45) {
                    n4 = (b[n5][n6] & 0x1C00) >> 10;
                    if (n4 == 3) {
                        k.a[n5][n6] = -1;
                        this.o(n5, n6);
                        continue;
                    }
                    k.b[n5][n6] = 0xA | ++n4 << 10;
                    k.b[n5][n6] = b[n5][n6] & 0xFFFFFF07 | 0x78;
                    k.b[n5][n6] = 0;
                    continue;
                }
                this.d(by, n5, n6);
            }
        }
    }

    public final void f(int n, int n2) {
        if (this.a(n, n2)) {
            return;
        }
        this.p(n, n2);
        int n3 = this.d(n, n2 - 1) ? 2 : 1;
        switch ((b[n][n2] & 0xFC00000) >> 22) {
            case 39: {
                k.a[n][n2] = 49;
                k.b[n][n2] = n3;
                return;
            }
            case 37: {
                k.a[n][n2] = (b[n][n2] & 0x10000000) != 0 ? 43 : 19;
                k.b[n][n2] = n3;
                this.d(19, n, n2);
                return;
            }
            case 35: {
                k.a[n][n2] = 45;
                k.b[n][n2] = b[n][n2] & 0xFFFFFFF0 | 0xA;
                return;
            }
            case 34: {
                k.a[n][n2] = 1;
                this.c(n, n2);
                return;
            }
            case 36: {
                k.a[n][n2] = 46;
                k.b[n][n2] = 0;
                k.b[n][n2] = 0;
            }
        }
    }

    public final boolean c() {
        if (this.v == 3) {
            int n = a[this.aR][this.aS] & 0xFF;
            if (this.ch == 0 && n != 15 && n != 16) {
                this.C(6);
                this.ch = this.cg <= 0 ? 1 : -1;
            }
            return true;
        }
        return false;
    }

    public final void d(int n, int n2, int n3) {
        int n4 = b[n2][n3];
        if (n == 43 && (n4 & 0xF8) == 0) {
            if ((n4 & 0x18000) == 0) {
                k.a[n2][n3] = -1;
                this.o(n2, n3);
                return;
            }
            n4 -= 32768;
            n4 = n4 & 0xFF01FFFF | n2 << 17;
            n4 = ((n4 = n4 & 0x80FFFFFF | n3 << 24) & 7) == 1 || (n4 & 7) == 3 ? (n4 |= Integer.MIN_VALUE) : (n4 &= Integer.MAX_VALUE);
        }
        k.b[n2][n3] = n4 = n4 & 0xFFFFFF07 | 0x78;
    }

    public final void aS() {
        boolean bl = false;
        int n = a[this.bG][this.bH] >> 8;
        if (++n >= 16) {
            k.a[this.bG][this.bH] = -1;
            return;
        }
        k.c[this.bG][this.bH] = 24;
        k.a[this.bG][this.bH] = n << 8 | 0x24;
    }

    public final void g(int n, int n2) {
        switch (a[n][n2]) {
            case 0: {
                this.C(9);
            }
            case 19: 
            case 43: 
            case 45: 
            case 46: {
                k.a[n][n2] = -1;
                this.o(n, n2);
                return;
            }
            case 48: {
                k.a[n][n2] = -1;
                this.o(n, n2);
                int n3 = n2 + 1;
                if (a[n][n3] != 48) {
                    n3 = -1;
                }
                k.a[n][n3] = -1;
                this.o(n, n3);
                int n4 = (b[n][n2] >> 24) * 3;
                k.e[n4 + 2] = -1;
                return;
            }
        }
        k.a[n][n2] = -1;
    }

    public final void aT() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        if (this.b) {
            --this.a;
        }
        if ((this.g || this.ah) && aP > 140) {
            if (this.ah) {
                this.d();
            }
            this.g = false;
            this.ah = false;
            this.K = true;
            this.bu = 0;
            this.a();
            this.I = true;
            l = (byte)28;
        }
        boolean bl = this.b();
        if (this.ak) {
            this.ak = false;
            if (this.du < this.dv) {
                n5 = this.a((byte)this.du, (byte)13, (byte)7);
                n4 = this.a((byte)this.du, (byte)20, (byte)7);
                this.u(n5, n4);
                ++this.du;
            } else {
                this.du = 0;
                this.dv = 0;
            }
        }
        if (a[4] != null) {
            a[4].b();
        }
        if (this.bl > 0) {
            --this.bl;
        }
        if (this.dj > 0) {
            --this.dj;
            if (this.dj == 0) {
                this.e = null;
            }
        }
        if (this.S != this.T) {
            n5 = this.S;
            while (n5 != this.T) {
                int n6 = n5;
                b[n6] = (byte)(b[n6] + 1);
                n4 = c[n5] < 0 ? this.a(a[2], 0) : a[9].a(c[n5]);
                if (b[n5] >= n4) {
                    ++this.S;
                    this.S &= 7;
                }
                n5 = n5 + 1 & 7;
            }
        }
        if (this.i != 0) {
            this.bf();
            if (l != 1) {
                return;
            }
        }
        if ((aP & 0xF) == 0) {
            this.be();
        }
        if (this.ch != 0 && (aP >> 1 & 1) == 0) {
            this.cg += this.ch;
            if (this.cg == 0 || this.cg == 9) {
                this.ch = 0;
                for (n5 = 1; n5 < this.ay - 1; ++n5) {
                    for (n4 = 1; n4 < this.ax - 1; ++n4) {
                        n3 = a[n4][n5] & 0xFF;
                        n2 = a[n4][n5];
                        n = 0;
                        if (n3 != 15 && n3 != 16 && n2 != 34 && n2 != 35) continue;
                        this.c(n4, n5);
                    }
                }
            } else if (this.cg == 5) {
                n5 = this.ay - 1;
                n4 = this.ax - 1;
                for (n3 = 1; n3 < n5; ++n3) {
                    for (n2 = 1; n2 < n4; ++n2) {
                        n = a[n2][n3] & 0xFF;
                        byte by = a[n2][n3];
                        boolean bl2 = false;
                        if (n == 15) {
                            this.g(n2, n3);
                            k.a[n2][n3] = 34;
                            bl2 = true;
                        } else if (n == 16) {
                            this.g(n2, n3);
                            k.a[n2][n3] = 35;
                            bl2 = true;
                        } else if (by == 34) {
                            k.a[n2][n3] = 15;
                            k.a[n2][n3] = -1;
                            this.s(n2, n3);
                            bl2 = true;
                        } else if (by == 35) {
                            k.a[n2][n3] = 16;
                            k.a[n2][n3] = -1;
                            this.s(n2, n3);
                            bl2 = true;
                        }
                        if (!bl2) continue;
                        this.p(n2, n3);
                    }
                }
            }
        }
        --this.b;
        if (this.aY > 0 && --this.aY == 0) {
            this.ba();
        }
        if (this.aT <= 0 && this.v) {
            this.v = false;
            try {
                Thread.sleep(100L);
            }
            catch (InterruptedException interruptedException) {
                InterruptedException interruptedException2 = interruptedException;
                interruptedException.toString();
            }
            this.bZ();
        }
        if (a[11] != null) {
            this.bd();
        }
        if (this.bk != 0 && this.bi != 0) {
            this.bc();
        }
        this.bz();
        if (this.al > 0) {
            this.aU();
        }
        this.ci();
        if (this.cn != 0) {
            this.by();
        }
        if (this.a != null) {
            this.am = 45;
            if (this.a.a() && this.a.b() == null) {
                this.a = null;
            }
            if (this.a != null) {
                this.a.b();
            }
        } else if (this.bo != -1) {
            this.t(this.bo);
            this.bo = -1;
            this.j = 0;
        }
        if (this.aV > 0) {
            if (a[this.aR][this.aS] < 0) {
                if (a[this.aR][this.aS + 1] == 9 && (b[this.aR][this.aS + 1] & 7) == 3) {
                    ++this.aS;
                    this.aU = this.aU & 0xFFFFFFF8 | 3;
                } else if (a[this.aR - 1][this.aS + 1] == 9 && (b[this.aR - 1][this.aS + 1] & 7) == 3) {
                    ++this.aS;
                    --this.aR;
                    this.aU = this.aU & 0xFFFFFFF8 | 3;
                } else if (a[this.aR + 1][this.aS + 1] == 9 && (b[this.aR + 1][this.aS + 1] & 7) == 3) {
                    ++this.aS;
                    ++this.aR;
                    this.aU = this.aU & 0xFFFFFFF8 | 3;
                } else {
                    this.aU = this.aU & 0xFFFFFFF8 | 0;
                }
            }
            this.aT = b[this.aR][this.aS];
        } else if ((this.k == 0 || this.aT <= 0 && this.k != 5) && !this.w && (this.aU & 0x70) == 0 && this.aC == -1) {
            this.k = this.j;
            boolean bl3 = false;
            if (this.an > 0) {
                this.k = (byte)2;
                --this.an;
                if (this.an == 0) {
                    this.i(this.aR - 1, this.aS);
                    this.j = 0;
                    W = 0;
                }
            } else if (bl) {
                this.p(this.aR, this.aS);
            }
            switch (this.k) {
                case 3: {
                    this.aU &= 0xFFFFFFF7;
                }
                case 1: 
                case 2: 
                case 4: {
                    if (k.a[0].f == 40 || k.a[0].f == 48) break;
                    if ((this.aU & 0x1000) == 0) {
                        bl3 = this.a((int)(-g[this.k]), (int)(-g[this.k + 8]), false);
                        bl = this.b();
                        if (!bl3) break;
                        this.a = 40;
                        this.b = false;
                        n4 = this.k - 1;
                        if (n4 < 0) {
                            n4 = 0;
                        }
                        if ((this.aU & 8) != 0) {
                            if (this.k == 2) {
                                this.m(8);
                                break;
                            }
                            this.m(9);
                            break;
                        }
                        this.m(4 + n4);
                        break;
                    }
                    this.aU = this.aU & 0xFFFFFFF8 | this.k;
                    this.aT = 18;
                    n4 = this.k - 1;
                    if (n4 < 0) {
                        n4 = 0;
                    }
                    this.m(0 + n4);
                    break;
                }
                case 6: {
                    int n7 = n4 = (this.aU & 7) == 2 ? 1 : -1;
                    if (!bl || a[this.aR + n4][this.aS] >= 0) break;
                    this.m(n4 == -1 ? 22 : 20);
                    k.a[this.aR + n4][this.aS] = 32;
                    k.b[this.aR + n4][this.aS] = 18;
                    k.b[this.aR + n4][this.aS] = 4 | (n4 > 0 ? 1 : 0);
                    k.c[this.aR + n4][this.aS] = 30;
                    this.aT = 72;
                    this.j = 0;
                    break;
                }
                case 5: {
                    this.aT = 0;
                    n3 = this.aU & 7;
                    if (!this.b()) break;
                    this.m(13 + n3 - 1);
                    break;
                }
                case 0: {
                    this.aU &= 0xFFFFFFF7;
                    n2 = 0;
                    switch (k.a[0].f) {
                        case 0: 
                        case 2: 
                        case 10: 
                        case 11: 
                        case 12: 
                        case 34: 
                        case 35: 
                        case 40: 
                        case 48: {
                            break;
                        }
                        default: {
                            if ((this.aU & 0x4000) != 0) break;
                            n2 = 1;
                        }
                    }
                    if (n2 != 0) {
                        n = 0 + (this.aU & 7) - 1;
                        if (n < 0) {
                            n = 0;
                        }
                        this.m(n);
                    }
                    this.aZ = this.a == null ? 6 : 0;
                    if (this.aT <= 0) break;
                    this.aT -= 6;
                }
            }
            if (bl) {
                n4 = a[this.aR][this.aS - 1];
                if (!(bl3 || this.k == 5 || this.aT > 0 || n4 != 0 && n4 != 9 && n4 != 8 && n4 != 48 || (a[this.aR][this.aS] & 0xFF) == 35)) {
                    n3 = 0;
                    if (e != null) {
                        n3 = this.a(e[this.aR][this.aS], (byte)0, (byte)3, (byte)4);
                    }
                    if (!this.k || n3 == 0 && n3 != 3) {
                        if ((this.aU & 8) == 0 && k.a[0].f != 11 && k.a[0].f != 10 && k.a[0].f != 12) {
                            this.m(11);
                        }
                        this.b = true;
                        if (this.a <= 0) {
                            this.a = 40;
                            this.b = 0L;
                            this.a((int)i[8], 32, 0);
                            return;
                        }
                    }
                }
            }
            if (bl3) {
                this.x = false;
            } else if (bl && (aP & 0x1F) == 0) {
                n4 = a[this.aR][this.aS - 1] == 0 ? 1 : 0;
                for (n3 = 1; n4 == 0 && n3 <= 4; n4 |= this.a((int)g[n3], (int)g[n3 + 8], true), ++n3) {
                }
                if (n4 == 0) {
                    if (this.x) {
                        this.m(19);
                    } else {
                        this.x = true;
                    }
                }
            }
        } else {
            if (this.w && this.aT <= 0) {
                this.k = this.as ? this.o : this.p;
                this.aU = this.aU & 0xFFFFFFF8 | this.k;
                this.aR += -g[this.k];
                this.aS += -g[this.k + 8];
                bl = this.b();
                this.aT = 18;
                if (k.a[0].f != 4) {
                    this.m(4 + this.k - 1);
                }
            }
            if ((this.aU & 0x70) <= 32 || (this.aU & 0x800) != 0) {
                this.aT -= 6;
                if (this.aT <= 0) {
                    this.aU &= 0xFFFFEF8F;
                    this.aT = 0;
                }
            }
        }
        if (this.cn == 0) {
            this.br();
            if (this.D) {
                this.cm = 8;
                if (this.f()) {
                    this.e(this.bU, this.bV, 5);
                    this.D = false;
                }
            } else if (this.a == null) {
                if (ai && this.k != 0) {
                    ai = false;
                    this.am = 0;
                }
                if (!ai) {
                    this.bq();
                }
            } else {
                this.ar = this.av + this.at;
                this.as = this.aw + this.au;
            }
        }
        if (this.k != 0 && bl) {
            this.m = a[this.aR][this.aS + 1] >= 0;
        }
        this.bb();
        if (this.w && (this.aR < -5 || this.aR > this.ax + 5 || this.aS < -5 || this.aS > this.ay + 5)) {
            this.t();
            if (this.as || this.aq >= this.dL) {
                this.bu = 0;
                this.bt = 12;
                l = (byte)35;
            } else {
                l = (byte)20;
                this.bu = 0;
                this.aW();
                this.H();
                this.e(6, this.bd);
                this.y();
            }
            this.a();
            this.aO = -1;
        }
    }

    public final byte a(int n, int n2, int n3, int n4) {
        int n5 = n + n2;
        if ((n > 0 && n3 == 0 || n < n3 && n3 > 0) && (a[n5][n4] < 0 || a[n5][n4] == 31 || this.d(n5, n4) >= 0)) {
            while (((n = n5) > 0 && n3 == 0 || n < n3 && n3 > 0) && (a[n5 += n2][n4] < 0 || this.d(n5, n4) >= 0 || a[n5][n4] == 31)) {
            }
        }
        return (byte)n;
    }

    public final boolean a(int n, int n2) {
        if (e == null) {
            return false;
        }
        for (int i2 = 0; i2 < e.length; i2 += 3) {
            if (e[i2 + 2] != n2 || e[i2 + 0] - 1 != n && e[i2 + 1] + 1 != n) continue;
            return true;
        }
        return false;
    }

    public final void aU() {
        int n = this.ax - 1;
        for (int i2 = 0; i2 < e.length; i2 += 3) {
            byte by = e[i2 + 2];
            if (by <= 0) continue;
            byte by2 = e[i2 + 1];
            int n2 = e[i2 + 0];
            int n3 = this.a(n2, -1, 0, (int)by);
            k.e[i2 + 0] = n3;
            n2 = n3;
            byte by3 = this.a((int)by2, 1, n, (int)by);
            k.e[i2 + 1] = by3;
            by2 = by3;
            for (int i3 = n2; i3 <= by2; ++i3) {
                this.b(i3, (int)by);
            }
        }
    }

    public final boolean b(int n, int n2) {
        int n3 = this.d(n, n2);
        int n4 = 0;
        if (n3 >= 0) {
            if (n3 == 37 && a[n][n2] == 43) {
                n4 = 0x10000000;
            }
            this.p(n, n2);
            k.a[n][n2] = 9;
            k.b[n][n2] = b[n][n2] & 0xF03FFFFF | n3 << 22 | n4;
            this.e(n, n2, 1);
        }
        int n5 = (this.aU & 0x4000) == 0 ? 0 : 3;
        i i2 = a[n5];
        if (this.d(n, n2) && this.aV <= 0 && i2.f != 40 && i2.f != 48 && i2.f != 47) {
            this.a(0, 16, 0);
        }
        return n3 >= 0;
    }

    public final int d(int n, int n2) {
        if (a[n][n2] < 0) {
            return -1;
        }
        switch (a[n][n2]) {
            case 1: {
                return 34;
            }
            case 45: {
                return 35;
            }
            case 19: 
            case 43: {
                return 37;
            }
            case 46: {
                return 36;
            }
            case 49: {
                return 39;
            }
        }
        return -1;
    }

    public final void aV() {
        int n = this.aO;
        b b2 = a[41];
        Graphics graphics = a;
        graphics.setColor(2496263);
        graphics.fillRect(0, 0, 176, 208);
        switch (n) {
            case 5: {
                Object object;
                int n2;
                if (this.bf == 0) {
                    if ((this.s & 0x20) != 0) {
                        k.a(graphics, a[5][0], 143, 155, 0);
                        if (n == 5 && aP < (n2 = ((b)(object = a[9])).a(0)) * 2) {
                            ((b)object).a(graphics, 0, aP * 2, 143, 155, 0, 0, 0);
                        }
                    }
                    k.a(graphics, a[28][0], 123, 172, 0);
                }
            }
            case 4: {
                int n3;
                int n4;
                if (n == 4) {
                    n4 = -100 + aP * 10;
                    if (n4 > 0) {
                        n4 = 0;
                    }
                } else {
                    n4 = 0;
                }
                k.a[0].a.a(graphics, 12, 0, 7 + n4, 161, 0, 0, 0);
                b2.b(graphics, a[44], 88, 161, 17);
                Object object = String.valueOf(this.bf);
                b2.b(graphics, (String)object, 88, 173, 17);
                if (this.be == 0) {
                    if ((this.s & 0x10) != 0) {
                        b b3;
                        k.a(graphics, a[5][0], 143, 119, 0);
                        if (n == 4 && aP < (n3 = (b3 = a[9]).a(0)) * 2) {
                            b3.a(graphics, 0, aP >> 1, 143, 119, 0, 0, 0);
                        }
                    }
                    k.a(graphics, a[28][0], 123, 136, 0);
                }
            }
            case 3: {
                int n3;
                int n4;
                if (n == 3) {
                    n4 = -100 + aP * 10;
                    if (n4 > 0) {
                        n4 = 0;
                    }
                } else {
                    n4 = 0;
                }
                k.a[0].a.a(graphics, 10, 0, 7 + n4, 129, 0, 0, 0);
                b2.b(graphics, a[43], 88, 125, 17);
                Object object = String.valueOf(this.be);
                b2.b(graphics, (String)object, 88, 137, 17);
                if (this.bd == this.bc) {
                    if ((this.s & 8) != 0) {
                        b b4;
                        k.a(graphics, a[5][0], 143, 83, 0);
                        if (n == 3 && aP < (n3 = (b4 = a[9]).a(0)) * 2) {
                            b4.a(graphics, 0, aP >> 1, 143, 83, 0, 0, 0);
                        }
                    }
                    k.a(graphics, a[28][0], 123, 100, 0);
                }
            }
            case 2: {
                int n3;
                int n4;
                if (n == 2) {
                    n4 = -100 + aP * 10;
                    if (n4 > 0) {
                        n4 = 0;
                    }
                } else {
                    n4 = 0;
                }
                a[k.c(3)].a(graphics, 0, 7 + n4, 89, 0, 0, 0);
                b2.b(graphics, a[114], 88, 89, 17);
                Object object = this.bd + "/" + this.bc;
                b2.b(graphics, (String)object, 88, 101, 17);
                if (this.bb == this.ba) {
                    if ((this.s & 4) != 0) {
                        b b5;
                        k.a(graphics, a[5][0], 143, 47, 0);
                        if (n == 2 && aP < (n3 = (b5 = a[9]).a(0)) >> 1) {
                            b5.a(graphics, 0, aP * 2, 143, 47, 0, 0, 0);
                        }
                    }
                    k.a(graphics, a[28][0], 123, 64, 0);
                }
            }
            case 1: {
                int n4;
                int n2;
                if (n == 1) {
                    n4 = -100 + aP * 10;
                    if (n4 > 0) {
                        n4 = 0;
                    }
                } else {
                    n4 = 0;
                }
                a[k.c(2)].a(graphics, 0, 7 + n4, 53, 0, 0, 0);
                b2.b(graphics, a[109], 88, 53, 17);
                if (n == 1) {
                    n2 = aP >> 1;
                    if (n2 > this.bb) {
                        n2 = this.bb;
                    }
                } else {
                    n2 = this.bb;
                }
                Object object = n2 + "/" + this.ba;
                b2.b(graphics, (String)object, 88, 65, 17);
            }
            case 0: {
                int n5;
                int n4;
                if (n == 0) {
                    n4 = -100 + aP * 10;
                    n5 = n4 - 176;
                    if (n4 > 0) {
                        n4 = 0;
                    }
                    if (n5 > 0) {
                        n5 = 0;
                    }
                } else {
                    n4 = 0;
                    n5 = 0;
                }
                b2.a(graphics, a[g[this.ap][this.aq]], 88 + n4, 10, 17);
                b2.a(graphics, a[41], 88 + n5, 20, 17);
            }
        }
        a[41].a(a, a[this.aO == 5 ? 98 : 53], 4, 206, 36);
    }

    public static final int a(byte[] byArray, int n) {
        return byArray[n] & 0xFF | (byArray[n + 1] & 0xFF) << 8;
    }

    public static final int b(byte[] byArray, int n) {
        return byArray[n] & 0xFF | (byArray[n + 1] & 0xFF) << 8 | (byArray[n + 2] & 0xFF) << 16 | (byArray[n + 3] & 0xFF) << 24;
    }

    public final int e(int n, int n2) {
        int n3 = k.a(i, n);
        if ((n3 += n2) < 0) {
            n3 = 0;
        }
        k.i[n] = (byte)(n3 & 0xFF);
        k.i[n + 1] = (byte)(n3 >> 8 & 0xFF);
        return n3;
    }

    public final void aW() {
        for (int i2 = 0; i2 < this.X; ++i2) {
            this.a(this.ap, this.aq, d[i2 << 1] & 0xFF, d[(i2 << 1) + 1] & 0xFF);
        }
    }

    public final int d() {
        return this.e(4, this.bb);
    }

    public final void p(int n) {
        switch (n) {
            case 0: {
                df = 0;
                dg = 0;
                dh = 0;
                this.r = this.a(this.ap, this.aq);
                this.s = 0;
                return;
            }
            case 1: {
                df = k.a(i, 4);
                df += this.bb;
                this.t = false;
                return;
            }
            case 2: {
                k.i[4] = (byte)(df & 0xFF);
                k.i[5] = (byte)(df >> 8 & 0xFF);
                return;
            }
            case 3: {
                dg = k.a(i, 6);
                dg += this.bd;
                return;
            }
            case 4: {
                k.i[6] = (byte)(dg & 0xFF);
                k.i[7] = (byte)(dg >> 8 & 0xFF);
                return;
            }
            case 5: {
                dh = i[2];
                this.J = 0;
                if ((dh & 8) == 0 && dg >= h.b[1]) {
                    this.J = 1;
                    return;
                }
                if ((dh & 0x10) != 0 || dg < h.b[2]) break;
                this.J = 2;
                return;
            }
            case 6: {
                try {
                    k.a[28] = k.a("/ui.f", 4);
                    return;
                }
                catch (Exception exception) {
                    return;
                }
            }
            case 7: {
                this.a(this.ap, this.aq, (byte)2);
                this.K = 0;
                return;
            }
            case 8: {
                int n2;
                int n3;
                for (n3 = n2 = (dh & 0xE0) >> 5; n3 < 4 && df >= h.a[n3]; ++n3) {
                }
                if (n2 < n3) {
                    i[2] = (byte)(i[2] & 0xFFFFFF1F);
                    i[2] = (byte)(i[2] | n3 << 5 & 0xE0);
                    this.A();
                    this.K = n3;
                }
            }
            case 9: {
                this.aW();
                return;
            }
            case 10: {
                this.a();
                System.gc();
                return;
            }
            case 11: {
                if (this.ao < 99 && this.bb == this.ba && (this.r & 4) == 0) {
                    this.a(this.ap, this.aq, (byte)4);
                    this.s = (byte)(this.s | 4);
                    ++this.ao;
                }
                if (this.ao < 99 && this.bd == this.bc && (this.r & 8) == 0) {
                    this.a(this.ap, this.aq, (byte)8);
                    this.s = (byte)(this.s | 8);
                    ++this.ao;
                }
                if (this.ao < 99 && this.be == 0 && (this.r & 0x10) == 0) {
                    this.a(this.ap, this.aq, (byte)16);
                    this.s = (byte)(this.s | 0x10);
                    ++this.ao;
                }
                if (this.ao < 99 && this.bf == 0 && (this.r & 0x20) == 0) {
                    this.a(this.ap, this.aq, (byte)32);
                    this.s = (byte)(this.s | 0x20);
                    ++this.ao;
                }
                this.aY();
                this.y();
                this.I = false;
                this.H = true;
            }
        }
    }

    public final void aX() {
        switch (this.aO) {
            case 0: {
                if (aP <= 40 && !this.t) break;
                ++this.aO;
                this.a();
                return;
            }
            case 1: {
                if ((aP <= this.bb << 1 || aP <= 40) && !this.t) break;
                ++this.aO;
                this.a();
                return;
            }
            case 2: {
                if (aP <= 40 && !this.t) break;
                ++this.aO;
                this.a();
                return;
            }
            case 3: {
                if (aP <= 10 && !this.t) break;
                ++this.aO;
                this.a();
                return;
            }
            case 4: {
                if (aP <= 10 && !this.t) break;
                ++this.aO;
                this.a();
                this.t = false;
            }
        }
    }

    public final long a(int n) {
        for (int i2 = 0; i2 < 12; ++i2) {
            for (int i3 = 0; i3 < 12; ++i3) {
                long l = a[i2][i3];
                if (l == 0L || this.a(l, (byte)6, (byte)5) != n) continue;
                return l;
            }
        }
        return -1L;
    }

    public final void aY() {
        long l = this.a(this.aq);
        if ((this.aq == 0 || this.a(l, (byte)11, (byte)3) > 1) && l >= 0L && (this.a(this.ap, this.aq + 1) & 0x40) == 0) {
            ea = this.aq + 1;
            this.a(this.ap, ea, (byte)64);
            this.aa = true;
            return;
        }
        ea = this.aq;
    }

    public final void aZ() {
        this.cn();
    }

    public final void e(int n, int n2, int n3) {
        int n4 = this.T << 1;
        k.a[n4] = (byte)n;
        k.a[n4 + 1] = (byte)n2;
        k.c[this.T] = (byte)n3;
        k.b[this.T] = 0;
        this.T = this.T + 1 & 7;
    }

    public final void ba() {
        --this.ao;
        ++this.bf;
        if (this.ao >= 0) {
            this.ca();
            this.m = i[8];
            this.v();
            this.aU = 0;
            this.aV = 0;
            this.k = 0;
            this.j = 0;
            return;
        }
        l = (byte)12;
    }

    public final void q(int n) {
        if (n < 0) {
            return;
        }
        byte by = q[n];
        byte by2 = r[n];
        int n2 = a[by][by2] & 0xFF;
        int n3 = a[by][by2] >> 8;
        if ((n3 & 0xF0) != 0) {
            return;
        }
        if (n2 != 7 || (n3 & 0xFF00) >> 8 != n) {
            System.out.println("!!!!!!!!!!!!!! door missing");
        }
        int n4 = n3 & 0xF;
        if (--n4 == 0) {
            n3 = n3 & 0xFFFFFF0F | 0x10;
            this.a((int)by, by2 - 1, 1, 0, 1);
            this.a((int)by, by2 - 1, -1, 0, 1);
            int n5 = a[by][by2 - 1] >> 8;
            k.a[by][by2 - 1] = (n5 |= 0x200) << 8 | a[by][by2 - 1] & 0xFF;
            k.c[by][by2] = 24;
        } else {
            n3 = n3 & 0xFFFFFFF0 | n4;
        }
        k.a[by][by2] = n3 << 8 | n2;
        this.C(2);
    }

    public final void h(int n, int n2) {
        int n3 = a[n][n2] >> 8;
        if ((n3 & 0xF0) == 0) {
            k.a[n][n2] = (n3 |= 0x10) << 8 | 7;
            k.c[n][n2] = 24;
        }
    }

    public final void i(int n, int n2) {
        int n3 = a[n][n2] >> 8;
        if ((a[n][n2] & 0xFF) != 7) {
            return;
        }
        if ((n3 & 0xF0) == 0) {
            return;
        }
        if (a[n][n2] == 32) {
            return;
        }
        this.C(10);
        k.a[n][n2] = (n3 &= 0xFFFFFF0F) << 8 | 7;
        this.a(n, n2 - 1, 1, 0, 0);
        this.a(n, n2 - 1, -1, 0, 0);
        if (this.d(n, n2)) {
            this.b = 0L;
            this.bk = 0;
            this.a((int)i[8], 48, 0);
        } else {
            switch (a[n][n2]) {
                case 0: 
                case 1: 
                case 19: 
                case 43: 
                case 45: {
                    k.a[n][n2] = -1;
                    this.b(n, n2);
                    this.o(n, n2);
                }
            }
        }
        k.c[n][n2] = 24;
    }

    public final void r(int n) {
        if (n < 0) {
            return;
        }
        this.i(q[n], r[n]);
    }

    public final void bb() {
        int n = (this.aU & 0x4000) == 0 ? 0 : 3;
        i i2 = a[n];
        int n2 = -1;
        boolean bl = true;
        boolean bl2 = false;
        boolean bl3 = i2.a();
        if (bl3) {
            this.aU &= 0xFFFFDFFF;
        }
        if (n == 3) {
            if (bl3) {
                this.aU &= 0xFFFFB7FF;
                n2 = this.e();
            }
        } else {
            switch (i2.f) {
                case 41: 
                case 42: 
                case 43: 
                case 44: 
                case 45: 
                case 46: {
                    if (!bl3) break;
                    n2 = 0 + (this.aU & 7) - 1;
                    this.j = 0;
                    this.k = 0;
                    this.aT = 0;
                    W = 0;
                    break;
                }
                case 1: 
                case 3: {
                    if (bl3) {
                        n2 = 0 + (this.aU & 7) - 1;
                    }
                    bl2 = true;
                    break;
                }
                case 36: 
                case 37: 
                case 38: 
                case 39: {
                    if (!bl3) break;
                    n2 = 4 + (this.aU & 7) - 1;
                    break;
                }
                case 47: {
                    this.aT = 0;
                    this.k = 0;
                    this.j = 0;
                    if ((aP & 1) == 0) {
                        int n3 = this.aR - 2 + aP % 5;
                        int n4 = this.aS - 2 + aP % 3;
                        if (n3 == this.aR && (n4 == this.aS || n4 == this.aS - 1)) {
                            n3 += (aP >> 1 & 1) == 0 ? 1 : -1;
                        }
                        this.e(n3, n4, aP * 3 % 5);
                    }
                    if (!bl3) break;
                    n2 = 0 + (this.aU & 7) - 1;
                    this.aE = -1;
                    this.aD = -1;
                    this.aC = -1;
                    break;
                }
                case 40: 
                case 48: {
                    this.aT = 0;
                    this.k = 0;
                    this.j = 0;
                    if (i2.h == 0) {
                        if (i2.g == (i2.f == 40 ? 12 : 6)) {
                            this.C(1);
                        }
                        if (i2.g == (i2.f == 40 ? 13 : 6)) {
                            this.bK();
                        }
                    }
                    if (!i2.a()) break;
                    this.l = System.currentTimeMillis();
                    n2 = 0 + (this.aU & 7) - 1;
                    this.aE = -1;
                    this.aD = -1;
                    this.aC = -1;
                    break;
                }
                case 35: {
                    bl2 = true;
                    n2 = 35;
                    break;
                }
                case 34: {
                    bl2 = true;
                    n2 = 34;
                    break;
                }
                case 0: {
                    bl2 = true;
                    n2 = 0;
                    break;
                }
                case 2: {
                    bl2 = true;
                    n2 = 2;
                    break;
                }
                case 9: {
                    if (this.m) break;
                    n2 = 27;
                    break;
                }
                case 8: {
                    if (this.m) break;
                    n2 = 26;
                    break;
                }
                case 27: {
                    if (this.m) break;
                    n2 = 9;
                    break;
                }
                case 26: {
                    if (this.m) break;
                    n2 = 8;
                    break;
                }
                case 4: 
                case 6: {
                    if (!this.m) break;
                    n2 = i2.f;
                    break;
                }
                case 5: {
                    if (this.m) break;
                    n2 = 24;
                    break;
                }
                case 7: {
                    if (this.m) break;
                    n2 = 25;
                    break;
                }
                case 24: {
                    if (!this.m) break;
                    n2 = 5;
                    break;
                }
                case 25: {
                    if (!this.m) break;
                    n2 = 7;
                    break;
                }
                case 20: 
                case 21: 
                case 22: 
                case 23: 
                case 30: 
                case 31: 
                case 32: 
                case 33: {
                    if (!bl3) break;
                    bl = false;
                    W = 0;
                    break;
                }
                case 19: {
                    if (!bl3) break;
                    bl = false;
                    this.ba();
                    break;
                }
                case 13: 
                case 14: 
                case 15: 
                case 16: 
                case 28: 
                case 29: {
                    if (bl3) {
                        W = 0;
                        this.k = 0;
                        this.aT = 0;
                        n2 = 0 + (this.aU & 7) - 1;
                        break;
                    }
                    if ((this.aU & 0x2000) != 0 || i2.g != 2 || i2.h != 0) break;
                    int n5 = this.aR - g[this.aU & 7];
                    int n6 = this.aS - g[(this.aU & 7) + 8];
                    if (i[9] >= 8 && i2.g == 2 && i2.h == 0) {
                        this.e(n5, n6, -1);
                    }
                    this.c(n5, n6, this.aU & 7);
                    this.j = 0;
                    if (i2.g == 3 && i2.h == 0 && a[n5][n6] != -1) {
                        k.s(200);
                    }
                    W = 0;
                    break;
                }
                case 11: {
                    if (a[this.aR][this.aS - 1] == -1) {
                        n2 = 0 + (this.aU & 7) - 1;
                        break;
                    }
                    if (!bl3 || a[this.aR][this.aS - 1] == -1) break;
                    this.b = 0L;
                    this.a((int)i[8], 32, 0);
                    break;
                }
                case 17: 
                case 18: {
                    if (bl3) {
                        n2 = 0 + (this.aU & 7) - 1;
                        this.aT = 0;
                        break;
                    }
                    if (i2.g <= 0 || this.aC == -1) break;
                    int n7 = (this.aU & 7) == 2 ? this.aR + 1 : this.aR - 1;
                    int n8 = a[n7][this.aS] >> 8;
                    int n9 = a[n7][this.aS] & 0xFF;
                    n8 |= 0x100;
                    if (n9 == 9) {
                        --this.aW;
                    } else {
                        --this.aX;
                    }
                    k.a[n7][this.aS] = n8 << 8 | n9;
                    this.q(n8 & 0xFF);
                    this.aE = -1;
                    this.aC = -1;
                    break;
                }
                case 10: {
                    if (bl3) {
                        this.aU &= 0xFFFFF7FF;
                        n2 = this.e();
                        break;
                    }
                    this.b = 26L;
                    break;
                }
                case 12: {
                    if (this.bn >= 104) break;
                    this.bn += 12;
                    break;
                }
                default: {
                    n2 = 36 + (this.aU & 7) - 1;
                }
            }
        }
        this.am = bl2 ? --this.am : 45;
        if (n2 != -1) {
            this.m(n2);
        }
        if (bl) {
            i2.b();
        }
        this.b = this.b > 0 ? (this.b = this.b - 1) : 0;
    }

    public final int e() {
        int n = 0;
        if (this.m <= 0) {
            this.C(0);
            n = 12;
            this.aY = 52;
        } else {
            n = 0 + (this.aU & 7) - 1;
            this.aU = this.aU & 0xFFFFFF8F | 0;
            this.b = 26L;
        }
        this.k = 0;
        return n;
    }

    public static final void s(int n) {
        if (l) {
            k.a.a.vibrate(n);
        }
    }

    public final void bc() {
        if (this.n <= 0) {
            int n = this.bk > 0 ? 1 : -1;
            this.bk -= n;
            if (this.bk != 0) {
                if (a[this.bi][this.bj] == 48) {
                    int n2 = b[this.bi][this.bj];
                    int n3 = this.bj + ((n2 & 8) == 0 ? -1 : 1);
                    if (a[this.bi + n][n3] < 0) {
                        k.a[this.bi + n][n3] = a[this.bi][n3];
                        k.a[this.bi][n3] = -1;
                        k.b[this.bi + n][n3] = b[this.bi][n3];
                        k.b[this.bi][n3] = this.n;
                    } else {
                        int n4 = this.aR - n;
                        while (a[n4][this.aS] == 32) {
                            k.a[n4][this.aS] = -1;
                            n4 -= n;
                        }
                        this.bk = 0;
                        return;
                    }
                }
                k.a[this.bi + n][this.bj] = a[this.bi][this.bj];
                k.a[this.bi][this.bj] = -1;
                this.b(this.bi, this.bj);
                this.bi += n;
                k.b[this.bi][this.bj] = this.bg | Integer.MIN_VALUE;
                k.b[this.bi][this.bj] = this.n = (byte)18;
            } else {
                if (a[this.bi][this.bj] == 48) {
                    int n5 = b[this.bi][this.bj];
                    int n6 = this.bj + ((n5 & 8) == 0 ? -1 : 1);
                    k.b[this.bi][n6] = 0;
                } else {
                    k.b[this.bi][this.bj] = this.bh;
                }
                k.b[this.bi][this.bj] = 0;
                this.bh = -1;
                this.c(this.bi, this.bj);
            }
            this.p(this.bi - n, this.bj);
            return;
        }
        k.b[this.bi][this.bj] = this.n = (byte)(this.n - 6);
        if ((this.bk == 1 || this.bk == -1) && this.n <= 6 && (this.aU & 0x70) == 0) {
            this.m((this.aU & 7) == 4 ? 23 : 21);
        }
    }

    public final void bd() {
        int n = aP % 89;
        this.aK = n < 15 ? 0 : (n < 45 ? 48 * (n - 15) / 30 : (n < 60 ? 48 : 48 - 48 * (n - 60) / 30));
        this.aL = this.aK > 0 ? (this.aK - 1) / 24 + 2 : 1;
        n = aP % 44;
        this.aM = n < 7 ? 0 : (n < 22 ? 48 * (n - 7) / 15 : (n < 30 ? 48 : 48 - 48 * (n - 30) / 15));
        this.aN = this.aM > 0 ? (this.aM - 1) / 24 + 2 : 1;
    }

    public final void be() {
        int n = k[this.az << 1] - this.aR;
        int n2 = k[(this.az << 1) + 1] - this.aS;
        if (this.i == 2 && this.az == 2) {
            n = 10;
            n2 = -8;
        }
        if (n2 == 0) {
            if (n < 0) {
                this.ac = 12;
                return;
            }
            this.ac = 4;
            return;
        }
        if (n == 0) {
            if (n2 < 0) {
                this.ac = 0;
                return;
            }
            this.ac = 8;
            return;
        }
        int n3 = n * 128 / n2;
        if (n3 > 0) {
            if (n3 < 128) {
                if (n > 0) {
                    this.ac = 7;
                    return;
                }
                this.ac = 15;
                return;
            }
            if (n3 > 128) {
                if (n > 0) {
                    this.ac = 5;
                    return;
                }
                this.ac = 13;
                return;
            }
            if (n > 0) {
                this.ac = 6;
                return;
            }
            this.ac = 14;
            return;
        }
        if (n3 > -128) {
            if (n < 0) {
                this.ac = 9;
                return;
            }
            this.ac = 1;
            return;
        }
        if (n3 < -128) {
            if (n < 0) {
                this.ac = 11;
                return;
            }
            this.ac = 3;
            return;
        }
        if (n < 0) {
            this.ac = 10;
            return;
        }
        this.ac = 2;
    }

    public final void bf() {
        switch (this.i) {
            case 2: {
                this.bp();
                this.bg();
                return;
            }
            case 1: {
                this.bo();
                return;
            }
            case 3: {
                this.bn();
                return;
            }
            case 4: {
                this.bj();
                return;
            }
            case 5: {
                this.bh();
            }
        }
    }

    public final void bg() {
        if (this.d(61, 3) && this.aT == 6) {
            this.e(this.aR, this.aS, 5);
            this.d = false;
        }
        if (this.a == null && (this.d(60, 3) || this.d(61, 3))) {
            this.b(true);
            this.N = true;
            this.cm();
            this.u();
            this.ap = 0;
            this.aq = 0;
            this.n();
        }
        if (this.aF == 2) {
            k.a[11][50] = -1;
        }
    }

    public final void j(int n, int n2) {
        for (int i2 = -1; i2 < 2; ++i2) {
            for (int i3 = -1; i3 < 2; ++i3) {
                int n3 = (this.ar + n) / 24 + i3;
                int n4 = (this.as + n2) / 24 + i2;
                if (!this.d(n3, n4)) continue;
                this.a(1, 48, 0);
            }
        }
    }

    public final void bh() {
        i i2 = a[5];
        if (this.ad == 12) {
            if (this.ae++ > 100) {
                this.ad = 15;
                this.o(11, 11);
            }
            i2.b();
            return;
        }
        if (this.ad == -1) {
            if (this.aR * 24 >= 360) {
                this.ad = 10;
                i2.a(10);
                return;
            }
        } else if (this.ad != 15 && this.ad != -1) {
            int n;
            int n2 = -1;
            int n3 = this.aR * 24 + 12;
            int n4 = this.aS * 24;
            int n5 = this.ai + 24;
            if (this.ad == 13) {
                n2 = 13;
                if (n3 > n5) {
                    this.ac = true;
                }
            }
            if (this.af <= 0) {
                n = 1;
            } else {
                int n6 = n = aP % this.af == 0 ? 2 : 1;
            }
            if (this.ad == 6 || this.ad == 7) {
                int n7 = n = (aP & 0xB) == 0 ? 2 : n;
            }
            if (!(this.ab || this.ad != 0 && this.ad != 1)) {
                if (this.ad == 0) {
                    this.di = 36;
                    this.di ^= 0xFFFFFFFF;
                    ++this.di;
                } else {
                    this.di = 36;
                }
                if (n4 < 504 && (n3 == n5 + this.di || aP % 76 == 0)) {
                    this.ab = true;
                }
            }
            while (n-- > 0) {
                switch (this.ad) {
                    case 13: {
                        if (i2.a()) {
                            n2 = 0;
                            this.ad = 0;
                            this.ac = false;
                            break;
                        }
                        if (!this.ac) break;
                        i2.b();
                        break;
                    }
                    case 4: 
                    case 5: {
                        if (i2.a()) {
                            n2 = this.ad == 4 ? 0 : 1;
                            this.ad = n2;
                        }
                        this.ab = false;
                        this.di = 0;
                        break;
                    }
                    case 10: 
                    case 11: {
                        if (n3 > n5 && n5 < 504) {
                            n2 = 1;
                            this.ad = 1;
                        } else if (n3 < n5 && n5 > 360) {
                            n2 = 0;
                            this.ad = 0;
                        }
                        this.ab = false;
                        this.di = 0;
                        break;
                    }
                    case 6: {
                        if (n4 >= 504) {
                            if (n3 >= n5 - 48) {
                                n2 = 8;
                                this.ad = 8;
                                break;
                            }
                            this.ai -= 2;
                            break;
                        }
                        if (n5 < 360) break;
                        n2 = 0;
                        this.ad = 0;
                        break;
                    }
                    case 7: {
                        if (n4 >= 504) {
                            if (n3 <= n5 + 48) {
                                n2 = 9;
                                this.ad = 9;
                                break;
                            }
                            this.ai += 2;
                            break;
                        }
                        if (n5 > 504) break;
                        n2 = 1;
                        this.ad = 1;
                        break;
                    }
                    case 0: {
                        if (n4 >= 504 && n5 > 360) {
                            if (n3 < n5) {
                                n2 = 6;
                                this.ad = 6;
                                break;
                            }
                            --this.ai;
                            break;
                        }
                        if (this.ab) {
                            n2 = 2;
                            this.ad = 2;
                            break;
                        }
                        if (n5 <= 360) {
                            n2 = 1;
                            this.ad = 1;
                            break;
                        }
                        --this.ai;
                        break;
                    }
                    case 1: {
                        if (n4 >= 504 && n5 < 504) {
                            if (n3 < n5) {
                                ++this.ai;
                                break;
                            }
                            n2 = 7;
                            this.ad = 7;
                            break;
                        }
                        if (this.ab) {
                            n2 = 3;
                            this.ad = 3;
                            break;
                        }
                        if (n5 >= 504) {
                            n2 = 0;
                            this.ad = 0;
                            break;
                        }
                        ++this.ai;
                        break;
                    }
                    case 8: {
                        if (i2.a()) {
                            n2 = 10;
                            this.ad = 10;
                        }
                        if (i2.g < 4 || n4 < 504 || n3 < n5 - 48 || n3 > n5) break;
                        this.a(1, 48, 0);
                        break;
                    }
                    case 9: {
                        if (i2.a()) {
                            n2 = 11;
                            this.ad = 11;
                        }
                        if (i2.g < 4 || n4 < 504 || n3 < n5 || n3 > n5 + 48) break;
                        this.a(1, 48, 0);
                        break;
                    }
                    case 3: {
                        if (i2.g == 5 && i2.h == 0) {
                            this.bl = 30;
                        }
                        if (i2.a()) {
                            n2 = 11;
                            this.ad = 11;
                            this.ab = false;
                            this.di = 0;
                        }
                        if (i2.g < 7 || n4 >= 504 || n3 != n5 + this.di) break;
                        this.a(1, 48, 0);
                        break;
                    }
                    case 2: {
                        if (i2.g == 5 && i2.h == 0) {
                            this.bl = 30;
                        }
                        if (i2.a()) {
                            n2 = 10;
                            this.ad = 10;
                            this.ab = false;
                            this.di = 0;
                        }
                        if (i2.g < 7 || n4 >= 504 || n3 != n5 + this.di) break;
                        this.a(1, 48, 0);
                    }
                }
                if (n4 < 504 || n3 < n5 - 24 || n3 > n5 - 24) continue;
                this.a(1, 48, (int)h[this.aU & 7]);
            }
            if ((this.ad == 8 || this.ad == 9) && i2.g == 5) {
                this.bl();
            }
            if (this.ad != 6 && this.ad != 7) {
                for (int i3 = 21; i3 < 23; ++i3) {
                    for (int i4 = n5 / 24 - 1; i4 < n5 / 24 - 2 + 4; ++i4) {
                        if (a[i4][i3] != 0) continue;
                        if ((b[i4][i3] & 7) == 3 && this.ad != 13) {
                            --this.af;
                            switch (this.ad) {
                                case 0: 
                                case 2: 
                                case 4: 
                                case 8: 
                                case 10: {
                                    n2 = 4;
                                    this.ad = 4;
                                    break;
                                }
                                case 1: 
                                case 3: 
                                case 5: 
                                case 9: 
                                case 11: {
                                    n2 = 5;
                                    this.ad = 5;
                                }
                            }
                        }
                        k.a[i4][i3] = -1;
                        this.b(i4, i3);
                        k.a[i4][i3] = 30;
                        k.c[i4][i3] = 24;
                        k.b[i4][i3] = 4;
                    }
                }
            }
            if (this.af <= 0) {
                this.ad = 12;
                this.ae = 0;
                n2 = 12;
            }
            if (n2 != -1) {
                i2.a(n2);
                return;
            }
            i2.b();
        }
    }

    public final void bi() {
        int n = this.f();
        if (this.aR == n || this.aR == n + 1) {
            i i2 = a[5];
            int n2 = i2.b + -40;
            int n3 = i2.b + 256;
            int n4 = (i2.a.b[i2.f] + i2.g) * 5;
            int n5 = k.a[0].b;
            if (n5 > (n2 -= (n4 = (i2.a.f[n4 + 3] << 0) * 1 / 1)) && n5 < (n3 -= n4) && !this.i) {
                this.a(1, 48, this.aR == n ? 4 : 2);
            }
        }
    }

    public final void k(int n, int n2) {
        if (n < 0 || n2 < 0) {
            return;
        }
        k.a[n][n2] = -1;
        k.a[n + 1][n2] = -1;
    }

    public final void l(int n, int n2) {
        if (n < 0 || n2 < 0) {
            return;
        }
        k.a[n][n2] = 50;
        k.a[n + 1][n2] = 50;
    }

    public final boolean c(int n, int n2) {
        boolean bl = false;
        for (int i2 = n; i2 <= n + 1; ++i2) {
            for (int i3 = n2; i3 >= n2 - 1; --i3) {
                if (a[i2][i3] != 0) continue;
                this.g(i2, i3);
                this.p(i2, i3);
                k.a[i2][i3] = -1;
                this.b(i2, i3);
                bl = true;
            }
        }
        return bl;
    }

    public final int f() {
        int n = this.ag > 0 ? 1 : 0;
        return 10 + this.ag * (2 + n);
    }

    public final int g() {
        i i2 = a[5];
        int n = i2.b + -40;
        int n2 = (i2.a.b[i2.f] + i2.g) * 5;
        n2 = (i2.a.f[n2 + 3] << 0) * 1 / 1;
        n -= n2;
        return this.ay * (n += this.as) / (this.ay * 24);
    }

    public final boolean d() {
        int n = this.f();
        int n2 = this.g();
        boolean bl = false;
        for (int i2 = n; i2 <= n + 1; ++i2) {
            for (int i3 = n2; i3 <= 10; ++i3) {
                if (a[i2][i3] != 0) continue;
                this.g(i2, i3);
                this.p(i2, i3);
                k.a[i2][i3] = -1;
                this.b(i2, i3);
                bl = true;
            }
        }
        return bl;
    }

    public final int h() {
        int n = this.aR - 10;
        int n2 = n / 3;
        if (n == n2 * 3 + 2) {
            n2 += aP % 50 / 25;
        }
        return n2;
    }

    public final void bj() {
        if (this.ad == 5) {
            if (this.X) {
                return;
            }
            this.X = true;
        }
        i i2 = a[5];
        ++this.ae;
        int n = -1;
        i i3 = a[4];
        int n2 = -1;
        int n3 = this.f();
        boolean bl = false;
        if (a[this.E][2] == -1) {
            k.a[this.E][2] = 31;
        }
        if (a[this.F][2] == -1) {
            k.a[this.F][2] = 31;
        }
        switch (this.ad) {
            case 0: {
                if (this.aR < 10) break;
                this.ad = 6;
                this.ae = 0;
                break;
            }
            case 6: {
                if (this.ae <= 6) break;
                this.ad = 1;
                n = 2;
                this.ae = 0;
                break;
            }
            case 1: {
                boolean bl2 = false;
                if (this.ae > 40) {
                    this.ad = 2;
                    this.ae = 0;
                    break;
                }
                if (this.ae <= 20) break;
                this.c(n3, 8);
                this.l(n3, 8);
                this.B = n3;
                this.C = 8;
                break;
            }
            case 7: {
                this.k(this.B, this.C);
                this.B = -1;
                this.C = -1;
                if (this.ae > 80) {
                    this.ad = 8;
                    this.bM();
                }
                if ((this.ae & 0x6F) != 1) break;
                this.C(8);
                break;
            }
            case 3: {
                boolean bl3 = false;
                if (this.ae <= 26) break;
                if (this.af > 0) {
                    if (this.H == 10) {
                        this.ad = 9;
                        this.ae = 0;
                        break;
                    }
                    if (this.H != 2 && this.H != 1) break;
                    this.ad = 4;
                    this.ae = 0;
                    n = 2;
                    break;
                }
                this.ad = 7;
                this.ae = 0;
                break;
            }
            case 2: {
                boolean bl4 = false;
                if (this.c(n3, 8)) {
                    --this.af;
                    this.H = this.ad;
                    this.k(this.B, this.C);
                    this.B = -1;
                    this.C = -1;
                    this.H = this.ad;
                    this.ad = 3;
                    n = 3;
                    this.C(4);
                }
                if (this.ae > 15 && i2.f != 6) {
                    n = 6;
                }
                if (this.ae <= 30) break;
                this.ad = 4;
                this.ae = 0;
                n = 0;
                this.k(this.B, this.C);
                this.B = -1;
                this.C = -1;
                break;
            }
            case 4: {
                int n4;
                int n5 = n4 = this.af <= 1 ? 5 : 10;
                if (this.ae >= n4) {
                    this.ad = 5;
                    this.ae = 0;
                    n = 4;
                } else if (this.ae > n4 >> 1 && i2.f != 1) {
                    n = 1;
                }
                this.d();
                this.bi();
                break;
            }
            case 5: {
                int n6 = i2.b + -40;
                int n7 = (i2.a.b[i2.f] + i2.g) * 5;
                n7 = (i2.a.f[n7 + 3] << 0) * 1 / 1;
                if ((n6 -= n7) <= 72 - this.as + 40) {
                    this.I = 0;
                    this.bl();
                    this.ad = 10;
                    this.B = n3;
                    this.C = 4;
                    this.l(this.B, this.C);
                }
                this.d();
                this.bi();
                break;
            }
            case 9: {
                this.ae -= 2;
                this.bi();
                int n8 = i2.b + -40;
                int n9 = (i2.a.b[i2.f] + i2.g) * 5;
                n9 = (i2.a.f[n9 + 3] << 0) * 1 / 1;
                if ((n8 -= n9) < 240 - this.as + 40) break;
                this.ad = 6;
                this.ae = 0;
                this.ag = this.h();
                break;
            }
            case 10: {
                --this.ae;
                this.bi();
                ++this.A;
                if (this.A == 28) {
                    n = 7;
                }
                if (this.A < 50) break;
                this.A = 0;
                this.ad = 11;
                this.k(this.B, this.C);
                this.B = -1;
                this.C = -1;
                n = 8;
                n2 = 2;
                this.j = true;
                break;
            }
            case 11: {
                --this.ae;
                ++this.A;
                if (this.A >= 12) {
                    this.A = 0;
                    this.ad = 9;
                    n = 4;
                    this.i = false;
                    this.j = false;
                    break;
                }
                if (this.i) break;
                this.bk();
            }
        }
        if (n == -1) {
            i2.b();
        } else {
            i2.a(n);
        }
        if (this.j) {
            if (n2 == -1) {
                i3.b();
                return;
            }
            i3.a(n2);
        }
    }

    public final void bk() {
        int n = this.f();
        boolean bl = false;
        if (this.aS == 4 && this.aR >= n - 3 && this.aR <= n + 4) {
            this.a(1, 64, this.aR == n ? 4 : 2);
            this.i = true;
        }
    }

    public final void bl() {
        this.bl = 30;
        if (a[this.E][this.G] == -1) {
            k.a[this.E][this.D] = 0;
            this.p(this.E, this.D);
        }
        if (a[this.F][this.G] == -1) {
            k.a[this.F][this.D] = 0;
            this.p(this.F, this.D);
        }
    }

    public final void bm() {
        this.ad = -1;
        this.af = 5;
    }

    public final void bn() {
        int n;
        int n2;
        i i2 = a[5];
        int n3 = this.bG;
        int n4 = this.bH;
        int n5 = this.aR - 7;
        int n6 = this.aR + 7;
        int n7 = this.aS + 7;
        int n8 = this.aS - 7;
        for (n2 = 15; n2 <= 22; ++n2) {
            for (n = 14; n <= 21; ++n) {
                if (n > n5 && n < n6 && n2 > n7 && n2 < n8 || a[n][n2] != 44) continue;
                this.bG = n;
                this.bH = n2;
                this.bE();
            }
        }
        this.bG = n3;
        this.bH = n4;
        if (this.m == 0) {
            this.bm();
        }
        if (this.ad == 12) {
            if (this.ae++ > 100) {
                this.ad = 15;
                this.o(11, 11);
            }
            i2.b();
            return;
        }
        if (this.ad == -1) {
            if (this.aR * 24 >= 336) {
                this.ad = 0;
                i2.a(0);
                return;
            }
        } else if (this.ad != 15 && this.ad != -1) {
            int n9;
            int n10;
            int n11;
            n2 = -1;
            n = this.aR * 24 + 12;
            int n12 = this.aS * 24;
            int n13 = this.ah + 24;
            if (this.m == 0L && this.m != 0) {
                this.m = aP + e.a(223, 290);
            }
            if (this.af <= 0) {
                n11 = 1;
            } else {
                int n14 = n11 = aP % this.af == 0 ? 2 : 1;
            }
            if (this.ad == 10 || this.ad == 11) {
                int n15 = n11 = (aP & 0xB) == 0 ? 2 : n11;
            }
            while (n11-- > 0) {
                n10 = 0;
                switch (this.ad) {
                    case 2: {
                        if (!i2.a()) break;
                        if ((long)aP > this.m) {
                            n2 = 13;
                            this.ad = 13;
                            break;
                        }
                        n2 = 4;
                        this.ad = 4;
                        break;
                    }
                    case 3: {
                        if (!i2.a()) break;
                        if ((long)aP > this.m) {
                            n2 = 14;
                            this.ad = 14;
                            break;
                        }
                        n2 = 5;
                        this.ad = 5;
                        break;
                    }
                    case 0: {
                        if (n13 > 360) {
                            n2 = 4;
                            this.ad = 4;
                            break;
                        }
                        n2 = 5;
                        this.ad = 5;
                        break;
                    }
                    case 1: {
                        if (n13 < 504) {
                            n2 = 5;
                            this.ad = 5;
                            break;
                        }
                        n2 = 4;
                        this.ad = 4;
                        break;
                    }
                    case 10: {
                        if (i2.a()) {
                            this.bl = 10;
                            n13 = this.ah + 24;
                            if ((long)aP > this.m) {
                                n2 = 13;
                                this.ad = 13;
                                break;
                            }
                            if (n12 >= 504) {
                                if (n < n13 - 48) break;
                                n2 = 6;
                                this.ad = 6;
                                break;
                            }
                            n2 = 4;
                            this.ad = 4;
                            break;
                        }
                        this.ah -= 2;
                        break;
                    }
                    case 11: {
                        if (i2.a()) {
                            this.bl = 10;
                            n13 = this.ah + 24;
                            if ((long)aP > this.m) {
                                n2 = 14;
                                this.ad = 14;
                                break;
                            }
                            if (n12 >= 504) {
                                if (n > n13 + 48) break;
                                n2 = 7;
                                this.ad = 7;
                                break;
                            }
                            n2 = 5;
                            this.ad = 5;
                            break;
                        }
                        this.ah += 2;
                        break;
                    }
                    case 4: {
                        if ((long)aP > this.m) {
                            n2 = 13;
                            this.ad = 13;
                            break;
                        }
                        if (n12 >= 504 && n < n13 && this.ah - 48 >= 360) {
                            n2 = 10;
                            this.ad = 10;
                        }
                        if (n13 <= 360) {
                            n2 = 5;
                            this.ad = 5;
                        }
                        if (this.ad != 4) break;
                        --this.ah;
                        break;
                    }
                    case 5: {
                        if ((long)aP > this.m) {
                            n2 = 14;
                            this.ad = 14;
                            break;
                        }
                        if (n12 >= 504 && n > n13 && this.ah + 48 <= 504) {
                            n2 = 11;
                            this.ad = 11;
                        }
                        if (n13 >= 504) {
                            n2 = 4;
                            this.ad = 4;
                        }
                        if (this.ad != 5) break;
                        ++this.ah;
                        break;
                    }
                    case 6: 
                    case 7: 
                    case 13: 
                    case 14: {
                        n9 = 0;
                        int n16 = 0;
                        int n17 = 0;
                        switch (this.ad) {
                            case 6: 
                            case 13: {
                                n9 = 4;
                                n16 = 2;
                                n17 = 1;
                                break;
                            }
                            case 7: 
                            case 14: {
                                n9 = 5;
                                n16 = 1;
                                n17 = 2;
                            }
                        }
                        if (i2.g == 5 && i2.h == 0) {
                            this.bl = this.ad == 13 || this.ad == 14 ? 52 : 10;
                        }
                        if (i2.a()) {
                            if (this.ad == 13 || this.ad == 14) {
                                this.n = aP + 26;
                                this.m = aP + e.a(223, 290);
                            }
                            this.ad = n2 = n9;
                        }
                        if (i2.g < 5 || n12 < 504 || n < n13 - n16 * 24 || n > n13 + n17 * 24) break;
                        this.a(1, 48, 4);
                    }
                }
                if (n12 >= 504 && n >= n13 - 24 && n <= n13 + 24) {
                    this.a(1, 48, (int)h[this.aU & 7]);
                }
                if (this.af > 0) continue;
                this.ad = 12;
                this.ae = 0;
                return;
            }
            if (this.cg == 5) {
                if (this.ch <= 0) {
                    if (this.af <= 2) {
                        k.a[10][16] = 45;
                        k.c[10][16] = 24;
                        k.b[10][16] = 0;
                        k.b[10][16] = 0;
                    }
                    k.a[26][19] = 45;
                    k.c[26][19] = 24;
                    k.b[26][19] = 0;
                    k.b[26][19] = 0;
                } else {
                    k.a[10][19] = 45;
                    k.c[10][19] = 24;
                    k.b[10][19] = 0;
                    k.b[10][19] = 0;
                    if (this.af <= 2) {
                        k.a[26][16] = 45;
                        k.c[26][16] = 24;
                        k.b[26][16] = 0;
                        k.b[26][16] = 0;
                    }
                }
            }
            if (this.ad != 10 && this.ad != 11) {
                for (n10 = 21; n10 < 23; ++n10) {
                    for (n9 = n13 / 24 - 1; n9 < n13 / 24 - 2 + 4; ++n9) {
                        if (a[n9][n10] != 9) continue;
                        if ((b[n9][n10] & 7) == 3) {
                            --this.af;
                            switch (this.ad) {
                                case 0: 
                                case 2: 
                                case 4: 
                                case 6: {
                                    n2 = 2;
                                    this.ad = 2;
                                    break;
                                }
                                case 1: 
                                case 3: 
                                case 5: 
                                case 7: {
                                    n2 = 3;
                                    this.ad = 3;
                                }
                            }
                        }
                        k.a[n9][n10] = -1;
                        this.b(n9, n10);
                        k.a[n9][n10] = 30;
                        k.c[n9][n10] = 24;
                        k.b[n9][n10] = 4;
                    }
                }
            }
            if (n2 != -1) {
                i2.a(n2);
                return;
            }
            i2.b();
        }
    }

    public final void bo() {
        if (a[18][63] == 0 && b[18][63] <= 0 && this.ab == 0) {
            this.bl = 120;
            ++this.ab;
        }
        if (this.ab == 3) {
            if (k.a[2].f == 0) {
                a[2].a(1);
            } else if (k.a[2].f == 1 && a[2].a()) {
                a[2].a(2);
                if (this.aS == this.ay - 4) {
                    this.aa = 817;
                }
            }
        } else if (k.a[2].f != 0) {
            a[2].a(0);
        }
        a[2].b();
        if (k.a[2].f == 2) {
            a[1].b();
            if (this.bl == 10) {
                this.bl = 60;
            }
            if (k.a[1].f == 0) {
                if ((this.a == null || this.aa < 46) && this.aa < 1704) {
                    ++this.aa;
                    int n = this.ay * 24 - (this.as + 208 - 28);
                    if (this.aa < n) {
                        this.aa = n;
                    }
                }
                if (this.ay * 24 - this.aa <= this.aS * 24 + 18 && this.aR < 17) {
                    this.a((int)i[8], 64, 1);
                    return;
                }
            } else if (a[1].a()) {
                a[1].a(0);
            }
        }
    }

    public final void bp() {
        if (a != null && this.b() && (a[this.aR][this.aS] & 0xFF) == 0) {
            int n = a[this.aR][this.aS] >> 8;
            if (n == 13) {
                this.p = true;
            } else if (n == 16) {
                this.q = true;
            }
        }
        if (!this.r && this.aT <= 0 && this.d(46, 7)) {
            this.s = true;
            this.r = true;
        }
    }

    public final void bq() {
        byte by = (this.aU & 0x1000) == 0 ? this.k : (byte)0;
        int n = this.aR * 24 + this.aT * g[by];
        boolean bl = false;
        int n2 = 24 * this.ax - 176;
        int n3 = 24 * this.ay - 180;
        if (n < this.av + 72) {
            this.av = this.av - 72 + n >> 1;
            if (this.av < 0) {
                this.av = 0;
            }
        } else if (n > this.av + 80) {
            this.av = this.av - 80 + n >> 1;
            if (this.av > n2) {
                this.av = n2;
            }
        }
        if ((n = this.aS * 24 + this.aT * g[by + 8]) < this.aw + 72) {
            this.aw = this.aw - 72 + n >> 1;
            if (this.aw < 0) {
                this.aw = 0;
            }
        }
        if (n > this.aw + 84) {
            this.aw = this.aw - 84 + n >> 1;
            if (this.aw > n3) {
                this.aw = n3;
            }
        }
        this.ar = this.av + this.at;
        this.as = this.aw + this.au;
        if (this.ar < 0) {
            this.at -= this.ar;
            this.ar = this.av + this.at;
        } else if (this.ar > n2) {
            this.at -= this.ar - n2;
            this.ar = this.av + this.at;
        }
        if (this.as < 0) {
            this.au -= this.as;
            this.as = this.aw + this.au;
            return;
        }
        if (this.as > n3) {
            this.au -= this.as - n3;
            this.as = this.aw + this.au;
        }
    }

    public final void br() {
        boolean bl = true;
        boolean bl2 = true;
        if (this.am < 0) {
            int n = this.aU & 7;
            switch (n) {
                case 4: {
                    if (this.at > -60) {
                        --this.at;
                    }
                    bl = false;
                    break;
                }
                case 2: {
                    if (this.at < 60 && this.ar < this.aR * 24) {
                        ++this.at;
                    }
                    bl = false;
                    break;
                }
                case 1: {
                    if (this.au > -60) {
                        --this.au;
                    }
                    bl2 = false;
                    break;
                }
                case 3: {
                    if (this.au < 60 && this.as < this.aS * 24) {
                        ++this.au;
                    }
                    bl2 = false;
                }
            }
        }
        if (bl) {
            if (this.at > 0) {
                --this.at;
            } else if (this.at < 0) {
                ++this.at;
            }
        }
        if (bl2) {
            if (this.au > 0) {
                --this.au;
                return;
            }
            if (this.au < 0) {
                ++this.au;
            }
        }
    }

    public final void a(int n, int n2, boolean bl, byte by) {
        int n3 = bl ? n + 1 : n - 1;
        int n4 = b[n][n2];
        k.a[n3][n2] = by;
        k.a[n][n2] = -1;
        k.b[n3][n2] = 18;
        if (bl) {
            n4 = n4 & 0xFFFFFFF8 | 2;
            n4 = n4 & 0xFFFFF3FF | 0x400;
        } else {
            n4 = n4 & 0xFFFFFFF8 | 4;
            n4 = n4 & 0xFFFFF3FF | 0x800;
        }
        k.b[n3][n2] = n4 & 0xFFFFFDFF | Integer.MIN_VALUE;
        this.p(n3, n2);
        this.b(n, n2);
    }

    public final void b(int n, int n2, byte by) {
        if ((a[n][n2] & 0xFF) == by) {
            k.a[n][n2] = -1;
            this.b(n - 1, n2, by);
            this.b(n + 1, n2, by);
            this.b(n, n2 - 1, by);
            this.b(n, n2 + 1, by);
        }
    }

    public final boolean a(int n, int n2, boolean bl) {
        boolean bl2 = false;
        int n3 = this.aU;
        int n4 = this.aR;
        int n5 = this.aS;
        byte by = this.k;
        boolean bl3 = this.w;
        int n6 = this.aZ;
        int n7 = this.aT;
        int n8 = this.aY;
        n3 = n > 0 ? n3 & 0xFFFFFFF8 | 2 : (n < 0 ? n3 & 0xFFFFFFF8 | 4 : (n2 < 0 ? n3 & 0xFFFFFFF8 | 1 : n3 & 0xFFFFFFF8 | 3));
        byte by2 = n4 + n;
        int n9 = n5 + n2;
        boolean bl4 = false;
        boolean bl5 = false;
        if (by2 < 0 || by2 >= this.ax || n9 < 0 || n9 >= this.ay) {
            bl4 = true;
        } else {
            int n10;
            byte by3;
            if (e != null && e[by2][n9] != 0 && i[10] == 0) {
                bl4 = false;
                bl2 = true;
            }
            byte by4 = (byte)(a[by2][n9] & 0xFF);
            switch (by4) {
                case 19: {
                    if (bl) break;
                    by3 = by2 + 3;
                    n10 = n9;
                    while (a[by3][n10] != 39) {
                        --n10;
                    }
                    if (!this.k) {
                        this.ch();
                    }
                    this.k = true;
                    this.ak = false;
                    if (e == null) {
                        e = new int[this.ax][this.ay];
                    }
                    this.a((byte)b[by3][n10], by3, (byte)n10, (byte)0);
                    this.u(by3, n10);
                    by3 = by2;
                    ++n10;
                    while ((a[by3][n10] & 0xFF) == 19) {
                        k.a[by3][n10] = -1;
                        ++n10;
                    }
                    break;
                }
                case 1: {
                    if (bl) break;
                    this.bl = 120;
                    ++this.ab;
                    this.b((int)by2, n9, (byte)1);
                    break;
                }
                case 7: {
                    int n11 = a[by2][n9] >> 8;
                    if ((n11 & 0xF0) >> 4 >= 2) break;
                    bl2 = true;
                    break;
                }
                case 4: {
                    int n12;
                    if (bl || (n12 = (a[by2][n9] & 0xFFFFFF00) >> 8) < this.az) break;
                    this.v = true;
                    this.az = n12 + 1;
                    this.Z = aP + 8;
                    break;
                }
                case 28: {
                    if (bl) break;
                    bl3 = true;
                    this.as = false;
                    break;
                }
                case 5: {
                    bl4 = true;
                    if (bl) break;
                    bl3 = true;
                    this.as = true;
                    break;
                }
                case 2: {
                    if (bl) break;
                    bl5 = true;
                    int n13 = a[by2][n9] >> 8;
                    switch (n13) {
                        case 0: {
                            if (i[9] >= 1) {
                                this.aA = 7;
                                this.aB = 0;
                                break;
                            }
                            this.aA = 13;
                            this.aB = 1;
                            break;
                        }
                        case 1: {
                            if (i[9] >= 2) {
                                this.aA = 7;
                                this.aB = 1;
                                break;
                            }
                            this.aA = 13;
                            this.aB = 1;
                        }
                    }
                    break;
                }
                case 6: {
                    break;
                }
                case 3: {
                    if (a[by2][n9] >> 8 < 3) {
                        bl4 = true;
                        break;
                    }
                    bl4 = false;
                    bl2 = true;
                }
            }
            if (!bl2) {
                by3 = a[by2][n9];
                switch (by3) {
                    case 34: 
                    case 35: {
                        bl4 = bl;
                        break;
                    }
                    case 31: 
                    case 49: {
                        bl4 = false;
                        break;
                    }
                    case 1: 
                    case 2: 
                    case 4: 
                    case 5: 
                    case 6: 
                    case 7: 
                    case 11: 
                    case 14: 
                    case 19: 
                    case 24: 
                    case 26: 
                    case 27: 
                    case 33: 
                    case 40: 
                    case 41: 
                    case 42: 
                    case 43: 
                    case 45: 
                    case 50: 
                    case 51: 
                    case 52: 
                    case 53: {
                        bl4 = true;
                        break;
                    }
                    case 10: {
                        if (this.v != 3) break;
                        if (!bl && b[by2][n9] <= 0) {
                            k.b[by2][n9] = 1;
                        }
                        bl4 = true;
                        break;
                    }
                    case 0: 
                    case 8: 
                    case 9: 
                    case 47: {
                        int n14;
                        int n15;
                        n10 = n4 + (n << 1);
                        int n16 = n5 + (n2 << 1);
                        if (this.i == 4 && (n10 == (n15 = this.f()) || n10 == n15 + 1) && n16 >= (n14 = this.g())) {
                            this.m(((n3 |= 8) & 7) == 2 ? 8 : 9);
                            return false;
                        }
                        n15 = a[n10][n16] & 0xFF;
                        n14 = a[n10][n16] >> 8;
                        byte by5 = a[by2][n5 + 1];
                        if ((--n6 < 0 || bl) && n != 0 && this.f(n10, n16) && (n15 != 7 || (n14 & 0xF0) != 0) && (by5 != 19 && by5 != 45 && by5 != 49 && by5 != 43 || (a[by2][n5 + 1] & 0xFF) == 35)) {
                            if (!bl) {
                                this.a((int)by2, n9, n > 0, by3);
                            }
                            bl4 = true;
                            n3 |= 8;
                            break;
                        }
                        if (n != 0) {
                            n3 |= 8;
                        }
                        by = 0;
                        k.b[by2][n9] = b[by2][n9] & 0xFFFFFFF8 | 0;
                        break;
                    }
                    case 48: {
                        int n17;
                        int n18;
                        n10 = n4 + (n << 1);
                        int n19 = n5 + (n2 << 1);
                        --n6;
                        if ((b[by2][n9] & 8) != 0) {
                            n18 = 0;
                            n17 = 1;
                        } else {
                            n18 = -1;
                            n17 = 0;
                        }
                        if ((n6 < 0 || bl) && n != 0 && a[n10][n19 + n18] < 0 && a[n10][n19 + n17] < 0 && a[by2][n9 + n17 + 1] >= 0) {
                            if (!bl) {
                                k.a[n10][n19 + n18] = by3;
                                k.a[n10][n19 + n17] = by3;
                                k.a[by2][n9 + n18] = -1;
                                k.a[by2][n9 + n17] = -1;
                                k.b[n10][n19 + n18] = b[by2][n9 + n18];
                                k.b[n10][n19 + n17] = b[by2][n9 + n17] & 0xFFFFFFF0 | (n > 0 ? 2 : 4);
                                k.b[n10][n19 + n17] = 18;
                                k.c[n10][n19 + n18 - 1] = 48;
                                k.c[n10][n19 + n18 - 1] = 48;
                                k.c[n10][n19 + n18 - 1] = 48;
                                this.p(n10, n19 + n17);
                            }
                            bl4 = true;
                            n3 |= 8;
                            break;
                        }
                        if (n != 0) {
                            n3 |= 8;
                        }
                        by = 0;
                        break;
                    }
                    case -1: {
                        if (by2 == 0 || n9 == 0 || by2 == this.ax - 1 || n9 == this.ay - 1) {
                            bl4 = true;
                        } else if (n != 0 && a[by2][n5 + 1] == 0 && (b[by2][n5 + 1] & 7) == 3 || this.aK >= 24 && (a[by2][n9 - 1] == 28 && (b[by2][n9 - 1] & 8) == 0 || a[by2][n9 + 1] == 28 && (b[by2][n9 + 1] & 8) == 0) || this.aM >= 24 && (a[by2][n9 - 1] == 28 || a[by2][n9 + 1] == 28)) {
                            if (bl) {
                                bl4 = true;
                            } else {
                                by = 0;
                            }
                        } else {
                            bl4 = true;
                        }
                        n3 &= 0xFFFFFFF7;
                        break;
                    }
                    case 28: {
                        by = 0;
                        n3 &= 0xFFFFFFF7;
                        break;
                    }
                    default: {
                        n = 0;
                        bl4 = false;
                        if (this.k != 4 && this.k != 2) break;
                        this.m(0 + this.k - 1);
                    }
                }
            }
        }
        if (!bl && bl4 && !bl5) {
            this.aA = -1;
        }
        if (bl4 && n8 == 0) {
            n7 = 18;
            n4 += n;
            n5 += n2;
            if ((n3 & 8) == 0 && !bl) {
                this.m(4 + by - 1);
            }
        } else if (n != 0 && !bl) {
            n3 |= 8;
        }
        if ((n3 & 8) != 0 && !bl) {
            this.m((n3 & 7) == 2 ? 8 : 9);
        }
        if (!bl) {
            this.aU = n3;
            this.aR = n4;
            this.aS = n5;
            this.k = by;
            this.w = bl3;
            this.aZ = n6;
            this.aT = n7;
            this.aY = n8;
        }
        return bl4;
    }

    public final void bs() {
        l = (byte)3;
    }

    public final void bt() {
        l = (byte)2;
        T = true;
        this.a(1);
        this.v();
        if (a[18] == null) {
            k.a[18] = k.a("/ui.f", 3);
        }
    }

    public final void bu() {
        this.o = System.currentTimeMillis() - this.a;
        this.ad = true;
        this.a.f();
    }

    public final void showNotify() {
        if (this.ad) {
            this.bv();
        }
    }

    public final void hideNotify() {
        if (!this.ad) {
            this.bu();
        }
    }

    public final void bv() {
        this.ad = false;
        T = true;
        U = true;
        this.c = true;
        W = 0;
        this.dd = -1;
        if (this.bq == 7) {
            this.bs = 0;
        }
        this.a = System.currentTimeMillis() - this.o;
        switch (l) {
            case 0: 
            case 4: 
            case 6: 
            case 7: 
            case 12: 
            case 22: 
            case 30: {
                return;
            }
            case 15: {
                this.au = true;
                return;
            }
            case 10: {
                U = false;
                return;
            }
            case 1: {
                this.v();
                if (E) {
                    return;
                }
                if (this.a != null) {
                    return;
                }
                if (this.an != 0) {
                    return;
                }
                if (this.w) {
                    return;
                }
                if (this.m <= 0) {
                    return;
                }
                if (k.a[0].f == 19) {
                    return;
                }
                if (this.D) {
                    return;
                }
                this.bt();
                return;
            }
            case 5: {
                this.R = true;
                return;
            }
            case 8: {
                return;
            }
            case 9: 
            case 28: {
                return;
            }
            case 11: {
                this.bu = 6;
                return;
            }
            case 31: {
                this.Q = true;
                return;
            }
            case 16: {
                this.ao = 0;
                this.bd = 0;
                this.o = false;
                this.V = 0;
                this.C = true;
                return;
            }
            case 17: {
                return;
            }
            case 18: 
            case 25: 
            case 26: {
                this.au = true;
                return;
            }
            case 19: {
                return;
            }
            case 20: {
                return;
            }
            case 21: {
                this.cn();
                return;
            }
            case 23: {
                return;
            }
            case 27: {
                this.au = true;
                this.f = true;
                return;
            }
            case 2: {
                c = null;
                this.n = true;
                if (this.bq != 1) break;
                this.bs = 0;
                return;
            }
            case 33: {
                this.au = true;
            }
        }
    }

    public final void bw() {
        if (!this.k) {
            return;
        }
        for (int i2 = 0; i2 < this.ax; ++i2) {
            for (int i3 = 0; i3 < this.ay; ++i3) {
                if (a[i2][i3] != 38) continue;
                this.a((byte)b[i2][i3], (byte)i2, (byte)i3, (byte)0);
                ++this.dv;
            }
        }
    }

    public final void m(int n, int n2) {
        this.c |= 0x400000L;
        int[] nArray = a[n];
        int n3 = n2;
        nArray[n3] = nArray[n3] & 0xFFFFFF00;
        int[] nArray2 = a[n];
        int n4 = n2;
        nArray2[n4] = nArray2[n4] | 0xE;
    }

    public final boolean e() {
        return this.i == 4 || this.i == 5 || this.i == 3;
    }

    public final void bx() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        Hashtable<Integer, Integer> hashtable = new Hashtable<Integer, Integer>();
        Hashtable<Integer, Integer> hashtable2 = new Hashtable<Integer, Integer>();
        Hashtable<Integer, Integer> hashtable3 = new Hashtable<Integer, Integer>();
        this.X = 0;
        this.Y = 0;
        int n8 = 0;
        this.ba = 0;
        this.bw = 0;
        int n9 = 0;
        int n10 = 0;
        this.ae = false;
        this.af = false;
        this.ag = false;
        this.al = 0;
        int n11 = 0;
        for (n7 = 0; n7 < this.ax; ++n7) {
            block88: for (n6 = 0; n6 < this.ay; ++n6) {
                k.b[n7][n6] = 0;
                k.c[n7][n6] = 0;
                n5 = a[n7][n6];
                n4 = b[n7][n6];
                n3 = a[n7][n6];
                if (n5 != -1) {
                    switch (n5 & 0xFF) {
                        case 31: {
                            this.c |= 0x40000000L;
                            k.a[n7][n6] = n4 << 8 | 0x1F;
                        }
                        case 19: {
                            k.a[n7][n6] = n4 << 8 | 0x13;
                            break;
                        }
                        case 17: {
                            Integer n12;
                            Integer n13;
                            n2 = a[n7][n6 - 1] & 0xFF;
                            if (n2 == 14 || n2 == 33) {
                                k.a[n7][n6 - 1] = 0xFF00 | n2;
                            }
                            n = a[n7][n6 - 1];
                            switch (n) {
                                case 19: 
                                case 36: 
                                case 43: 
                                case 45: 
                                case 46: 
                                case 49: {
                                    n13 = new Integer(n4);
                                    n12 = (Integer)hashtable2.get(n13);
                                    n12 = n12 == null ? new Integer(1) : new Integer(n12 + 1);
                                    hashtable2.put(n13, n12);
                                    k.a[n7][n6] = -1;
                                    Integer n14 = (Integer)hashtable3.get(n13);
                                    if (n == 36) {
                                        if (n14 != null) break;
                                        hashtable3.put(n13, new Integer(58));
                                        break;
                                    }
                                    hashtable3.put(n13, new Integer(57));
                                    if (this.i == 4) {
                                        hashtable3.put(n13, new Integer(93));
                                        break;
                                    }
                                    if (this.i == 5) {
                                        hashtable3.put(n13, new Integer(94));
                                        break;
                                    }
                                    if (this.i != 3) break;
                                    hashtable3.put(n13, new Integer(95));
                                    break;
                                }
                                default: {
                                    k.a[n7][n6] = n4 << 8 | 0x11;
                                }
                            }
                            if (n4 < 0) break;
                            n10 |= 1 << n4;
                            break;
                        }
                        case 14: 
                        case 33: {
                            if (!this.e()) {
                                k.a[n7][n6] = 33;
                            }
                            this.c |= 1L << ((a[n7][n6] & 0xFF) == 14 ? 22 : 33);
                            if (!this.a(this.ap, this.aq, n7, n6)) break;
                            if (this.e()) {
                                k.a[n7][n6] = 41;
                                k.b[n7][n6] = 10;
                                this.ba += 10;
                                break;
                            }
                            k.a[n7][n6] = -1;
                            int[] nArray = a[n7];
                            int n15 = n6;
                            nArray[n15] = nArray[n15] | 0x100;
                            break;
                        }
                        case 2: {
                            this.c |= 0x100000L;
                            switch (n4) {
                                case 0: 
                                case 1: {
                                    this.c |= 0x80000L;
                                }
                            }
                            k.a[n7][n6] = n4 << 8 | 2;
                            break;
                        }
                        case 8: {
                            this.af = true;
                        }
                        case 9: {
                            if ((n5 & 0xFF) != 8) {
                                this.ae = true;
                            }
                            this.c |= 0x10000000L;
                            Integer n13 = new Integer(n4);
                            Integer n12 = (Integer)hashtable.get(n13);
                            n12 = n12 == null ? new Integer(1) : new Integer(n12 + 1);
                            hashtable.put(n13, n12);
                            k.a[n7][n6] = n4 << 8 | n5;
                            break;
                        }
                        case 7: {
                            if (n4 != -1) {
                                k.q[n4] = (byte)n7;
                                k.r[n4] = (byte)n6;
                            }
                            k.a[n7][n6] = n4 << 8 | n5;
                            break;
                        }
                        case 30: {
                            this.c |= 0x40000000L;
                            ++n11;
                        }
                        case 1: 
                        case 26: {
                            k.a[n7][n6] = n4 << 8 | n5 & 0xFF;
                            break;
                        }
                        case 0: {
                            ++n11;
                            k.a[n7][n6] = n4 << 8 | n5 & 0xFF;
                            break;
                        }
                        case 4: {
                            ++n9;
                            this.c |= 0x10L;
                            k.a[n7][n6] = n4 << 8 | n5 & 0xFF;
                            break;
                        }
                        case 5: {
                            this.o = (byte)n4;
                            break;
                        }
                        case 28: {
                            this.p = (byte)n4;
                            break;
                        }
                        case 3: {
                            k.c[n7][n6] = 127;
                            if (n4 <= 0) break;
                            k.a[n7][n6] = n4 + 1 << 8 | 3;
                            break;
                        }
                        case 6: {
                            Integer n13 = new Integer(n4);
                            Integer n12 = (Integer)hashtable.get(n13);
                            n12 = n12 == null ? new Integer(1) : new Integer(n12 + 1);
                            hashtable.put(n13, n12);
                            this.c |= 0x20000000L;
                            k.a[n7][n6] = n4 << 8 | 6;
                            break;
                        }
                        default: {
                            if (n5 >= 20 && n5 < 26) {
                                k.a[n7][n6] = n5;
                                switch (this.ap) {
                                    case 0: {
                                        this.c |= 0x10L;
                                        break;
                                    }
                                    case 1: {
                                        this.c |= 0x200000L;
                                    }
                                }
                                break;
                            }
                            if (n5 >= 80 || n5 <= -1) break;
                            k.a[n7][n6] = -1;
                            break;
                        }
                        case 34: {
                            this.c |= 0x400000000L;
                        }
                    }
                }
                switch (n3) {
                    case 48: {
                        k.b[n7][n6] = (n4 & 7) == 4 ? 16 : 0;
                        ++this.al;
                        this.c |= 0x10000000000L;
                        this.c |= 0x100000000L;
                        n2 = n6 - 1;
                        k.a[n7][n2] = 48;
                        k.b[n7][n2] = 8;
                        this.p(n7, n2);
                        continue block88;
                    }
                    case 47: {
                        k.c[n7][n6] = 48;
                        k.b[n7][n6] = 0;
                        this.c |= 0x800000L;
                        continue block88;
                    }
                    case 46: {
                        k.b[n7][n6] = 0;
                        k.c[n7][n6] = 24;
                        k.b[n7][n6] = 0;
                        this.c |= 0x2000000000L;
                        continue block88;
                    }
                    case 45: {
                        k.b[n7][n6] = 0;
                        k.c[n7][n6] = 24;
                        this.c |= 0x800000000L;
                        continue block88;
                    }
                    case 44: {
                        k.c[n7][n6] = 24;
                        k.b[n7][n6] = 0;
                        this.c |= 0x400000000L;
                        continue block88;
                    }
                    case 42: {
                        ++n11;
                        ++n8;
                        this.c |= 0x80000000L;
                        this.c |= 0x40000000L;
                        this.m(n7, n6);
                        continue block88;
                    }
                    case 41: {
                        if (b[n7][n6] <= 0) {
                            k.b[n7][n6] = 1;
                        }
                        this.ba += b[n7][n6];
                        continue block88;
                    }
                    case 40: {
                        this.c |= 0x40000000L;
                        ++n11;
                        this.k = true;
                        this.c |= 0x8000000L;
                        this.m(n7, n6);
                        ++n8;
                        continue block88;
                    }
                    case 12: {
                        this.e |= 0x20L;
                        this.Q = n7;
                        this.R = n6;
                        this.P = n4;
                        continue block88;
                    }
                    case 36: {
                        if (b[n7][n6] != 1) {
                            k.b[n7][n6] = 0;
                        }
                        this.c |= 0x100L;
                        continue block88;
                    }
                    case 18: {
                        this.cg = 0;
                        this.ch = 0;
                        this.c |= 0x8000000000L;
                        this.c |= 0x80L;
                        continue block88;
                    }
                    case 34: {
                        k.a[n7][n6] = -1;
                        k.a[n7][n6] = 15;
                        this.c |= 0x1000000L;
                        continue block88;
                    }
                    case 35: {
                        k.a[n7][n6] = 35;
                        k.a[n7][n6] = -1;
                        this.c |= 0x1000000L;
                        this.ag = true;
                        continue block88;
                    }
                    case 31: 
                    case 33: {
                        continue block88;
                    }
                    case 39: {
                        this.k = true;
                        this.c |= 0x4000000L;
                        continue block88;
                    }
                    case 38: {
                        this.k = true;
                        this.c |= 0x4000000L;
                        k.a[n7][n6] = 27;
                        this.c |= 0x40L;
                        continue block88;
                    }
                    case 14: {
                        this.c |= 0x1000L;
                        k.b[n7][n6] = b[n7][n6] == 4 ? 8 : 0;
                        k.c[n7][n6] = 24;
                        continue block88;
                    }
                    case 28: {
                        this.c |= 0x800L;
                        if (n4 > 10) {
                            int[] nArray = b[n7];
                            int n16 = n6;
                            nArray[n16] = nArray[n16] / 11;
                            int[] nArray2 = b[n7];
                            int n17 = n6;
                            nArray2[n17] = nArray2[n17] | 8;
                        }
                        k.c[n7][n6] = 24;
                        continue block88;
                    }
                    case 79: {
                        this.aR = 0;
                        this.aS = n6;
                        this.an = n7;
                        k.a[n7][n6] = -1;
                        this.au = 0;
                        this.at = 0;
                        this.av = 0;
                        this.ar = 0;
                        this.aw = this.as = this.aS * 24 - 72;
                        continue block88;
                    }
                    case 11: {
                        k.b[n7][n6] = n4 == 1 ? 16 : 0;
                        k.c[n7][n6] = 48;
                        this.c |= 0x4000L;
                        continue block88;
                    }
                    case 49: {
                        this.c |= 0x20000000000L;
                        k.c[n7][n6] = 48;
                        continue block88;
                    }
                    case 43: {
                        this.c |= 1L << (this.ap == 1 ? 17 : 15);
                        this.bw |= 1;
                        k.b[n7][n6] = n4 & 0xFFFE7FFF | 0x10000;
                        k.c[n7][n6] = 48;
                        continue block88;
                    }
                    case 19: {
                        this.c |= 1L << (this.ap == 1 ? 17 : 15);
                        this.bw |= 2;
                        k.c[n7][n6] = 48;
                        continue block88;
                    }
                    case 22: 
                    case 23: {
                        this.c |= 0x200L;
                        this.c |= 0x400L;
                        k.c[n7][n6] = 48;
                        continue block88;
                    }
                    case 30: {
                        this.c |= 0x80L;
                        k.b[n7][n6] = 0;
                        continue block88;
                    }
                    case 37: {
                        this.c |= 0x2000000L;
                        k.b[n7][n6] = 0;
                        continue block88;
                    }
                    case 10: {
                        k.b[n7][n6] = 0;
                        this.d |= 2L;
                        continue block88;
                    }
                    case 16: {
                        if (a[n7][n6 + 1] != 16) {
                            k.a[n7][n6 - 1] = 16;
                            k.b[n7][n6 - 1] = n4;
                        }
                        this.c |= 0x2000L;
                        continue block88;
                    }
                    case 6: {
                        ++n8;
                        this.m(n7, n6);
                    }
                    case 7: {
                        this.c |= 0x10L;
                        k.b[n7][n6] = 0;
                        continue block88;
                    }
                    case 26: {
                        this.c |= 0x10000000000L;
                    }
                    case 24: 
                    case 27: {
                        ++n11;
                        ++n8;
                        this.c |= 0x40000000L;
                        this.c |= 0x80000L;
                        this.m(n7, n6);
                        continue block88;
                    }
                    case 8: {
                        this.c |= 0x20L;
                        this.c |= 8L;
                    }
                    case 4: {
                        if (n3 != 8) {
                            this.m(n7, n6);
                        }
                    }
                    case 5: {
                        this.c |= 4L;
                    }
                    case 2: {
                        ++n8;
                    }
                    case 0: {
                        k.c[n7][n6] = 48;
                        k.b[n7][n6] = 0;
                        this.d |= 1L;
                        continue block88;
                    }
                    case 1: {
                        ++this.ba;
                        k.c[n7][n6] = 48;
                        k.b[n7][n6] = 0;
                        continue block88;
                    }
                    case 53: {
                        continue block88;
                    }
                    case 51: {
                        continue block88;
                    }
                    case 52: {
                        continue block88;
                    }
                    default: {
                        if (n3 >= 80 || n3 <= -1) continue block88;
                        k.a[n7][n6] = -1;
                    }
                }
            }
        }
        d = new byte[n8 << 1];
        for (n7 = 0; n7 < d.length; ++n7) {
            k.d[n7] = 0;
        }
        a = new d[n11];
        p = new byte[n11];
        n7 = 0;
        k = new byte[(n9 + 1) * 2];
        for (n6 = 31; n6 >= 0 && (n10 & 1 << n6) == 0; --n6) {
        }
        if (++n6 > 0) {
            m = new byte[n6];
            l = new byte[n6];
        }
        if (this.al > 0) {
            e = new byte[this.al * 3];
        }
        n5 = 0;
        for (n4 = 0; n4 < this.ay; ++n4) {
            block92: for (n3 = 0; n3 < this.ax; ++n3) {
                int n18;
                n2 = a[n3][n4] & 0xFF;
                n = a[n3][n4] >> 8;
                switch (n2) {
                    case 0: 
                    case 30: {
                        k.p[n7++] = (byte)n;
                        break;
                    }
                    case 7: {
                        boolean bl;
                        Integer n19 = (Integer)hashtable.get(new Integer(n));
                        n <<= 8;
                        if (n19 != null) {
                            n = n & 0xFFFFFFF0 | n19;
                        }
                        n18 = (a[n3][n4 - 1] & 0xFF) == 17 ? 1 : 0;
                        boolean bl2 = bl = (a[n3][n4 + 1] & 0xFF) == 17 && (a[n3 + 1][n4] & 0xFF) != 26 && (a[n3 - 1][n4] & 0xFF) != 26;
                        if (n18 != 0 || bl) {
                            n = n & 0xFFFFFF0F | 0x30;
                            k.c[n3][n4] = 24;
                            if (n18 != 0) {
                                k.a[n3][n4 - 1] = -1;
                            }
                        }
                        k.a[n3][n4] = n << 8 | n2;
                        break;
                    }
                    case 4: {
                        int n20 = n;
                        k.k[n20 * 2] = (byte)n3;
                        k.k[n20 * 2 + 1] = (byte)n4;
                        break;
                    }
                    case 5: {
                        k.k[n9 * 2] = (byte)n3;
                        k.k[n9 * 2 + 1] = (byte)n4;
                        break;
                    }
                    case 17: {
                        if (n == -1) break;
                        Integer n21 = new Integer(n);
                        Integer n22 = (Integer)hashtable2.get(n21);
                        if (n22 == null) {
                            n22 = new Integer(0);
                        }
                        k.m[n] = n22.byteValue();
                        Integer n23 = (Integer)hashtable3.get(n21);
                        if (n23 == null) {
                            n23 = new Integer(59);
                        }
                        k.l[n] = n23.byteValue();
                    }
                }
                switch (a[n3][n4]) {
                    case 48: {
                        if ((b[n3][n4] & 8) == 0) continue block92;
                        int n24 = n3 + ((b[n3][n4 + 1] & 0x10) == 0 ? 1 : -1);
                        n18 = n5 * 3;
                        if (this.d(n24, n4) >= 0) {
                            k.e[n18 + 0] = (byte)n24;
                            k.e[n18 + 1] = (byte)n24;
                            k.e[n18 + 2] = (byte)n4;
                        } else {
                            k.e[n18 + 2] = -1;
                        }
                        k.b[n3][n4] = b[n3][n4] & 0xFFFFFF | n5 << 24;
                        ++n5;
                        continue block92;
                    }
                    case 26: {
                        k.p[n7++] = 25;
                        continue block92;
                    }
                    case 42: {
                        k.p[n7++] = 11;
                        continue block92;
                    }
                    case 24: {
                        k.p[n7++] = 22;
                        continue block92;
                    }
                    case 27: {
                        k.p[n7++] = 23;
                        continue block92;
                    }
                    case 40: {
                        k.p[n7++] = 24;
                    }
                }
            }
        }
        k.a[this.an - 2][this.aS] = -193 << 8 | 7;
        if ((this.c & 0x100000000L) != 0L || i[9] >= 8) {
            this.c |= 0x10000000000L;
            this.c |= 2L;
            this.c |= 1L;
            if ((this.c & 0x20000L) != 0L) {
                this.c |= 0x40000L;
            }
            if ((this.c & 0x8000L) != 0L) {
                this.c |= 0x10000L;
            }
            if ((this.c & 0x800000000L) != 0L) {
                this.c |= 0x1000000000L;
            }
            if ((this.c & 0x2000000000L) != 0L) {
                this.c |= 0x4000000000L;
            }
            if ((this.c & 0x20000000000L) != 0L) {
                this.c |= 0x40000000000L;
            }
        }
    }

    public final void a(int n, int n2, int n3, int n4, int n5) {
        if (n + n3 <= 0 || n + n3 >= this.ax || n2 + n4 <= 0 || n2 + n4 >= this.ay) {
            return;
        }
        int n6 = n3;
        int n7 = n4;
        int n8 = a[n + n3][n2 + n4] & 0xFF;
        switch (n8) {
            case 8: 
            case 9: {
                int n9 = a[n + n3][n2 + n4] >> 8;
                n9 = n5 == 1 ? (n9 |= 0x200) : (n9 &= 0xFFFFFDFF);
                k.a[n + n3][n2 + n4] = n9 << 8 | n8;
                this.a(n + n3, n2 + n4, n6, n7, n5);
                this.a(n + n3, n2 + n4, 0, 1, n5);
            }
        }
    }

    public final boolean d(int n, int n2) {
        return n == this.aR && n2 == this.aS;
    }

    public final void t(int n) {
        this.k = 0;
        this.j = 0;
        for (int i2 = 0; i2 < p.length; ++i2) {
            if (p[i2] != n) continue;
            this.a = a[i2];
        }
        this.a.a();
    }

    public final boolean f() {
        if (this.ar < this.ck) {
            this.ar += this.cm;
            if (this.ar > this.ck) {
                this.ar = this.ck;
            }
        } else if (this.ar > this.ck) {
            this.ar -= this.cm;
            if (this.ar < this.ck) {
                this.ar = this.ck;
            }
        }
        if (this.as < this.cl) {
            this.as += this.cm;
            if (this.as > this.cl) {
                this.as = this.cl;
            }
        } else if (this.as > this.cl) {
            this.as -= this.cm;
            if (this.as < this.cl) {
                this.as = this.cl;
            }
        }
        boolean bl = false;
        boolean bl2 = false;
        if (this.ar < 0) {
            this.ar = 0;
            bl = true;
        } else if (this.ar > this.ax * 24 - 176) {
            this.ar = this.ax * 24 - 176;
            bl = true;
        } else if (this.ar == this.ck) {
            bl = true;
        }
        if (this.as < 0) {
            this.as = 0;
            bl2 = true;
        } else if (this.as > this.ay * 24 - 208 + 28) {
            this.as = this.ay * 24 - 208 + 28;
            bl2 = true;
        } else if (this.as == this.cl) {
            bl2 = true;
        }
        if (bl && bl2) {
            this.av = this.ar;
            this.aw = this.as;
            this.at = 0;
            this.au = 0;
            this.am = 45;
            return true;
        }
        return false;
    }

    public final void by() {
        switch (this.cn) {
            case 1: {
                this.cm = 8;
                if (!this.f()) break;
                this.cn = 2;
                this.dm = 26;
                return;
            }
            case 2: {
                --this.dm;
                if (this.dm == 19) {
                    int n = a[this.dk][this.dl] >> 8;
                    if ((n & 0xF0) == 0) break;
                    this.i(this.dk, this.dl);
                    return;
                }
                if (this.dm != 0) break;
                this.cn = 3;
                this.ck = this.aR * 24 - 76;
                this.cl = this.aS * 24 - 78;
                this.cm = 5;
                this.e = a[l[co]];
                a[41].a(this.e);
                this.dj = 52;
                return;
            }
            case 3: {
                if (!this.f()) break;
                this.dm = 13;
                this.cn = 4;
                this.am = 0;
                return;
            }
            case 4: {
                --this.dm;
                if (this.dm != 0) break;
                this.am = 0;
                this.cn = 0;
                ai = true;
            }
        }
    }

    public final void u(int n) {
        int n2 = this.ax - 1;
        int n3 = this.ay - 1;
        for (int i2 = 1; i2 < n3; ++i2) {
            for (int i3 = 1; i3 < n2; ++i3) {
                if ((a[i3][i2] & 0xFF) != 17 || a[i3][i2] >> 8 != n) continue;
                int n4 = -1;
                int n5 = -1;
                if (a[i3][i2] == 18) {
                    n4 = i3;
                    n5 = i2;
                } else {
                    int n6 = a[i3][i2 - 1] & 0xFF;
                    switch (n6) {
                        case 7: {
                            int n7 = a[i3][i2 - 1] >> 8;
                            if ((n7 & 0xF0) == 0) break;
                            n4 = i3;
                            n5 = i2 - 1;
                            break;
                        }
                        case 14: 
                        case 33: {
                            n4 = i3;
                            n5 = i2 - 1;
                        }
                    }
                }
                if (n4 == -1) continue;
                this.dk = n4;
                this.dl = n5;
                this.ck = 24 * n4 - 76;
                this.cl = 24 * n5 - 78;
            }
        }
    }

    public final void v(int n) {
        this.C(2);
        int n2 = this.ax - 1;
        int n3 = this.ay - 1;
        for (int i2 = 1; i2 < n3; ++i2) {
            block5: for (int i3 = 1; i3 < n2; ++i3) {
                if ((a[i3][i2] & 0xFF) != 17 || a[i3][i2] >> 8 != n) continue;
                int n4 = a[i3][i2 - 1] & 0xFF;
                switch (n4) {
                    case 7: {
                        this.h(i3, i2 - 1);
                        continue block5;
                    }
                    case 14: 
                    case 33: {
                        k.a[i3][i2 - 1] = 0 | n4;
                    }
                }
            }
        }
    }

    public final void bz() {
        int n;
        int n2 = this.aR - 7;
        int n3 = this.aR + 7;
        int n4 = this.aS + 7;
        int n5 = this.aS - 7;
        int n6 = 0;
        if (a[4] != null) {
            n = k.a[4].g;
            n6 = n == 0 ? 0 : (n <= 10 ? 1 : (n <= 20 ? 2 : 3));
        }
        if (n2 < 1) {
            n2 = 1;
        }
        if (n3 > this.ax - 2) {
            n3 = this.ax - 2;
        }
        if (n5 < 1) {
            n5 = 1;
        }
        if (n4 > this.ay - 2) {
            n4 = this.ay - 2;
        }
        this.bH = n4;
        while (this.bH >= n5) {
            this.bG = n2;
            while (this.bG <= n3) {
                int n7 = n = this.bk != 0 && this.bG == this.bi && this.bH == this.bj ? 1 : 0;
                if (c[this.bG][this.bH] > 0 && n == 0) {
                    byte[] byArray = c[this.bG];
                    int n8 = this.bH;
                    byArray[n8] = (byte)(byArray[n8] - 6);
                    byte by = (byte)(a[this.bG][this.bH] & 0xFF);
                    switch (by) {
                        case 36: {
                            this.aS();
                            break;
                        }
                        case 35: 
                        case 37: {
                            if (this.bG == this.bi && this.bH == this.bj && this.bk != 0) break;
                            this.bB();
                            break;
                        }
                        case 32: {
                            this.bF();
                            break;
                        }
                        case 26: {
                            this.bJ();
                            break;
                        }
                        case 6: {
                            this.bG();
                            break;
                        }
                        case 33: {
                            this.y(33);
                            break;
                        }
                        case 14: {
                            this.y(14);
                            break;
                        }
                        case 2: {
                            switch (a[this.bG][this.bH] >> 8) {
                                case 0: {
                                    if (a[this.bG - 1][this.bH] == 30 || a[this.bG + 1][this.bH] == 30 || a[this.bG][this.bH - 1] == 30 || a[this.bG][this.bH + 1] == 30) break;
                                    this.aA = -1;
                                    this.b(this.bG, this.bH, (byte)2);
                                }
                            }
                            break;
                        }
                        case 3: {
                            this.bY();
                            break;
                        }
                        case 30: {
                            if (this.a != null || this.bo != -1 || !this.d(this.bG, this.bH) || this.aT > 0) break;
                            this.bo = a[this.bG][this.bH] >> 8;
                            k.a[this.bG][this.bH] = -1;
                            break;
                        }
                        case 0: {
                            if (this.a != null || this.bo != -1 || !this.d(this.bG, this.bH) || this.aT > 6) break;
                            this.bo = a[this.bG][this.bH] >> 8;
                            k.a[this.bG][this.bH] = -1;
                            break;
                        }
                        case 7: {
                            this.bX();
                            break;
                        }
                        case 8: {
                            this.bW();
                            break;
                        }
                        case 9: {
                            this.bW();
                        }
                    }
                    int n9 = (a[this.bG][this.bH] & 0xF0000000) >> 28;
                    if (n9 > 0) {
                        this.bL();
                    }
                    by = a[this.bG][this.bH];
                    switch (by) {
                        case 54: {
                            this.bH();
                            break;
                        }
                        case 50: {
                            if (this.aT >= 12 || !this.d(this.bG, this.bH) || this.i) break;
                            this.a(1, 48, (int)h[this.aU & 7]);
                            break;
                        }
                        case 49: {
                            this.e((byte)49);
                            break;
                        }
                        case 48: {
                            if ((b[this.bG][this.bH] & 8) == 0) {
                                this.d((byte)48);
                                break;
                            }
                            this.bA();
                            break;
                        }
                        case 46: {
                            this.bD();
                            break;
                        }
                        case 45: {
                            this.aE();
                            break;
                        }
                        case 44: {
                            this.bE();
                            break;
                        }
                        case 40: {
                            this.w(40);
                            break;
                        }
                        case 36: {
                            this.bI();
                            break;
                        }
                        case 28: {
                            this.bV();
                            break;
                        }
                        case 16: {
                            this.bU();
                            break;
                        }
                        case 14: {
                            this.bT();
                            break;
                        }
                        case 10: {
                            this.bQ();
                            break;
                        }
                        case 21: {
                            this.bS();
                            break;
                        }
                        case 32: {
                            this.bR();
                            break;
                        }
                        case 11: {
                            this.bP();
                            break;
                        }
                        case 37: {
                            this.bO();
                            break;
                        }
                        case 30: {
                            this.bN();
                            break;
                        }
                        case 24: {
                            this.x(24);
                            break;
                        }
                        case 27: {
                            this.x(27);
                            break;
                        }
                        case 26: {
                            this.x(26);
                            break;
                        }
                        case 43: {
                            this.e((byte)43);
                            break;
                        }
                        case 19: {
                            this.e((byte)19);
                            break;
                        }
                        case 42: {
                            this.w(42);
                            break;
                        }
                        case 2: {
                            this.w(2);
                            break;
                        }
                        case 53: {
                            this.w(53);
                            break;
                        }
                        case 51: {
                            this.w(51);
                            break;
                        }
                        case 52: {
                            this.w(52);
                            break;
                        }
                        case 5: {
                            this.w(5);
                            break;
                        }
                        case 4: {
                            this.w(4);
                            break;
                        }
                        case 6: {
                            this.w(6);
                            break;
                        }
                        case 7: {
                            this.w(7);
                            break;
                        }
                        case 41: {
                            this.w(41);
                            break;
                        }
                        case 47: {
                            this.cb();
                            this.bC();
                            break;
                        }
                        case 1: {
                            this.cb();
                            break;
                        }
                        case 0: {
                            this.cb();
                            break;
                        }
                        case 9: {
                            if ((b[this.bG][this.bH] & 0xFC00000) == 0x8400000) {
                                k.c[this.bG][this.bH] = 24;
                                if (this.aj > 0) {
                                    --this.aj;
                                } else if (this.aj < 0) {
                                    ++this.aj;
                                }
                                if (this.ak > 0) {
                                    --this.ak;
                                } else if (this.ak < 0) {
                                    ++this.ak;
                                }
                            }
                            this.cb();
                            break;
                        }
                        case 8: {
                            this.cb();
                            break;
                        }
                        case 23: {
                            this.n(23, n6);
                            break;
                        }
                        case 22: {
                            this.n(22, n6);
                        }
                    }
                }
                ++this.bG;
            }
            --this.bH;
        }
    }

    public final void bA() {
        int n;
        int n2 = this.bG;
        int n3 = this.bH;
        int n4 = n3 + 1;
        int n5 = b[n2][n4];
        switch (n5 & 7) {
            case 4: {
                n = n2 + 1;
                break;
            }
            case 2: {
                n = n2 - 1;
                break;
            }
            default: {
                n = (n5 & 0x10) == 0 ? n2 + 1 : n2 - 1;
            }
        }
        int n6 = (b[n2][n3] >> 24) * 3;
        if (a[n][n3] < 0) {
            k.e[n6 + 2] = (byte)n3;
            k.e[n6 + 1] = (byte)n;
            k.e[n6 + 0] = (byte)n;
            return;
        }
        k.e[n6 + 2] = -1;
    }

    public final void d(byte by) {
        int n = this.bG;
        int n2 = this.bH;
        if (b[n][n2] == 6 && (a[n][n2] & 0xFF) == 6) {
            this.q(a[n][n2] >> 8);
        }
        if (b[n][n2] <= 0) {
            int n3 = b[n][n2];
            int n4 = n3 & 7;
            if (n4 == 2) {
                n3 |= 0x10;
            } else if (n4 == 4) {
                n3 &= 0xFFFFFFEF;
            }
            int n5 = n2 + 1;
            if (!(a[n][n5] >= 0 || this.d(n, n5) && this.aY == 0)) {
                k.a[n][n2 - 1] = -1;
                k.a[n][n5] = by;
                k.b[n][n5] = n3 & 0xFFFFFFF8 | 3;
                k.b[n][n2] = b[n][n2 - 1] | 8;
                k.b[n][n5] = 18;
                int n6 = n2 - 2;
                k.c[n - 1][n6] = 48;
                k.c[n][n6] = 48;
                k.c[n + 1][n6] = 48;
                this.p(n, n2);
                if (by == 48) {
                    this.bA();
                }
            } else {
                if ((n3 & 7) == 3 && this.d(n, n2 + 1)) {
                    this.a(2, 48, 0);
                }
                k.b[n][n2] = n3 & 0xFFFFFFF8 | 0;
            }
        } else {
            byte[] byArray = b[n];
            int n7 = n2;
            byArray[n7] = (byte)(byArray[n7] - 6);
        }
        k.c[n][n2] = 24;
        k.c[n][n2 - 1] = 24;
    }

    public final void bB() {
        int n = this.bG;
        int n2 = this.bH;
        k.c[n][n2] = 24;
        if (b[n][n2] <= 0) {
            int n3 = n2 - 1;
            int n4 = n2 + 1;
            byte by = (byte)(a[n][n3] & 0xFF);
            if (by == 34 || by == 37) {
                k.a[n][n3] = 37;
            } else if (by != 35 && this.e(n, n3)) {
                k.b[n][n3] = 18;
                k.a[n][n3] = 35;
            }
            byte by2 = a[n][n2];
            if (a[n][n3] < 0 && !this.d(n, n3) && by == 35 && by2 != 32 && by2 != 21 && a[n][n2] != -1) {
                k.b[n][n3] = 18;
                k.a[n][n3] = a[n][n2];
                k.b[n][n3] = b[n][n2] & 0xFFFFFFF8 | 1;
                k.a[n][n2] = -1;
                this.b(n, n2);
            } else {
                this.c(n, n2);
            }
            if ((a[n][n4] & 0xFF) != 35 && a[n][n4] != 47) {
                k.a[n][n2] = a[n][n2] == 37 ? 34 : -1;
            }
            k.c[n][n3] = 24;
            if (a[n][n2] < 0) {
                k.b[n][n2] = 18;
                return;
            }
        } else {
            byte[] byArray = b[n];
            int n5 = n2;
            byArray[n5] = (byte)(byArray[n5] - 6);
        }
    }

    public final boolean e(int n, int n2) {
        byte by = a[n][n2];
        int n3 = a[n][n2] & 0xFF;
        return by < 80 && by != 30 && by != 10 && by != 37 && by != 34 && by != 35 && n3 != 14 && n3 != 33 && n3 != 15 && n3 != 4 && n3 != 16;
    }

    public final boolean f(int n, int n2) {
        byte by = a[n][n2];
        int n3 = a[n][n2] & 0xFF;
        return by == -1 && n3 != 14 && n3 != 33 && n3 != 5 && n3 != 28;
    }

    public final boolean g(int n, int n2) {
        byte by = a[n][n2];
        int n3 = a[n][n2] & 0xFF;
        return by == -1 && n3 != 14 && n3 != 33 && n3 != 4 && n3 != 32 && (n3 != 7 || (a[n][n2] >> 8 & 0xF0) != 0);
    }

    public final void bC() {
        boolean bl;
        int n = this.bH - 1;
        boolean bl2 = bl = e != null && e[this.bG][this.bH] != 0 && e[this.bG][this.bH - 1] == 0;
        if ((b[this.bG][this.bH] & 7) == 0 && (a[this.bG][n] & 0xFF) != 35 && this.e(this.bG, n) && (!this.d(this.bG - 1, this.bH) && !this.d(this.bG + 1, this.bH) || (this.aU & 8) == 0) && (a[this.bG][this.bH + 1] >= 0 || bl)) {
            k.a[this.bG][n] = 35;
            k.b[this.bG][n] = 18;
            k.c[this.bG][n] = 24;
        }
    }

    public final void bD() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = b[n][n2] & 0x1F;
        int n4 = (b[n][n2] & 0x1FE0) >> 5;
        int n5 = this.a(a[29], n3);
        boolean bl = (a[n][n2] & 0xFF) == 35;
        if (bl) {
            if (++n4 > n5) {
                n4 = 0;
            }
            k.b[n][n2] = 0 | n4 << 5;
            return;
        }
        if (a[n][n2 + 1] < 0 && n3 != 8 && n3 != 9) {
            switch (n3) {
                case 0: 
                case 2: 
                case 4: 
                case 6: {
                    n3 = 8;
                    break;
                }
                default: {
                    n3 = 9;
                }
            }
            k.b[n][n2 + 1] = 18;
            k.a[n][n2 + 1] = 46;
            k.a[n][n2] = -1;
            k.b[n][n2 + 1] = n3;
            this.p(n, n2);
            return;
        }
        if (n3 == 8 || n3 == 9) {
            byte[] byArray = b[n];
            int n6 = n2;
            byArray[n6] = (byte)(byArray[n6] - 6);
            if (b[n][n2] < 0) {
                if (a[n][n2 + 1] < 0) {
                    k.b[n][n2 + 1] = 18;
                    k.a[n][n2 + 1] = 46;
                    k.a[n][n2] = -1;
                    k.b[n][n2 + 1] = n3;
                    this.p(n, n2);
                    return;
                }
                k.b[n][n2] = n3 = n3 == 8 ? 10 : 11;
                k.b[n][n2] = 0;
                return;
            }
            if (this.a(n, n2, 3, (int)b[n][n2], this.aR, this.aS, this.aU & 7, this.aT)) {
                this.a(1, 48, b[n][n2] & 7);
                return;
            }
        } else {
            if (this.i(n, n2)) {
                k.a[n][n2] = -1;
                this.o(n, n2);
                this.p(n, n2);
                return;
            }
            if (this.d(n - 1, n2) || this.d(n + 1, n2) || this.d(n, n2 - 1)) {
                if (this.aS == n2 - 1) {
                    n3 = 17;
                } else if (this.aR == n - 1) {
                    n3 = 16;
                } else if (this.aR == n + 1) {
                    n3 = 15;
                }
                n4 = 0;
            } else {
                int n7 = this.aU & 7;
                if (this.aR == n && this.aT == 6 && (n7 == 4 || n7 == 2) && this.aS < n2 && a[n][n2 - 1] < 0 && n2 * 24 <= this.as + 208 - 28) {
                    switch (n3) {
                        case 0: 
                        case 2: {
                            n3 = 6;
                            n4 = 0;
                            break;
                        }
                        case 1: 
                        case 3: {
                            n3 = 7;
                            n4 = 0;
                        }
                    }
                } else if (this.aS == n2 && this.aT == 6 && (n7 == 1 || n7 == 3) && n3 >= 0 && n3 <= 3 && (this.aR < n && a[n - 1][n2] < 0 && n * 24 < this.ar + 176 || this.aR > n && a[n + 1][n2] < 0 && (n + 1) * 24 > this.ar)) {
                    n3 = this.aR < n ? 4 : 5;
                    n4 = 0;
                } else {
                    int n8;
                    ++n4;
                    switch (n3) {
                        case 4: {
                            n8 = n - 1;
                            if (a[n8][n2] >= 0 || n4 != this.b(a[29], 4, 1)) break;
                            k.a[n8][n2] = 21;
                            k.b[n8][n2] = 4;
                            k.b[n8][n2] = 18;
                            k.c[n8][n2] = 24;
                            break;
                        }
                        case 5: {
                            int n9 = n + 1;
                            if (a[n9][n2] >= 0 || n4 != this.b(a[29], 5, 1)) break;
                            k.a[n9][n2] = 21;
                            k.b[n9][n2] = 2;
                            k.b[n9][n2] = 18;
                            k.c[n9][n2] = 24;
                            break;
                        }
                        case 6: 
                        case 7: {
                            int n10 = n2 - 1;
                            if (a[n][n10] >= 0 || n4 != this.b(a[29], n3, 1)) break;
                            k.a[n][n10] = 21;
                            k.b[n][n10] = 1;
                            k.b[n][n10] = 18;
                            k.c[n][n10] = 24;
                        }
                    }
                    if (n4 > n5) {
                        n4 = 0;
                        n8 = this.a(n, n2, this.aR, this.aS, false);
                        switch (n8) {
                            case 4: {
                                if (this.aS == n2 && n3 != 4 && n * 24 < this.ar + 176) {
                                    n3 = 4;
                                    break;
                                }
                                n3 = 0;
                                break;
                            }
                            case 2: {
                                if (this.aS == n2 && n3 != 5 && (n + 1) * 24 > this.ar) {
                                    n3 = 5;
                                    break;
                                }
                                n3 = 1;
                                break;
                            }
                            case 1: {
                                if (this.aR == n && n3 != 6 && n3 != 7 && n2 * 24 <= this.as + 208 - 28) {
                                    n3 = n3 == 2 ? 6 : 7;
                                    break;
                                }
                                n3 = this.aR < n ? 2 : 3;
                                break;
                            }
                            default: {
                                n3 = this.aR < n ? 0 : 1;
                            }
                        }
                    }
                }
            }
            k.c[n][n2] = 24;
            k.b[n][n2] = n3 & 0x1F | n4 << 5;
        }
    }

    public final int a(b b2, int n) {
        int n2 = 0;
        int n3 = b2.e[n] & 0xFF;
        for (int i2 = 0; i2 < n3; ++i2) {
            n2 += b2.f[(b2.b[n] + i2) * 5 + 1] & 0xFF;
        }
        return n2;
    }

    public final void bE() {
        int n = this.bG;
        int n2 = this.bH;
        k.c[n][n2] = 24;
        int n3 = (b[n][n2] & 0x38) >> 3;
        switch (n3) {
            case 0: {
                if ((this.aR != n || (n2 + 1) * 24 <= this.as || this.i == 3) && (this.i != 3 || this.n == 0L || (long)aP < this.n + (long)(21 - n))) break;
                int n4 = n2 + 1;
                byte by = a[n][n4];
                while (this.aS != n4 && by < 80 && by != 30 && by != 34 && by != 35 && by != 0) {
                    by = a[n][++n4];
                }
                if (this.aS != n4 && this.i != 3) break;
                k.b[n][n2] = b[n][n2] & 0xFFFFFFC7 | 8;
                k.b[n][n2] = 10;
                return;
            }
            case 1: {
                byte[] byArray = b[n];
                int n5 = n2;
                byArray[n5] = (byte)(byArray[n5] - 1);
                if (b[n][n2] > 0) break;
                k.a[n][n2] = 34;
                k.b[n][n2] = b[n][n2] & 0xFFFFFFC0 | 0x18 | 3;
                k.b[n][n2] = 0;
                return;
            }
            case 3: {
                if (b[n][n2] <= 0) {
                    boolean bl = this.d(n, n2 + 1);
                    boolean bl2 = false;
                    if (bl || a[n][n2 + 1] >= 0 || this.k && e[n][n2 + 1] != 0) {
                        if (bl) {
                            this.a(1, 48, 0);
                            bl2 = true;
                        } else {
                            bl2 = true;
                            switch (a[n][n2 + 1]) {
                                case 10: {
                                    k.a[n][n2 + 1] = 32;
                                    this.b(n, n2 + 1);
                                    bl2 = false;
                                    break;
                                }
                                case 19: 
                                case 43: 
                                case 45: 
                                case 46: 
                                case 49: {
                                    this.o(n, n2 + 1);
                                    k.a[n][n2 + 1] = -1;
                                    break;
                                }
                                case 30: {
                                    this.C(9);
                                    k.b[n][n2 + 1] = 1;
                                    break;
                                }
                                case 18: {
                                    this.c();
                                    break;
                                }
                                case 21: {
                                    bl2 = false;
                                    break;
                                }
                                default: {
                                    this.C(10);
                                }
                            }
                        }
                    }
                    if (bl2) {
                        k.b[n][n2] = b[n][n2] & 0xFFFFFFC0 | 0x20;
                        k.b[n][n2] = 0;
                        return;
                    }
                    k.a[n][n2] = -1;
                    k.a[n][n2 + 1] = 44;
                    k.b[n][n2 + 1] = b[n][n2];
                    k.b[n][n2 + 1] = 19;
                    this.p(n, n2);
                    return;
                }
                byte[] byArray = b[n];
                int n6 = n2;
                byArray[n6] = (byte)(byArray[n6] - 5);
                return;
            }
            case 4: {
                if ((aP & 1) != 0) break;
                byte[] byArray = b[n];
                int n7 = n2;
                byArray[n7] = (byte)(byArray[n7] + 1);
                if (b[n][n2] != a[27].a(4)) break;
                k.a[n][n2] = -1;
                this.p(n, n2);
            }
        }
    }

    public final void bF() {
        int n = a[this.bG][this.bH] >> 8 & 0xFF;
        if ((aP & 1) == 0) {
            ++n;
        } else if (n == 1) {
            this.b(this.bG, this.bH);
        }
        k.a[this.bG][this.bH] = n == a[16].a(0) ? -1 : n << 8 | 0x20;
        k.c[this.bG][this.bH] = 24;
    }

    public final void bG() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = a[n][n2] >> 8;
        boolean bl = this.j(n, n2) || a[n][n2] == 47 || a[n][n2] == 48;
        int n4 = b[n][n2];
        if (!bl && this.d(n, n2)) {
            bl = true;
            int n5 = n4 = (this.aU & 0x1000) != 0 ? 0 : this.aT;
        }
        if (bl && n4 < 12) {
            this.q(n3);
            return;
        }
        this.r(n3);
    }

    public final void bH() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = b[n][n2];
        b b2 = a[7];
        int n4 = this.a(b2, 0);
        if (++n3 >= n4) {
            k.a[n][n2] = -1;
            this.p(n, n2);
            return;
        }
        if (n3 == 1) {
            this.C(8);
            this.p(n, n2);
        } else if (n3 == n4 >> 1) {
            for (int i2 = -1; i2 < 2; ++i2) {
                for (int i3 = -1; i3 < 2; ++i3) {
                    int n5 = n + i3;
                    int n6 = n2 + i2;
                    switch (a[n5][n6]) {
                        case 10: {
                            if (this.v != 3) break;
                        }
                        case 30: 
                        case 37: {
                            k.b[n5][n6] = 1;
                            this.p(n5, n6);
                            break;
                        }
                        case 16: 
                        case 19: 
                        case 43: 
                        case 49: {
                            k.a[n5][n6] = -1;
                            this.o(n5, n6);
                            k.c[n5][n6] = 24;
                            break;
                        }
                        case 8: {
                            k.a[n5][n6] = 54;
                            k.b[n5][n6] = 0;
                            this.p(n5, n6);
                        }
                    }
                    if (!this.d(n5, n6)) continue;
                    this.a(1, 64, 0);
                }
            }
        }
        k.b[n][n2] = n3;
        k.c[n][n2] = 24;
    }

    public final void bI() {
        int n = this.bG;
        int n2 = this.bH;
        if (b[n][n2] == 0) {
            if (a[n][n2 - 1] == 11) {
                k.b[n][n2] = 1;
                this.bM();
                return;
            }
        } else if (this.d(n, n2 - 1)) {
            this.a(1, 64, 0);
        }
    }

    public final void bJ() {
        if (this.aT <= 6 && this.d(this.bG, this.bH)) {
            W = 0;
            this.j = 0;
            co = a[this.bG][this.bH] >> 8;
            this.i(this.aR + g[this.aU & 7], this.aS);
            if (co < 0 || co >= m.length) {
                co = -1;
            } else {
                this.cn = 1;
                this.u(co);
            }
            k.a[this.bG][this.bH] = -1;
        }
    }

    public final void n(int n, int n2) {
        int n3 = this.bG;
        int n4 = this.bH;
        int n5 = n == 23 ? -1 : 1;
        k.c[n3][n4] = 24;
        if (this.aS == n4) {
            for (int i2 = 0; i2 <= n2; ++i2) {
                int n6 = n3 + i2 * n5;
                if (this.aR != n6) continue;
                this.a(1, 64, 0);
            }
        }
    }

    public final void bK() {
        boolean bl = false;
        int n = -1;
        boolean bl2 = false;
        switch (this.aF) {
            case 26: {
                bl = true;
                this.bo = 25;
                bl2 = true;
                break;
            }
            case 24: {
                bl2 = true;
                bl = true;
                this.bo = 22;
                break;
            }
            case 27: {
                bl2 = true;
                bl = true;
                this.bo = 23;
                break;
            }
            case 40: {
                bl2 = true;
                bl = true;
                this.bo = 24;
                break;
            }
            case 42: {
                bl2 = true;
                bl = true;
                this.o = true;
                this.bo = 11;
                break;
            }
            case 41: {
                if (this.e()) {
                    this.ah = true;
                    this.a();
                }
                this.bb += this.aE;
                this.P -= this.aE;
                if (this.P <= 0 && !this.e()) {
                    k.a[this.Q][this.R] = -1;
                    this.P = 0;
                }
                n = 3;
                break;
            }
            case 4: {
                n = 2;
                ++this.aW;
                break;
            }
            case 5: {
                ++this.aX;
                n = 1;
                break;
            }
            case 2: {
                ++this.bd;
                bl2 = true;
                n = 0;
                break;
            }
            case 6: {
                ++this.ao;
                k.e[this.aR][this.aS] = -1;
                int[] nArray = d[this.aR];
                int n2 = this.aS;
                nArray[n2] = nArray[n2] | 0x100;
                n = 0;
                this.a(this.ap, this.aq, this.aR, this.aS);
                break;
            }
            case 7: {
                this.a((byte)127);
                n = 4;
                break;
            }
            case 51: 
            case 52: 
            case 53: {
                this.a(this.ap, this.aq, this.aR, this.aS);
                n = 0;
                bl = true;
                this.a();
                this.g = true;
                this.s = this.aF == 53 ? 0 : (this.aF == 51 ? 1 : 2);
                i[2] = (byte)(i[2] | 1 << this.s);
                this.A();
            }
        }
        if (bl) {
            this.m(47);
        }
        if (n != -1) {
            this.e(this.aR, this.aS - 1, n);
        }
        if (bl2) {
            k.d[this.X << 1] = (byte)this.aR;
            k.d[(this.X << 1) + 1] = (byte)this.aS;
            ++this.X;
        }
        this.v();
        this.aF = -1;
    }

    public final void w(int n) {
        int n2 = this.bG;
        int n3 = this.bH;
        if (this.aT > 0 || !this.d(n2, n3)) {
            return;
        }
        int n4 = a[n2][n3] & 0xFF;
        if ((n4 == 14 || n4 == 33) && a[n2][n3] >> 8 == 255) {
            return;
        }
        this.aF = n;
        switch (n) {
            case 40: {
                this.aC = 19;
                this.aD = 0;
                k.a[this.bG][this.bH] = -1;
                this.aF = 40;
                k.i[10] = 1;
                break;
            }
            case 42: {
                this.aC = 29;
                this.aD = 0;
                break;
            }
            case 41: {
                this.aC = 2;
                this.aD = 0;
                this.aE = b[this.bG][this.bH];
                break;
            }
            case 4: {
                this.aC = 24;
                this.aD = 0;
                break;
            }
            case 5: {
                this.aC = 25;
                this.aD = 0;
                break;
            }
            case 2: {
                this.aC = 3;
                this.aD = 0;
                break;
            }
            case 53: {
                this.aC = 32;
                this.aD = 0;
                break;
            }
            case 51: {
                this.aC = 30;
                this.aD = 0;
                break;
            }
            case 52: {
                this.aC = 31;
                this.aD = 0;
                break;
            }
            case 6: {
                if (this.ao < 99) {
                    this.aC = 5;
                    this.aD = 0;
                    break;
                }
                k.a[n2][n3] = 7;
                k.b[n2][n3] = 0;
                this.w(7);
                break;
            }
            case 7: {
                if (this.m == i[8]) {
                    k.a[n2][n3] = 41;
                    k.b[n2][n3] = 10;
                    this.ba += 10;
                    this.w(41);
                    break;
                }
                this.aC = 5;
                this.aD = 1;
            }
        }
        k.a[n2][n3] = -1;
        this.v();
    }

    public final boolean h(int n, int n2) {
        return a[n][n2] == 28 || this.aK >= 24 && (a[n][n2 - 1] == 28 && (b[n][n2 - 1] & 8) == 0 || a[n][n2 + 1] == 28 && (b[n][n2 + 1] & 8) == 0) || this.aM >= 24 && (a[n][n2 - 1] == 28 || a[n][n2 + 1] == 28);
    }

    public final int a(int n, int n2, int n3, int n4, boolean bl) {
        int n5 = n - n3;
        int n6 = n2 - n4;
        int n7 = n5 > 0 ? n5 : -n5;
        int n8 = n6 > 0 ? n6 : -n6;
        int n9 = 0;
        if (n7 > n8) {
            if (n5 > 0) {
                n9 = 4;
            } else if (n5 < 0) {
                n9 = 2;
            }
            if (n9 != 0 && (!this.g(n - g[n9], n2) || this.h(n - g[n9], n2))) {
                n9 = 0;
            }
        }
        if (n9 == 0) {
            if (n6 > 0) {
                n9 = 1;
            } else if (n6 < 0) {
                n9 = 3;
            }
            int n10 = n2 - g[8 + n9];
            if (bl && n9 != 0 && (!this.g(n, n10) || this.k && e[n][n10] != 0 || this.h(n, n10))) {
                n9 = 0;
                if (n5 > 0) {
                    n9 = 4;
                } else if (n5 < 0) {
                    n9 = 2;
                }
                if (n9 != 0 && a[n - g[n9]][n2] >= 0) {
                    n9 = 0;
                }
            }
        }
        return n9;
    }

    public final void e(byte by) {
        boolean bl;
        int n = this.bG;
        int n2 = this.bH;
        int n3 = b[n][n2];
        int n4 = b[n][n2];
        int n5 = 0;
        int n6 = 0;
        boolean bl2 = (a[n][n2] & 0xFF) == 35;
        boolean bl3 = bl = by == 43 && (n3 & 0xF00) != 0;
        if (!bl2 && this.i(n, n2)) {
            k.a[n][n2] = -1;
            this.o(n, n2);
            return;
        }
        int n7 = n3 & 7;
        if (n4 <= 0) {
            if (bl2 && n4 <= 6) {
                if (n4 < 0) {
                    k.b[n][n2] = 0;
                }
            } else {
                this.p(n, n2);
                if (bl) {
                    n4 = 18;
                    int n8 = this.a(n, n2, this.aR, this.aS, true);
                    n3 = n3 & 0xFFFFFFF8 | n8;
                    n7 = n8;
                    n5 = -g[n8];
                    n6 = -g[n8 + 8];
                    if (n8 == 0) {
                        n4 = 0;
                        n6 = 0;
                        n5 = 0;
                    }
                    n3 -= 256;
                } else if ((n3 & 0xFE0000) != 0 && (n3 & 0xF8) == 0) {
                    int n9 = (n3 & 0xFE0000) >> 17;
                    int n10 = (n3 & 0x7F000000) >> 24;
                    if (n == n9 && n2 == n10) {
                        n7 = ((n3 &= 0xFF01FFFF) & Integer.MIN_VALUE) == 0 ? 2 : 1;
                        n3 = n3 & 0xFFFFFFF8 | n7;
                    } else {
                        n4 = 21;
                        int n11 = this.a(n, n2, n9, n10, true);
                        n3 = n3 & 0xFFFFFFF8 | n11;
                        n5 = -g[n11];
                        n6 = -g[n11 + 8];
                        n7 = n11;
                        if (n11 == 0) {
                            n4 = 0;
                            n6 = 0;
                            n5 = 0;
                        }
                    }
                } else if (n7 == 0) {
                    n4 = 21;
                    int n12 = (n3 & 0x7000) >> 12;
                    n3 = n3 & 0xFFFFFFF8 | n12;
                    n7 = n12;
                    n5 = -g[n12];
                    n6 = -g[n12 + 8];
                    if (!this.g(n + n5, n2 + n6)) {
                        n6 = 0;
                        n5 = 0;
                        n4 = 0;
                    }
                } else {
                    n4 = 21;
                    n5 = -g[n7];
                    n6 = -g[n7 + 8];
                    if (!this.g(n + n5, n2 + n6)) {
                        switch (n7) {
                            case 4: {
                                n3 = n3 & 0xFFFF8FFF | 0x2000;
                                break;
                            }
                            case 2: {
                                n3 = n3 & 0xFFFF8FFF | 0x4000;
                                break;
                            }
                            case 1: {
                                n3 = n3 & 0xFFFF8FFF | 0x3000;
                                break;
                            }
                            case 3: {
                                n3 = n3 & 0xFFFF8FFF | 0x1000;
                            }
                        }
                        n3 = n3 & 0xFFFFFFF8 | 0;
                        n7 = 0;
                        n6 = 0;
                        n5 = 0;
                    }
                }
            }
            if ((n3 & 0xF8) == 0) {
                k.a[n][n2] = -1;
                k.a[n + n5][n2 + n6] = by;
                k.c[n + n5][n2 + n6] = 48;
                k.b[n + n5][n2 + n6] = n4;
                k.b[n + n5][n2 + n6] = n3;
            } else {
                if ((aP & 3) == 0) {
                    n3 = n3 & 0xFFFFFF07 | (n3 & 0xF8) - 8;
                    if (by == 43 && (n3 & 0xF8) == 0) {
                        n3 = n3 & 0xFFFFF0FF | 0xC00;
                    }
                }
                k.b[n][n2] = 0;
            }
        } else {
            if (n4 < 0) {
                k.b[n][n2] = 0;
            }
            k.b[n][n2] = n4 = (byte)(n4 - 3);
        }
        if ((n3 & 0xF8) == 0 && (k.a[0].f < 13 || k.a[0].f > 16) && this.a(n, n2, n7, (int)b[n][n2], this.aR, this.aS, (int)((this.aU & 0x1000) == 0 ? this.k : (byte)0), this.aT)) {
            this.a(1, 48, n7);
            if (bl) {
                n3 &= 0xFFFFF0FF;
            }
        }
        k.b[n][n2] = n3;
    }

    public final void bL() {
        int n = (a[this.bG][this.bH] & 0xF0000000) >> 28;
        if (n == 0) {
            this.C(4);
        }
        if ((aP & 1) == 0) {
            ++n;
        }
        k.a[this.bG][this.bH] = n >= a[13].a(0) ? a[this.bG][this.bH] & 0xFFFFFFF : a[this.bG][this.bH] & 0xFFFFFFF | n << 28;
        this.p(this.bG, this.bH);
    }

    public final void bM() {
        if ((this.i == 3 || this.i == 4 || this.i == 5) && this.af > 0) {
            return;
        }
        if (co >= 0) {
            int n = co;
            m[n] = (byte)(m[n] - 1);
            if (m[co] == 0) {
                this.v(co);
            }
        }
    }

    public final void x(int n) {
        if ((a[this.bG][this.bH] & 0xFF) == 14 && a[this.bG][this.bH] >> 8 == 255) {
            return;
        }
        if (this.d(this.bG, this.bH) && (k.a[0].f == 40 || k.a[0].f == 48)) {
            k.a[this.bG][this.bH] = -1;
            switch (n) {
                case 24: {
                    k.i[9] = 1;
                    this.aC = 7;
                    this.aD = 0;
                    this.aF = 24;
                    break;
                }
                case 27: {
                    k.i[9] = 2;
                    this.aC = 7;
                    this.aD = 1;
                    this.aF = 27;
                    break;
                }
                case 26: {
                    k.i[9] = 8;
                    this.aC = 7;
                    this.aD = 2;
                    this.aF = 26;
                }
            }
            this.a(this.ap, this.aq, this.bG, this.bH);
        }
    }

    public final void bN() {
        int n = b[this.bG][this.bH];
        if (n > 0) {
            int n2 = this.bG;
            int n3 = this.bH;
            if (n == 4) {
                for (int i2 = 1; i2 < 5; ++i2) {
                    byte by = g[i2];
                    byte by2 = g[i2 + 8];
                    if (a[n2 + by][n3 + by2] != 30) continue;
                    int[] nArray = b[n2 + by];
                    int n4 = n3 + by2;
                    nArray[n4] = nArray[n4] + 1;
                    k.c[n2 + by][n3 + by2] = 24;
                }
            } else if (n >= 16) {
                k.a[n2][n3] = -1;
                this.p(n2, n3);
            }
            k.b[n2][n3] = n + 1;
            k.c[n2][n3] = 24;
        }
    }

    public final void bO() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = b[n][n2];
        if (n3 > 0) {
            if (n3 >= 8) {
                this.s(n, n2);
                k.a[n][n2] = -1;
                this.p(n, n2);
            }
            k.b[n][n2] = n3 + 1;
            k.c[n][n2] = 24;
        }
    }

    public final void bP() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = (b[n][n2] & 0xF00) >> 8;
        if (n3 != 0) {
            if (n3 >= 4) {
                k.a[n][n2] = -1;
            } else if ((aP >> 1 & 1) == 0) {
                k.b[n][n2] = b[n][n2] + 256;
            }
        } else if (e != null && e[n][n2] != 0) {
            k.b[n][n2] = b[n][n2] & 0xFFFFF0FF | 0x100;
        } else if (b[n][n2] <= 4) {
            int n4 = b[n][n2];
            k.c[n][n2] = 24;
            boolean bl = (n4 & 0x10) != 0;
            int n5 = n4 & 7;
            if (n5 != 0) {
                int n6 = 0;
                int n7 = 0;
                int n8 = 0;
                int n9 = 0;
                int n10 = 0;
                int n11 = 0;
                switch (n5) {
                    case 3: {
                        n6 = bl ? 1 : -1;
                        n10 = bl ? 2 : 4;
                        n11 = bl ? 4 : 2;
                        n9 = 1;
                        break;
                    }
                    case 2: {
                        n7 = bl ? -1 : 1;
                        n10 = bl ? 1 : 3;
                        n11 = bl ? 3 : 1;
                        n8 = 1;
                        break;
                    }
                    case 1: {
                        n6 = bl ? -1 : 1;
                        n10 = bl ? 4 : 2;
                        n11 = bl ? 2 : 4;
                        n9 = -1;
                        break;
                    }
                    case 4: {
                        n7 = bl ? 1 : -1;
                        n10 = bl ? 3 : 1;
                        n11 = bl ? 1 : 3;
                        n8 = -1;
                    }
                }
                if (this.g(n + n8, n2 + n9) && this.g(n + n6, n2 + n7) && this.g(n + n6 - n8, n2 + n7 - n9)) {
                    if (b[n][n2] <= 0) {
                        k.b[n + n8][n2 + n9] = n4;
                        k.a[n + n8][n2 + n9] = 11;
                        k.a[n][n2] = -1;
                        k.b[n + n8][n2 + n9] = 18;
                    }
                } else if (this.g(n + n6, n2 + n7)) {
                    k.b[n + n6][n2 + n7] = n4 & 0xFFFFFFF8 | n10;
                    k.a[n + n6][n2 + n7] = 11;
                    k.a[n][n2] = -1;
                    k.b[n + n6][n2 + n7] = 18;
                } else if (this.g(n + n8, n2 + n9)) {
                    if (b[n][n2] <= 0) {
                        k.b[n + n8][n2 + n9] = n4;
                        k.a[n + n8][n2 + n9] = 11;
                        k.a[n][n2] = -1;
                        k.b[n + n8][n2 + n9] = 18;
                    }
                } else {
                    k.b[n][n2] = n4 & 0xFFFFFFF8 | n11;
                }
            } else {
                if (a[n - 1][n2] >= 0) {
                    k.b[n][n2] = n4 & 0xFFFFFFF8 | (bl ? 1 : 3);
                } else if (a[n][n2 + 1] >= 0) {
                    k.b[n][n2] = n4 & 0xFFFFFFF8 | (bl ? 2 : 4);
                }
                if (a[n + 1][n2] >= 0) {
                    k.b[n][n2] = n4 & 0xFFFFFFF8 | (bl ? 3 : 1);
                }
                if (a[n][n2 + 1] >= 0) {
                    k.b[n][n2] = n4 & 0xFFFFFFF8 | (bl ? 4 : 2);
                }
            }
            this.p(n, n2);
        }
        if (this.d(n, n2)) {
            this.a(1, 64, 0);
        }
        if (b[n][n2] > 0) {
            byte[] byArray = b[n];
            int n12 = n2;
            byArray[n12] = (byte)(byArray[n12] - 5);
        }
    }

    public final void bQ() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = b[n][n2];
        if (n3 > 0) {
            k.a[n][n2] = -1;
            k.a[n][n2] = 32;
            this.p(n, n2);
            this.s(n, n2);
            k.c[n][n2] = 24;
        }
    }

    /*
     * Unable to fully structure code
     */
    public final void bR() {
        block16: {
            block12: {
                block15: {
                    block13: {
                        block14: {
                            var1_1 = this.bG;
                            var2_2 = this.bH;
                            k.c[var1_1][var2_2] = 24;
                            if (k.b[var1_1][var2_2] != 0) break block12;
                            var3_3 = k.b[var1_1][var2_2];
                            var4_4 = (var3_3 & 1) == 0 ? -1 : 1;
                            var5_5 = k.a[var1_1 + var4_4][var2_2];
                            var6_6 = k.a[var1_1 + var4_4][var2_2] & 255;
                            var7_7 = false;
                            var8_8 = var3_3 >> 1;
                            if (var8_8 <= 0) break block13;
                            if (var5_5 >= 0 || var6_6 == 14 || var6_6 == 33) break block14;
                            k.b[var1_1 + var4_4][var2_2] = var8_8 - 1 << 1 | var3_3 & 1;
                            k.c[var1_1 + var4_4][var2_2] = 30;
                            k.b[var1_1 + var4_4][var2_2] = 18;
                            var5_5 = 32;
                            break block15;
                        }
                        if (var5_5 == 32) break block15;
                        var9_9 = k.b[var1_1 + var4_4][var2_2];
                        var10_10 = 0;
                        if (var5_5 == 48 && (var9_9 & 8) != 0) break block15;
                        switch (var5_5) {
                            case 1: 
                            case 2: 
                            case 4: 
                            case 5: 
                            case 6: 
                            case 7: {
                                var10_10 = -var4_4;
                            }
                            case 0: 
                            case 8: 
                            case 9: 
                            case 11: 
                            case 14: 
                            case 19: 
                            case 43: 
                            case 47: 
                            case 48: 
                            case 49: {
                                this.C(5);
                                this.n = 0;
                                this.bk = this.aR - (var1_1 + var4_4) + var10_10;
                                this.bi = var1_1 + var4_4;
                                this.bj = var2_2;
                                if (this.bh == -1) {
                                    switch (var5_5) {
                                        case 0: 
                                        case 8: 
                                        case 9: 
                                        case 47: {
                                            var9_9 &= -28673;
                                            var9_9 &= -513;
                                        }
                                    }
                                    this.bh = var9_9;
                                }
                                if (this.bk < 0) {
                                    this.bg = var9_9 & -8 | 4;
                                    ** break;
                                }
                                this.bg = var9_9 & -8 | 2;
                                ** break;
                            }
                            default: {
                                if (var5_5 != -1) {
                                    var7_7 = true;
                                    ** break;
                                }
                                break block15;
                            }
                        }
lbl49:
                        // 3 sources

                        break block15;
                    }
                    var7_7 = true;
                }
                if (var7_7) {
                    for (var9_9 = 1; var9_9 <= 3; ++var9_9) {
                        if (k.a[this.aR + var4_4 * var9_9][this.aS] != 32) continue;
                        k.a[this.aR + var4_4 * var9_9][this.aS] = -1;
                    }
                }
                k.a[var1_1 + var4_4][var2_2] = var5_5;
                break block16;
            }
            v0 = k.b[var1_1];
            v1 = var2_2;
            v0[v1] = (byte)(v0[v1] - 6);
        }
        this.p(var1_1, var2_2);
    }

    public final void bS() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = b[n][n2] & 7;
        if ((b[n][n2] & 8) != 0) {
            int n4;
            switch (n3) {
                case 4: {
                    n4 = 12;
                    break;
                }
                case 2: {
                    n4 = 13;
                    break;
                }
                default: {
                    n4 = 14;
                }
            }
            if (b[n][n2] >= this.a(a[29], n4) || (a[this.bG][this.bH] & 0xFF) == 35) {
                k.a[n][n2] = -1;
                this.p(n, n2);
            } else {
                byte[] byArray = b[n];
                int n5 = n2;
                byArray[n5] = (byte)(byArray[n5] + 1);
            }
            k.c[n][n2] = 24;
            return;
        }
        if (this.d(n, n2) || this.d(n + g[n3], n2 + g[8 + n3]) && b[n][n2] <= this.aT) {
            this.a(1, 48, 0);
        }
        if (b[n][n2] <= 0) {
            int n6 = n - g[n3];
            int n7 = n2 - g[n3 + 8];
            int n8 = 24;
            if (n3 == 4) {
                n8 = 12;
            }
            if (a[n6][n7] < 0) {
                k.a[n6][n7] = 21;
                k.b[n6][n7] = b[n][n2];
                k.b[n6][n7] = n8;
                k.a[n][n2] = -1;
            } else if (a[n6][n7] == 21) {
                int n9 = b[n6][n7] & 7;
                int n10 = n6 - g[n9];
                int n11 = n7 - g[n9 + 8];
                k.a[n][n2] = -1;
                this.p(n, n2);
                int n12 = b[n][n2];
                if (a[n10][n11] < 0) {
                    k.a[n10][n11] = 21;
                    k.b[n10][n11] = b[n6][n7];
                    k.b[n10][n11] = 18;
                }
                k.a[n6][n7] = 21;
                k.b[n6][n7] = n12;
                k.b[n6][n7] = 18;
            } else {
                switch (a[n6][n7]) {
                    case 19: 
                    case 43: 
                    case 45: 
                    case 46: {
                        k.a[n6][n7] = -1;
                        this.o(n6, n7);
                        break;
                    }
                    case 10: 
                    case 30: {
                        if (b[n6][n7] >= 1) break;
                        k.b[n6][n7] = 1;
                    }
                }
                int[] nArray = b[n];
                int n13 = n2;
                nArray[n13] = nArray[n13] | 8;
                k.b[n][n2] = 0;
            }
            k.c[n6][n7] = 48;
            return;
        }
        byte[] byArray = b[n];
        int n14 = n2;
        byArray[n14] = (byte)(byArray[n14] - 12);
    }

    public final void o(int n, int n2) {
        k.a[n][n2] = a[n][n2] & 0xFFFFFFF | 0x10000000;
        this.bM();
    }

    public final void bT() {
        int n;
        int n2 = this.bG;
        int n3 = this.bH;
        int n4 = b[n2][n3];
        int n5 = (n4 & 0xFF00) >> 8;
        int n6 = n = (n4 & 8) != 0 ? 4 : 2;
        if (n5 >= 13) {
            if (this.g(n2, n3 + 1) || n == 4 && (a[n2 - 1][n3] < 0 || a[n2 - 1][n3] == 16 || a[n2 - 1][n3] == 19 || a[n2 - 1][n3] == 43) || n == 2 && (a[n2 + 1][n3] < 0 || a[n2 + 1][n3] == 16 || a[n2 + 1][n3] == 19 || a[n2 + 1][n3] == 43)) {
                k.b[n2][n3] = n4 & 0xFFFF00FF | 0xC00;
            }
        } else if (n5 > 0) {
            k.b[n2][n3] = n4 & 0xFFFF00FF | n5 - 1 << 8;
            k.c[n2][n3] = 24;
        } else {
            byte by = b[n2][n3];
            if (by <= 0) {
                int n7 = n2;
                int n8 = n3;
                if (this.g(n2, n3 + 1)) {
                    n8 = n3 + 1;
                    n = 3;
                } else if (n == 4) {
                    if (this.g(n2 - 1, n3)) {
                        n7 = n2 - 1;
                    } else {
                        n = 0;
                        if (a[n2 - 1][n3] != 16 && a[n2 - 1][n3] != 19 && a[n2 - 1][n3] != 43) {
                            n4 = n4 & 0xFFFF00FF | 0xD00;
                        }
                    }
                } else if (n == 2) {
                    if (this.g(n2 + 1, n3)) {
                        n7 = n2 + 1;
                    } else {
                        n = 0;
                        if (a[n2 + 1][n3] != 16 && a[n2 + 1][n3] != 19 && a[n2 + 1][n3] != 43) {
                            n4 = n4 & 0xFFFF00FF | 0xD00;
                        }
                    }
                }
                if (n7 != n2 || n8 != n3) {
                    k.a[n7][n8] = 14;
                    this.p(n7, n8);
                    k.a[n2][n3] = -1;
                    k.b[n7][n8] = 18;
                }
                k.b[n7][n8] = n4 & 0xFFFFFFF8 | n;
            } else {
                k.b[n2][n3] = (byte)(by - 6);
            }
        }
        if (this.d(n2, n3)) {
            this.a(1, 48, n);
        }
    }

    public final void bU() {
        boolean bl;
        int n;
        int n2;
        int n3 = this.bG;
        int n4 = this.bH;
        if (a[n3][n4 + 1] != 16) {
            n2 = 0;
            n = -1;
        } else {
            n2 = 1;
            n = 0;
        }
        int n5 = b[n3][n4 + n2];
        int n6 = b[n3][n4 + n2];
        int n7 = (n6 & 7) == 4 ? 4 : 2;
        boolean bl2 = bl = this.d(n3 - g[n7], n4 + n2) || this.d(n3 - g[n7], n4 + n);
        if (n5 <= 0 && bl && this.aT <= 12) {
            n5 = 36;
        } else if (n5 > 0) {
            if (n2 == 0) {
                n5 = (byte)(n5 - 1);
            }
            if ((n5 == 11 || n2 == 0 && n5 < 11) && bl) {
                this.a(1, 48, n6 & 7);
            }
            k.c[n3][n4] = 24;
        }
        if (this.i(n3, n4)) {
            this.C(10);
            k.a[n3][n4 + n] = -1;
            this.o(n3, n4 + n);
            k.a[n3][n4 + n2] = -1;
            this.o(n3, n4 + n2);
            return;
        }
        k.b[n3][n4 + n] = n6;
        k.b[n3][n4 + n2] = n6;
        if (n2 == 0) {
            k.b[n3][n4 + n] = n5;
            k.b[n3][n4 + n2] = n5;
        }
    }

    public final void bV() {
        int n;
        int n2;
        int n3 = b[this.bG][this.bH];
        int n4 = n2 = (n3 & 7) == 3 ? 1 : -1;
        if ((n3 & 8) == 0) {
            n = this.aL;
            boolean bl = false;
        } else {
            n = this.aN;
            boolean bl = false;
        }
        int n5 = this.bH + (n - 1) * n2;
        if (this.d(this.bG, n5)) {
            this.a(2, 48, (int)h[this.aU & 7]);
        }
        switch (a[this.bG][n5]) {
            case -1: 
            case 28: 
            case 32: {
                break;
            }
            default: {
                this.o(this.bG, n5);
                k.a[this.bG][n5] = -1;
                this.p(this.bG, n5);
                this.b(this.bG, n5);
            }
        }
        k.c[this.bG][this.bH] = 24;
    }

    public final void bW() {
        int n;
        int n2 = this.bG;
        int n3 = this.bH;
        int n4 = a[n2][n3] >> 8;
        int n5 = a[n2][n3] & 0xFF;
        if ((n4 & 0x100) == 0 && (n5 == 9 && this.aW > 0 || n5 == 8 && this.aX > 0) && this.aS == n3 && (this.aR == n2 - 1 || this.aR == n2 + 1) && (n = k.a[0].f) != 18 && n != 17 && this.aT <= 6) {
            this.j = 0;
            this.k = 0;
            if (this.aR == n2 - 1) {
                this.aU = this.aU & 0xFFFFFFF8 | 2;
                this.m(18);
            } else {
                this.aU = this.aU & 0xFFFFFFF8 | 4;
                this.m(17);
            }
            if (n5 == 9) {
                this.aC = 24;
                this.aD = 0;
                return;
            }
            this.aC = 25;
            this.aD = 0;
        }
    }

    public final void bX() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = a[n][n2] >> 8;
        int n4 = (n3 & 0xF0) >> 4;
        if (n4 != 0) {
            if (aP % 3 == 0 && n4 < 3) {
                n3 = n3 & 0xFFFFFF0F | n4 + 1 << 4;
                if (n4 == 2) {
                    int n5 = a[n][n2 - 1] & 0xFF;
                    if (n5 == 9 || n5 == 8) {
                        int n6 = a[n][n2 - 1] >> 8;
                        k.a[n][n2 - 1] = (n6 &= 0xFFFFFDFF) << 8 | n5;
                    }
                    this.a(n, n2 - 1, 1, 0, 0);
                    this.a(n, n2 - 1, -1, 0, 0);
                }
                k.c[n][n2] = 24;
            }
            k.a[n][n2] = n3 << 8 | 7;
        }
    }

    public final void bY() {
        int n = this.bG;
        int n2 = this.bH;
        int n3 = a[n][n2] >> 8;
        if (n3 < 6) {
            switch (n3) {
                case -1: {
                    if (Math.abs(this.aR - n) >= 4 || Math.abs(this.aS - n2) >= 4) break;
                    n3 = 3;
                    break;
                }
                case 0: 
                case 1: {
                    break;
                }
                case 2: {
                    switch (this.k) {
                        case 1: {
                            if (!this.d(n, n2 - 1)) break;
                            n3 = 3;
                            break;
                        }
                        case 2: {
                            if (!this.d(n + 1, n2)) break;
                            n3 = 3;
                            break;
                        }
                        case 3: {
                            if (!this.d(n, n2 + 1)) break;
                            n3 = 3;
                            break;
                        }
                        case 4: {
                            if (!this.d(n - 1, n2)) break;
                            n3 = 3;
                        }
                    }
                    break;
                }
                default: {
                    if ((aP & 1) != 0) break;
                    ++n3;
                }
            }
            k.c[n][n2] = 24;
            k.a[n][n2] = n3 << 8 | 3;
            return;
        }
        k.c[n][n2] = 0;
    }

    public final void y(int n) {
        int n2 = this.bG;
        int n3 = this.bH;
        int n4 = a[n2][n3] >> 8;
        k.a[n2][n3] = n4 << 8 | n;
        if (b[n2][n3] <= 0) {
            if (n4 == 0) {
                if (this.d(n2, n3) && this.aT <= 0) {
                    this.aU &= 0xFFFFF7FF;
                    k.a[n2][n3] = 0x100 | n;
                    if (Math.abs(this.l - System.currentTimeMillis()) >= 5000L) {
                        this.m(40);
                        return;
                    }
                    this.m(48);
                    return;
                }
            } else if ((aP >> 1 & 1) == 0 && a[n == 14 ? 8 : 22] != null && n4 < a[n == 14 ? 8 : 22].a(0) - 1) {
                k.a[n2][n3] = n4 + 1 << 8 | n;
                k.c[n2][n3] = 24;
            }
        }
    }

    public final boolean i(int n, int n2) {
        int n3 = n2 - 1;
        int n4 = n - 1;
        int n5 = n + 1;
        return b[n][n3] <= 6 && (this.j(n, n3) && ((b[n][n3] & 7) == 3 || a[n][n2] != 16 && a[n][n3] != 1) || a[n][n3] == 46 || a[n][n3] == 14 || a[n][n3] == 48) || b[n5][n2] <= 0 && a[n5][n2] == 14 && (b[n5][n2] & 8) != 0 && (b[n5][n2] & 7) != 3 || b[n4][n2] <= 0 && a[n4][n2] == 14 && (b[n4][n2] & 8) == 0 && (b[n4][n2] & 7) != 3;
    }

    public final boolean j(int n, int n2) {
        if (a[n][n2] >= 0) {
            switch (a[n][n2]) {
                case 0: 
                case 1: 
                case 8: 
                case 9: {
                    return true;
                }
            }
        }
        return false;
    }

    public final void p(int n, int n2) {
        int n3 = n - 1;
        int n4 = n + 1;
        int n5 = n2 - 1;
        int n6 = n2 + 1;
        k.c[n3][n5] = 48;
        k.c[n][n5] = 48;
        k.c[n4][n5] = 48;
        k.c[n3][n2] = 48;
        k.c[n][n2] = 48;
        k.c[n4][n2] = 48;
        k.c[n3][n6] = 48;
        k.c[n][n6] = 48;
        k.c[n4][n6] = 48;
    }

    public final void bZ() {
        this.h = i[10];
        this.cj = this.ch;
        this.ci = this.cg;
        this.U = this.P;
        this.cb = this.az;
        this.bZ = this.bb;
        this.ca = this.bd;
        this.bU = this.aR;
        this.bV = this.aS;
        this.bW = this.aW;
        this.bX = this.aX;
        this.bY = this.an;
        this.Y = this.X;
        this.cc = this.ab;
        this.cd = this.aa;
        cp = co;
        if (m != null) {
            System.arraycopy(m, 0, o, 0, m.length);
        }
        for (int i2 = 0; i2 < this.ax; ++i2) {
            System.arraycopy(b[i2], 0, c[i2], 0, this.ay);
            System.arraycopy(b[i2], 0, d[i2], 0, this.ay);
            System.arraycopy(a[i2], 0, e[i2], 0, this.ay);
            System.arraycopy(a[i2], 0, d[i2], 0, this.ay);
        }
        this.ce();
    }

    public final void ca() {
        int n;
        int n2;
        int n3;
        cE = -1;
        this.aE = -1;
        this.aD = -1;
        this.aC = -1;
        this.bi = 0;
        this.bj = 0;
        this.D = true;
        this.ck = this.bU * 24 - 88;
        this.cl = this.bV * 24 - 104;
        this.bn = 0;
        if (this.p) {
            this.bo = 15;
            this.p = false;
            k.d[37][7] = -1;
            k.d[39][5] = -1;
        } else if (this.q) {
            this.bo = 17;
            this.q = false;
            k.d[46][7] = -1;
            k.d[50][7] = -1;
        }
        this.s = false;
        this.am = 45;
        k.i[10] = this.h;
        this.P = this.U;
        this.ch = this.cj;
        this.cg = this.ci;
        this.az = this.cb;
        this.bd = this.ca;
        this.bb = this.bZ;
        a[0].a(2);
        this.aU = 2;
        this.bl = 0;
        this.aR = this.bU;
        this.aS = this.bV;
        this.aW = this.bW;
        this.aX = this.bX;
        this.X = this.Y;
        switch (this.i) {
            case 5: {
                this.F();
                break;
            }
            case 3: {
                this.af = 5;
                break;
            }
            case 4: {
                this.ad = 0;
                this.ag = 0;
                this.af = 3;
                this.j = false;
                break;
            }
            case 1: {
                this.aa = this.cd;
                this.ab = this.cc;
            }
        }
        co = cp;
        if (m != null) {
            System.arraycopy(o, 0, m, 0, m.length);
        }
        for (n3 = 0; n3 < this.ax; ++n3) {
            System.arraycopy(c[n3], 0, b[n3], 0, this.ay);
            System.arraycopy(d[n3], 0, b[n3], 0, this.ay);
            System.arraycopy(e[n3], 0, a[n3], 0, this.ay);
            System.arraycopy(d[n3], 0, a[n3], 0, this.ay);
        }
        n3 = this.ay - 1;
        for (n2 = 1; n2 < n3; ++n2) {
            n = this.ax - 1;
            for (int i2 = 1; i2 < n; ++i2) {
                byte by = a[i2][n2];
                int n4 = a[i2][n2] & 0xFF;
                if ((by <= -1 || by >= 80) && (n4 <= -1 || n4 >= 80)) continue;
                this.p(i2, n2);
            }
        }
        if (a[2] != null) {
            a[2].a(0);
            k.a[18][63] = -1;
        }
        this.an = this.bY;
        this.v();
        if (this.k) {
            this.cf();
        }
        if (e != null) {
            for (n2 = 0; n2 < this.ay; ++n2) {
                for (n = 0; n < this.ax; ++n) {
                    if (a[n][n2] != 48) continue;
                    this.bG = n;
                    this.bH = n2;
                    if ((b[n][n2] & 8) == 0) {
                        this.d((byte)48);
                        continue;
                    }
                    this.bA();
                }
            }
        }
    }

    public final void a(short s, short s2, byte by, int n) {
        k.a[s][s2] = by;
        k.b[s][s2] = n;
    }

    public static final boolean b(int n, int n2, int n3, int n4) {
        return Math.abs(n - n3) < 24 && Math.abs(n2 - n4) < 24;
    }

    public final boolean a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        do = 0;
        dn = 0;
        dq = 100;
        dp = 100;
        if (Math.abs(n - n5) > 1 || Math.abs(n2 - n6) > 1) {
            return false;
        }
        dn = n * 24 + g[n3] * n4;
        do = n2 * 24 + g[8 + n3] * n4;
        dp = n5 * 24 + g[n7] * n8;
        dq = n6 * 24 + g[8 + n7] * n8;
        return k.b(dn, do, dp, dq);
    }

    public final void cb() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6 = this.bG;
        int n7 = this.bH;
        int n8 = b[n6][n7];
        int n9 = b[n6][n7];
        byte by = a[n6][n7];
        boolean bl = false;
        boolean bl2 = e != null && e[n6][n7] != 0;
        int n10 = n9 & 7;
        if (bl2 && e[n6][n7] != 3) {
            n5 = -1;
            n4 = 1;
            n3 = n7 - 1;
        } else {
            n5 = 1;
            n4 = 3;
            n3 = n7 + 1;
        }
        byte by2 = (this.aU & 0x1000) == 0 ? this.k : (byte)0;
        boolean bl3 = this.a(n6, n7, n10, n8, this.aR, this.aS, (int)by2, this.aT);
        if (by == 1 && bl3) {
            this.q(n6, n7);
            return;
        }
        boolean bl4 = (a[n6][n7] & 0xFF) == 35;
        byte by3 = a[n6][n3];
        if (by3 == 9 && n8 <= 0) {
            n2 = (byte)(a[n6][n3] & 0xFF);
            n = (b[n6][n3] & 0xFC00000) >> 22;
            if (n != 34) {
                if (n == 33) {
                    if (n2 == -1) {
                        k.a[n6][n3] = 32;
                    }
                    this.aR = n6;
                    this.aS = n3;
                    k.a[n6][n3] = -1;
                    this.aT = 0;
                    this.aV = 0;
                    this.a(2, 48, 0);
                } else if (a[n6][n3] == 19 || a[n6][n3] == 43 || a[n6][n3] == 45 || a[n6][n3] == 46 || a[n6][n3] == 49 || a[n6][n3] == 11) {
                    k.a[n6][n3] = -1;
                    this.o(n6, n3);
                }
            }
        }
        if (n8 <= 0 && !bl4) {
            if (n10 == n4 && this.d(n6, n3) && this.f(n6, n3)) {
                if ((by == 0 || by == 9) && n5 > 0) {
                    this.a(2, 48, 0);
                } else if (by == 1) {
                    k.b[n6][n3] = n9 & 0xFFFFFFF8 | 3;
                    k.b[n6][n3] = 18;
                    k.a[n6][n3] = 1;
                    k.a[n6][n7] = -1;
                    this.b(n6, n7);
                } else if (by == 8) {
                    n9 &= 0xFFC1FFFF;
                }
                k.b[n6][n7] = n9 & 0xFFFFFFF8 | 0;
            } else if (!(!this.f(n6, n3) && a[n6][n3] != 21 || this.d(n6, n7) && this.aV <= 0 || (this.d(n6, n3) || k.b(dn, do, dp, dq - 1)) && this.aV <= 0 && this.aY == 0 && (by == 0 || n10 != n4))) {
                if (n5 > 0 || e != null && e[n6][n3] != 0) {
                    n9 += 131072;
                    n9 = n9 & 0xFFFFFFF8 | n4;
                    k.b[n6][n3] = n9 | Integer.MIN_VALUE;
                    k.b[n6][n3] = 18;
                    k.a[n6][n3] = by;
                    k.a[n6][n7] = -1;
                    this.p(n6, n7);
                    k.c[n6][n7 + 2 * n5] = 24;
                    this.b(n6, n7);
                } else {
                    k.b[n6][n7] = n9 = n9 & 0xFFC1FFF8 | 0;
                    k.b[n6][n3] = 0;
                }
            } else if (this.j(n6, n3)) {
                if (n5 < 0 && (e == null || e[n6][n3] == 0) && a[n6][n7 + 1] < 0) {
                    k.b[n6][n7 + 1] = n9 & 0xFFFFFFF8 | 3;
                    k.b[n6][n7 + 1] = b[n6][n7 + 1] | Integer.MIN_VALUE;
                    k.a[n6][n7 + 1] = by;
                    k.b[n6][n7 + 1] = 18;
                    k.a[n6][n7] = -1;
                } else if (b[n6][n3] <= 0) {
                    n2 = (n9 & 0x3E0000) >> 17;
                    if (n2 >= 2) {
                        if (by == 8) {
                            k.a[n6][n7] = 54;
                            k.b[n6][n7] = 0;
                            this.p(n6, n7);
                            return;
                        }
                        if (a[n6][n3] == 8) {
                            k.a[n6][n3] = 54;
                            k.b[n6][n3] = 0;
                            this.p(n6, n3);
                            return;
                        }
                    }
                    n9 &= 0xFFC1FFFF;
                    if (this.f(n6 - 1, n7) && this.f(n6 - 1, n3) && !this.d(n6 - 1, n7)) {
                        k.b[n6][n7] = (byte)(((n9 & 0x7000) >> 12) + 1);
                        k.c[n6][n7] = 24;
                        n9 = n9 & 0xFFFFFFF8 | 4;
                        n9 = n9 & 0xFFFFF3FF | 0x800;
                        n9 |= 0x200;
                    } else if (this.f(n6 + 1, n7) && this.f(n6 + 1, n3) && !this.d(n6 + 1, n7)) {
                        k.b[n6][n7] = (byte)(((n9 & 0x7000) >> 12) + 1);
                        k.c[n6][n7] = 24;
                        n9 = n9 & 0xFFFFFFF8 | 2;
                        n9 = n9 & 0xFFFFF3FF | 0x400;
                        n9 |= 0x200;
                    }
                    k.b[n6][n7] = n9;
                }
            } else if (by == 8) {
                n2 = (n9 & 0x3E0000) >> 17;
                if (n2 >= 2) {
                    k.a[n6][n7] = 54;
                    k.b[n6][n7] = 0;
                    this.p(n6, n7);
                    return;
                }
                n9 &= 0xFFC1FFFF;
            } else {
                n9 = n9 & 0xFFFFF3FF | 0;
                n9 &= 0xFFC1FFFF;
                k.b[n6][n7] = n9 &= 0xFFFFFFF8;
            }
        } else if (!bl4) {
            if ((n9 & 0x200) == 0) {
                if (n10 != 3 || (a[n6][n7] & 0xFF) != 6 || n8 > 12) {
                    n8 = (byte)(n8 - 6);
                } else {
                    n8 = (byte)(n8 - (aP & 1));
                    k.c[n6][n7] = 24;
                }
                if (n8 == 0 || n8 == 12) {
                    switch (n9 & 0xC00) {
                        case 2048: {
                            n9 = n9 & 0xFFFFFFC7 | n9 - 8 & 0x38;
                            break;
                        }
                        case 1024: {
                            n9 = n9 & 0xFFFFFFC7 | n9 + 8 & 0x38;
                        }
                    }
                    if (n8 == 0) {
                        if ((a[n6][n7] & 0xFF) == 6) {
                            n9 &= 0xFFFFFE3F;
                        }
                        if (n10 == n4) {
                            if (!(by != 0 && by != 9 || n5 <= 0 || this.f(n6, n7 + 1))) {
                                this.C(10);
                                this.bl = 10;
                                if (by == 9 && this.aV > 0 && this.d(n6, n7)) {
                                    this.a(1, 0, 0);
                                    this.v();
                                }
                                boolean bl5 = this.j(n6, n7 + 1);
                                n2 = bl5 ? 1 : 0;
                                if (!bl5) {
                                    n9 = n9 & 0xFFFFFE3F | 0x40;
                                }
                            }
                            k.c[n6][n7] = 30;
                            if (!this.d(n6, n3)) {
                                n9 = n9 & 0xFFFFFFF8 | 0;
                            }
                        }
                    }
                }
                k.b[n6][n7] = n8;
                k.b[n6][n7] = n9;
            } else {
                n2 = 0;
                n = 0;
                if (n10 == 4) {
                    n2 = -1;
                } else if (n10 == 2) {
                    n2 = 1;
                }
                if (this.f(n6, n3) && !this.d(n6, n3)) {
                    if ((n8 = (int)(n8 - 6)) <= 0) {
                        n8 = 0;
                        n9 &= 0xFFFFFDFF;
                        n9 = n9 & 0xFFFFFFF8 | 0;
                    }
                    k.b[n6][n7] = n8;
                    k.b[n6][n7] = n9;
                    k.c[n6][n7] = 24;
                } else if (this.f(n6 + n2, n7) && !this.d(n6 + n2, n7) && this.f(n6 + n2, n3) && !this.d(n6 + n2, n3) && (b[n6][n3] & 0x200) == 0) {
                    if (n8 < 6) {
                        if ((aP & 3) == 0) {
                            n8 = (byte)(n8 + 1);
                        }
                    } else {
                        n8 = (byte)(n8 + 1);
                    }
                    if (n8 >= 12) {
                        n9 &= 0xFFFFFDFF;
                        if (n2 != 0) {
                            n8 = 6;
                            k.a[n6][n7] = -1;
                            if (this.f(n6 + n2, n3)) {
                                n8 = 12;
                                n9 = n9 & 0xFFFFFFF8 | n4;
                                n = n5;
                            }
                        } else {
                            n9 = n9 & 0xFFFFFFF8 | 0;
                            n8 = 0;
                        }
                        k.b[n6 + n2][n7 + n] = n9 | Integer.MIN_VALUE;
                        k.b[n6 + n2][n7 + n] = n8;
                        k.a[n6 + n2][n7 + n] = by;
                        this.p(n6, n7);
                        k.c[n6][n7 + 2 * n5] = 24;
                    } else {
                        k.b[n6][n7] = n8;
                        k.b[n6][n7] = n9;
                        k.c[n6][n7] = 24;
                    }
                } else {
                    if ((n8 = (int)(n8 - 6)) <= 0) {
                        n8 = 0;
                        n9 &= 0xFFFFFDFF;
                        n9 = n9 & 0xFFFFFFF8 | 0;
                    }
                    k.b[n6][n7] = n8;
                    k.b[n6][n7] = n9;
                    k.c[n6][n7] = 24;
                    this.c(n6, n7);
                }
            }
        }
        n2 = n9 & 0x20000000;
        n = b[n6][n7];
        int n11 = n9 & 0x40000000;
        int n12 = 0;
        if (n2 == 0 && n != 0 || n11 == 0 && bl2) {
            this.b(n6, n7);
        }
        if (n2 != 0 && n == 0 || n11 != 0 && !bl2) {
            this.c(n6, n7);
        }
        n12 = (n9 & 0x200) != 0 ? 1 : (n != 0 || n2 != 0 ? 2 : (bl2 ? 3 : (a[n6][n7] > -1 && a[n6][n7] < 38 ? 4 : ((this.f(n6 - 1, n7) || this.f(n6 + 1, n7)) && this.j(n6, n7 + 1) && (b[n6][n7 + 1] & 7) == 0 && n6 != this.bi && n7 != this.bj ? 6 : 0))));
        n9 = n9 & 0xDFFFFFFF | (n != 0 ? 0x20000000 : 0);
        n9 = n9 & 0xBFFFFFFF | (bl2 ? 0x40000000 : 0);
        k.b[n6][n7] = n9 = n9 & Integer.MAX_VALUE | (n12 != 0 ? Integer.MIN_VALUE : 0);
        int n13 = ((b[n6][n7] & 0x1C0) >> 6) - 1;
        if (n13 >= 0 && n13 < 5) {
            k.b[n6][n7] = b[n6][n7] & 0xFFFFFE3F | b[n6][n7] + 64 & 0x1C0;
        }
    }

    public final void q(int n, int n2) {
        this.e(n, n2, 3);
        ++this.bb;
        k.a[n][n2] = -1;
        --this.P;
        this.bk = 0;
        if (this.P == 0) {
            k.a[this.Q][this.R] = -1;
        }
        if (a[n][n2 - 1] == -1) {
            this.b(n, n2 - 1);
        }
        this.b(n, n2);
        this.v();
    }

    public static final b a(String string, int n, int n2, int n3) {
        b b2 = null;
        try {
            b2 = new b();
            byte[] byArray = k.a(string, n);
            b2.a(byArray, 0);
            for (int i2 = n2; i2 <= n3; ++i2) {
                b2.a(i2, 0, -1, -1);
            }
            b2.m = n2;
            b2.g = null;
            System.gc();
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
        }
        return b2;
    }

    public static final b a(String string, int n) {
        return k.a(string, n, 0);
    }

    public static final b a(String string, int n, int n2) {
        return k.a(string, n, n2, n2);
    }

    public static final f[] a(String string, int n) {
        return k.a(string, n, 0);
    }

    public static final f[] a(String string, int n, int n2) {
        b b2 = null;
        try {
            b2 = new b();
            byte[] byArray = k.a(string, n);
            b2.a(byArray, 0);
            b2.a(n2, 0, -1, -1);
            k.a(b2, false);
            System.gc();
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
        }
        return b2.a[n2];
    }

    public static final byte[] a(String string, int n) {
        byte[] byArray = null;
        a a2 = k.a(string);
        try {
            int n2 = a2.a() << 3;
            byArray = new byte[n2];
            a2.a(byArray);
            int n3 = k.b(byArray, n << 3);
            int n4 = k.b(byArray, (n << 3) + 4);
            a2.a(n3);
            byArray = new byte[n4];
            a2.a(byArray);
            a2.a();
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
        }
        return byArray;
    }

    public final void cc() {
        if (b.h == null) {
            a a2 = k.a("/mc");
            b.h = new byte[256];
            try {
                a2.a(b.h);
                a2.a();
                return;
            }
            catch (Exception exception) {
                Exception exception2 = exception;
                exception.toString();
            }
        }
    }

    public static final int a(b b2, String string, int n) {
        int n2;
        if (n != -1 && (n2 = string.indexOf(10)) != -1) {
            string = string.substring(0, n2);
        }
        if ((n2 = string.indexOf(125)) != -1) {
            string = string.substring(0, n2);
        }
        b2.a(string);
        return b.n;
    }

    public final int a(b b2) {
        return b2.p + (b2.a[1] & 0xFF);
    }

    public static final void z(int n) {
        g.c = n;
    }

    public final boolean a(Graphics graphics) {
        ++g.b;
        switch (g.c) {
            case 0: {
                this.u();
                this.a = new g();
                this.cd();
                this.a.f();
                k.z(1);
                this.aj = false;
                break;
            }
            case 1: {
                this.a.a();
                U = false;
                break;
            }
            case 2: {
                this.a.b();
                this.u();
                l = (byte)9;
                this.bt = 8;
                this.bu = 0;
                break;
            }
            case 3: {
                this.a.b(graphics);
                break;
            }
            case 4: {
                k.z(0);
                this.a = null;
                System.gc();
                return false;
            }
        }
        return true;
    }

    public final void cd() {
        if ((j[0] & 1) == 0) {
            this.aj = true;
            j[0] = (byte)(j[0] | 1);
            this.C();
        }
    }

    public final int a(a a2) throws IOException {
        return a2.a() & 0xFF | (a2.a() & 0xFF) << 8;
    }

    public final int e(int n) {
        if (n < 0) {
            n = Math.abs(n);
        }
        switch (n) {
            case 1: {
                return 1;
            }
            case 2: {
                return 2;
            }
            case 3: {
                return 4;
            }
            case 4: {
                return 8;
            }
            case 5: {
                return 16;
            }
            case 7: {
                return 32;
            }
            case 6: {
                return 64;
            }
            case 23: {
                return 128;
            }
            case 42: {
                return 256;
            }
            case 35: {
                return 512;
            }
            case 48: {
                return 1024;
            }
            case 49: {
                return 2048;
            }
            case 50: {
                return 4096;
            }
            case 51: {
                return 8192;
            }
            case 52: {
                return 16384;
            }
            case 53: {
                return 32768;
            }
            case 54: {
                return 65536;
            }
            case 55: {
                return 131072;
            }
            case 56: {
                return 262144;
            }
            case 57: {
                return 524288;
            }
        }
        return 0;
    }

    public final void ce() {
        if (!this.k) {
            return;
        }
        if (f == null) {
            f = new int[this.ax][this.ay];
        }
        for (int i2 = 0; i2 < this.ax; ++i2) {
            System.arraycopy(e[i2], 0, f[i2], 0, this.ay);
        }
        if (c == null) {
            c = new long[15];
        }
        System.arraycopy(a, 0, c, 0, a.length);
        if (d == null) {
            d = new long[15];
        }
        System.arraycopy(b, 0, d, 0, b.length);
        this.w = this.v;
        this.dB = this.dr;
        this.dC = this.ds;
        this.dD = this.dt;
        this.x = this.t;
        this.dE = this.dw;
        this.dF = this.dx;
        this.dG = this.dy;
        this.y = this.u;
        this.dH = this.dz;
        this.dI = this.dA;
        al = this.ak;
        this.dJ = this.du;
        this.dK = this.dv;
    }

    public final void cf() {
        this.ak = al;
        this.du = this.dJ;
        this.dv = this.dK;
        for (int i2 = 0; i2 < this.ax; ++i2) {
            System.arraycopy(f[i2], 0, e[i2], 0, this.ay);
        }
        System.arraycopy(c, 0, a, 0, a.length);
        System.arraycopy(d, 0, b, 0, b.length);
        this.v = this.w;
        this.dr = this.dB;
        this.ds = this.dC;
        this.dt = this.dD;
        this.t = this.x;
        this.dw = this.dE;
        this.dx = this.dF;
        this.dy = this.dG;
        this.u = this.y;
        this.dz = this.dH;
        this.dA = this.dI;
    }

    public final void cg() {
        if (this.k) {
            this.ch();
            e = new int[this.ax][this.ay];
            this.bw();
        }
    }

    public final void ch() {
        if (this.k) {
            a = new long[15];
            c = new long[15];
            b = new long[15];
            d = new long[15];
            this.v = (byte)3;
            this.ak = true;
            this.dr = -1;
            this.ds = 0;
            this.dt = 0;
            this.t = 0;
            this.dw = 0;
            this.dx = 0;
            this.dy = 0;
            this.u = 0;
            this.dz = 0;
            this.dA = -1;
            this.du = 0;
            this.dv = 0;
        }
    }

    public final byte a(byte by, byte by2, byte by3, byte by4) {
        byte by5;
        for (by5 = 0; by5 < 15 && this.a(by5, (byte)0, (byte)4) != 0; by5 = (byte)(by5 + 1)) {
        }
        if (by5 < 15) {
            this.a(by5, (byte)1, (byte)0, (byte)4);
            this.a(by5, by4, (byte)4, (byte)2);
            this.a(by5, by, (byte)6, (byte)7);
            this.a(by5, by, (byte)27, (byte)7);
            this.a(by5, by2, (byte)13, (byte)7);
            this.a(by5, by3, (byte)20, (byte)7);
            return by5;
        }
        return -1;
    }

    public final int a(int n, byte by, byte by2, byte by3) {
        n >>>= by * 9 + by2;
        return n &= ~(-1 << by3);
    }

    public final void a(int n, int n2, byte by, byte n3, byte by2, byte by3) {
        int n4 = e[n][n2];
        int n5 = this.a(n4, by, by2, by3);
        byte by4 = (byte)(by * 9 + by2);
        n4 ^= (n5 <<= by4);
        int n6 = n3;
        k.e[n][n2] = n4 |= (n6 <<= by4);
        k.c[n][n2] = 24;
        k.c[n][n2 + 1] = 24;
    }

    public final int a(int n, byte by, byte by2) {
        return (int)(a[n - 1] >>> by & (-1L << by2 ^ 0xFFFFFFFFFFFFFFFFL));
    }

    public final void a(int n, byte by, byte by2, byte by3) {
        long l = this.a(n, by2, by3);
        long l2 = a[--n];
        l2 ^= (l <<= by2);
        long l3 = by;
        k.a[n] = l2 |= (l3 <<= by2);
    }

    public final int a(byte by, byte by2, byte by3) {
        long l = b[by];
        l >>>= by2;
        return (int)(l &= -1L << by3 ^ 0xFFFFFFFFFFFFFFFFL);
    }

    public final void a(byte by, byte n, byte by2, byte by3) {
        long l = this.a(by, by2, by3);
        long l2 = b[by];
        l2 ^= (l <<= by2);
        int n2 = n;
        k.b[by] = l2 |= (long)(n2 <<= by2);
    }

    public final byte b(int n, int n2) {
        for (byte by = 0; by < 15; by = (byte)(by + 1)) {
            if (n != this.a(by, (byte)13, (byte)7) || n2 != this.a(by, (byte)20, (byte)7)) continue;
            return by;
        }
        return -1;
    }

    public final byte a(int n, int n2, byte by) {
        byte by2 = this.b(n, n2);
        if (by2 >= 0) {
            this.a(by2, by, (byte)0, (byte)4);
            switch (by) {
                case 3: {
                    by2 = 39;
                    break;
                }
                case 1: {
                    by2 = 38;
                    break;
                }
                case 2: {
                    by2 = 39;
                }
            }
            return (byte)by2;
        }
        return -1;
    }

    public final void ci() {
        if (!this.k) {
            return;
        }
        if (this.dr >= 0 && this.dA >= 0) {
            ++this.dr;
            this.ck();
        }
        switch (this.v) {
            case 2: {
                block11: for (byte by = 1; by <= 15; by = (byte)(by + 1)) {
                    switch (this.a((int)by, (byte)28, (byte)3)) {
                        case 3: {
                            this.f(by);
                            continue block11;
                        }
                        case 2: {
                            if (this.dA < 0) continue block11;
                            ++this.dA;
                            this.g(by);
                            continue block11;
                        }
                        case 1: 
                        case 6: 
                        case 7: {
                            this.h(by);
                        }
                    }
                }
                break;
            }
            case 1: {
                this.v = (byte)2;
                return;
            }
            case 4: {
                this.cj();
                this.v = (byte)2;
                return;
            }
            case 5: {
                this.t(this.dw, this.dx);
            }
        }
    }

    public final void f(byte by) {
        k.a[by - 1] = 0L;
    }

    public final void cj() {
        for (byte by = 0; by < 15; by = (byte)(by + 1)) {
            if (this.a(by, (byte)0, (byte)4) != 3) continue;
            int n = this.a(by, (byte)13, (byte)7);
            int n2 = this.a(by, (byte)20, (byte)7);
            int n3 = this.a(by, (byte)4, (byte)2);
            k.b[by] = 0L;
            byte by2 = 0;
            byte by3 = 0;
            switch (n3) {
                case 0: {
                    ++n2;
                    by2 = 0;
                    by3 = 0;
                    break;
                }
                case 1: {
                    ++n;
                    by2 = 1;
                    by3 = 2;
                    break;
                }
                case 2: {
                    --n;
                    by2 = -1;
                    by3 = 2;
                }
            }
            this.a(n, n2, (byte)7, by2, by3, this.b(n, n2));
        }
    }

    public final void ck() {
        int n = this.a((int)this.u, (byte)20, (byte)6);
        int n2 = this.a((int)this.u, (byte)47, (byte)2);
        switch (n2) {
            case 1: {
                int n3;
                if (n == this.dz) {
                    this.dr = -1;
                    this.dA = -1;
                    this.f(this.u);
                    this.v = (byte)4;
                    return;
                }
                byte by = (byte)this.a((int)this.u, (byte)49, (byte)5);
                if (this.dr == 0 || this.dr % by != 0) break;
                this.dr = 0;
                byte by2 = (byte)this.a((int)this.u, (byte)26, (byte)2);
                if (by2 < 0) break;
                for (byte by3 = 0; by3 < by; by3 = (byte)(by3 + 1)) {
                    this.c(n3 - by3, n, by2);
                    byte by4 = by2;
                    int n4 = n;
                    by4 = (byte)(by4 + 1);
                    if (by4 > 2) {
                        by4 = 0;
                        ++n4;
                    }
                    int n5 = this.a(e[n3 - by3][n4], by4, (byte)3, (byte)4);
                    if (n4 != this.dz || by2 != 2) {
                        if (n5 == 12 || n5 == 9) continue;
                        this.a(n3 - by3, n4, by4, (byte)7, (byte)3, (byte)4);
                        continue;
                    }
                    if (n5 == 0 || n5 == 3) continue;
                    this.a(n3 - by3, n4, by4, (byte)7, (byte)3, (byte)4);
                }
                if (by2 == 2) {
                    this.a((int)this.u, (byte)0, (byte)47, (byte)2);
                    this.a((int)this.u, (byte)0, (byte)26, (byte)2);
                    this.a((int)this.u, (byte)(++n), (byte)20, (byte)6);
                    return;
                }
                by2 = (byte)(by2 + 1);
                this.a((int)this.u, by2, (byte)26, (byte)2);
                return;
            }
            case 0: {
                int n3;
                this.a((int)this.u, (byte)1, (byte)47, (byte)2);
                int n6 = this.a((int)this.u, (byte)49, (byte)5);
                byte by = (byte)this.a((int)this.u, (byte)45, (byte)2);
                int n7 = 0;
                if (by != 0) {
                    if (by == 2) {
                        for (n3 = this.a((int)this.u, 14, 6); n3 >= this.dw && (byte)(a[n3 + 1][n] - 80) < 0 && a[n3 + 1][n] != 10 && a[n3 + 1][n] != 37 && a[n3 + 1][n] != 34 && a[n3 + 1][n] != 35; ++n3) {
                        }
                    } else {
                        while (n3 <= this.dw && (byte)(a[n3 + 1][n] - 80) < 0 && a[n3 + 1][n] != 10 && a[n3 + 1][n] != 37 && a[n3 + 1][n] != 34 && a[n3 + 1][n] != 35) {
                            ++n3;
                        }
                    }
                } else if ((byte)(a[n3 + 1][n] - 80) < 0 && a[n3 + 1][n] != 10 && a[n3 + 1][n] != 37 && a[n3 + 1][n] != 34 && a[n3 + 1][n] != 35) {
                    while ((byte)(a[n3 + 1][n] - 80) < 0 && a[n3 + 1][n] != 10 && a[n3 + 1][n] != 37 && a[n3 + 1][n] != 34 && a[n3 + 1][n] != 35) {
                        ++n3;
                    }
                } else {
                    while (n7 < n6) {
                        ++n7;
                        if ((byte)(a[n3][n] - 80) < 0 && a[n3][n] != 10 && a[n3][n] != 37 && a[n3][n] != 34 && a[n3][n] != 35) {
                            n7 = n6;
                            continue;
                        }
                        --n3;
                    }
                }
                if (this.dy != 2 && n3 <= this.dw) {
                    while ((byte)(a[n3 + 1][n] - 80) < 0 && a[n3 + 1][n] != 10 && a[n3 + 1][n] != 37 && a[n3 + 1][n] != 34 && a[n3 + 1][n] != 35) {
                        ++n3;
                    }
                }
                this.a((int)this.u, (byte)n3, (byte)14, (byte)6);
                byte by5 = 1;
                while ((byte)(a[n3 - by5][n] - 80) < 0 && a[n3 - by5][n] != 10 && a[n3 - by5][n] != 37 && a[n3 - by5][n] != 34 && a[n3 - by5][n] != 35) {
                    by5 = (byte)(by5 + 1);
                }
                this.a((int)this.u, by5, (byte)49, (byte)5);
            }
        }
    }

    public final void g(byte by) {
        int n = this.a((int)by, (byte)14, (byte)6);
        int n2 = this.a((int)by, (byte)20, (byte)6);
        int n3 = this.a((int)by, (byte)0, (byte)7);
        int n4 = this.a((int)by, (byte)7, (byte)7);
        int n5 = this.a((int)by, (byte)47, (byte)2);
        byte by2 = (byte)this.a((int)by, (byte)54, (byte)3);
        byte by3 = (byte)this.a(by2, (byte)6, (byte)7);
        switch (n5) {
            case 1: {
                byte by4 = (byte)this.a((int)by, (byte)49, (byte)5);
                if (this.dA == 0 || this.dA % by4 != 0) break;
                this.dA = 0;
                byte by5 = (byte)this.a((int)by, (byte)26, (byte)2);
                byte by6 = (byte)this.a((int)by, (byte)57, (byte)1);
                if (by5 < 0) break;
                if (by6 != 1) {
                    byte by7;
                    for (by7 = 0; by7 < by4; by7 = (byte)(by7 + 1)) {
                        this.a(n - by7, n2, by5, (byte)7, (byte)3, (byte)4);
                        this.a((int)by, by5, (byte)43, (byte)2);
                        this.a(n - by7, n2, by5, by, (byte)0, (byte)3);
                    }
                    if (this.ds > 0) {
                        by7 = by5;
                        int n6 = n2;
                        if ((by7 = (byte)(by7 + 1)) > 2) {
                            by7 = 0;
                            ++n6;
                        }
                        for (byte by8 = 0; by8 < by4; by8 = (byte)(by8 + 1)) {
                            if ((byte)(a[n - by8][n6] - 80) >= 0 || a[n - by8][n6] == 10 || a[n - by8][n6] == 37 || a[n - by8][n6] == 34 || a[n - by8][n6] == 35) continue;
                            this.a(n - by8, n6, by7, (byte)8, (byte)3, (byte)4);
                        }
                    }
                    ++this.ds;
                }
                if (by6 == 1 || (n4 >= n3 || by3 == 0) && by5 == this.t) {
                    if (by6 == 1) {
                        this.a((int)by, (byte)0, (byte)57, (byte)1);
                    }
                    this.a((int)by, (byte)3, (byte)28, (byte)3);
                    if (by3 == 0) {
                        this.a(by2, (byte)3, (byte)0, (byte)4);
                        this.a((int)by, (byte)5, (byte)28, (byte)3);
                        if (this.dr == -1) {
                            this.dA = -1;
                            this.v = (byte)4;
                        }
                        return;
                    }
                }
                if (by5 == 0) {
                    this.a((int)by, (byte)0, (byte)47, (byte)2);
                    this.a((int)by, (byte)2, (byte)26, (byte)2);
                    return;
                }
                by5 = (byte)(by5 - 1);
                this.a((int)by, by5, (byte)26, (byte)2);
                return;
            }
            case 0: {
                byte by9;
                boolean bl;
                int n7;
                this.a((int)by, (byte)1, (byte)47, (byte)2);
                this.a((int)by, (byte)(--n2), (byte)20, (byte)6);
                boolean bl2 = false;
                if ((byte)(a[n][n2] - 80) >= 0 || a[n][n2] == 10 || a[n][n2] == 37 || a[n][n2] == 34 || a[n][n2] == 35) {
                    while ((byte)(a[n][n2] - 80) >= 0 || a[n][n2] == 10 || a[n][n2] == 37 || a[n][n2] == 34 || a[n][n2] == 35) {
                        n += -1;
                    }
                } else {
                    while ((byte)(a[n + 1][n2] - 80) < 0 && a[n + 1][n2] != 10 && a[n + 1][n2] != 37 && a[n + 1][n2] != 34 && a[n + 1][n2] != 35) {
                        ++n;
                    }
                }
                this.a((int)by, (byte)n, (byte)14, (byte)6);
                byte by10 = 1;
                while ((byte)(a[n - by10][n2] - 80) < 0 && a[n - by10][n2] != 10 && a[n - by10][n2] != 37 && a[n - by10][n2] != 34 && a[n - by10][n2] != 35) {
                    by10 = (byte)(by10 + 1);
                }
                this.a((int)by, by10, (byte)49, (byte)5);
                int n8 = by3 - by10;
                byte by11 = 0;
                this.t = 0;
                if (n8 < 0) {
                    n7 = -n8;
                    n7 *= 3;
                    byte by12 = 0;
                    int n9 = by10 + n8;
                    if (n9 * 3 - by10 != 0 && (n9 *= 3) <= by10 * 3 / 2) {
                        by12 = 1;
                    }
                    this.t = (byte)(n7 /= by10);
                    this.t = (byte)(this.t + by12);
                    if (this.t > 2) {
                        this.a((int)by, (byte)1, (byte)57, (byte)1);
                    }
                    by11 = (byte)Math.abs(n8);
                    bl = false;
                }
                if ((n4 += by10 - by11) > n3) {
                    n7 = n3 - n4;
                    n4 += n7;
                    by9 = (byte)(bl - n7);
                }
                this.a((int)by, (byte)n4, (byte)7, (byte)7);
                this.a(by2, by9, (byte)6, (byte)7);
            }
        }
    }

    public final byte a(byte by, int n, int n2, byte by2, byte by3, byte by4, boolean bl) {
        byte by5 = 0;
        if ((byte)(a[n + by4][n2] - 80) >= 0 || a[n + by4][n2] == 10 || a[n + by4][n2] == 37 || a[n + by4][n2] == 34 || a[n + by4][n2] == 35) {
            by5 = -2;
        } else {
            by5 = by4;
            if (by2 != by4) {
                this.a((int)by, by4 < 0 ? (byte)2 : (byte)by4, (byte)45, (byte)2);
            }
            this.a((int)by, (byte)(n += by4), (byte)31, (byte)6);
            this.a(n, n2, by3, by, (byte)0, (byte)3);
            if (bl) {
                this.c(n, n2, by3);
            } else {
                byte by6 = 0;
                byte by7 = 0;
                int n3 = this.a((int)by, (byte)28, (byte)3);
                if (by4 > 0) {
                    by6 = n3 == 6 && this.dw == n && this.dx == n2 ? (byte)11 : 4;
                    by7 = 9;
                } else {
                    by6 = n3 == 6 && this.dw == n && this.dx == n2 ? (byte)14 : 5;
                    by7 = 12;
                }
                if ((byte)(a[n][n2 + 1] - 80) >= 0 || a[n + by4][n2] == 10 || a[n + by4][n2] == 37 || a[n + by4][n2] == 34 || a[n + by4][n2] == 35) {
                    this.a(n, n2, by3, by6, (byte)3, (byte)4);
                } else {
                    this.a(n, n2, by3, by7, (byte)3, (byte)4);
                }
            }
        }
        return by5;
    }

    public final boolean d(int n) {
        return n != -1 && this.a(n, (byte)6, (byte)1) == 1;
    }

    public final byte a(int n, byte by, byte by2) {
        return (byte)(n >>> by & ~(0xFFFFFF << by2));
    }

    public final boolean a(int n, int n2, int n3) {
        boolean bl = true;
        boolean bl2 = true;
        while (bl2) {
            bl2 = true;
            n -= n3;
            if (n3 == 0) {
                if ((byte)(a[n - 1][n2] - 80) < 0 && a[n - 1][n2] != 10 && a[n - 1][n2] != 37 && a[n - 1][n2] != 34 && (a[n - 1][n2] != 35 || (byte)(a[n + 1][n2] - 80) < 0) && a[n + 1][n2] != 10 && a[n + 1][n2] != 37 && a[n + 1][n2] != 34 && a[n + 1][n2] != 35) continue;
                bl = true;
                bl2 = false;
                continue;
            }
            if ((byte)(a[n][n2 + 1] - 80) < 0 && a[n][n2 + 1] != 10 && a[n][n2 + 1] != 37 && a[n][n2 + 1] != 34 && a[n][n2 + 1] != 35) {
                bl2 = false;
            }
            if ((byte)(a[n][n2] - 80) >= 0 || a[n][n2] == 10 || a[n][n2] == 37 || a[n][n2] == 34 || a[n][n2] == 35) {
                bl = bl2;
                bl2 = false;
                continue;
            }
            if (bl2) continue;
            return bl2;
        }
        return bl;
    }

    public final void h(byte by) {
        byte by2;
        int n = this.a((int)by, (byte)31, (byte)6);
        int n2 = this.a((int)by, (byte)37, (byte)6);
        byte by3 = (byte)this.a((int)by, (byte)43, (byte)2);
        byte by4 = (byte)this.a(e[n][n2], by3, (byte)7, (byte)2);
        byte by5 = (byte)this.a((int)by, (byte)45, (byte)2);
        byte by6 = (byte)this.a((int)by, (byte)28, (byte)3);
        boolean bl = by6 == 7;
        byte by7 = 0;
        if (by5 > 1) {
            by5 = -1;
        }
        if (by4 == 0) {
            by2 = (byte)(by3 + 1);
            int n3 = n2;
            if (by3 == 2) {
                by2 = 0;
                n3 = n2 + 1;
            }
            if (this.a(e[n][n3], by2, (byte)3, (byte)4) == 7) {
                this.ds = 1;
                if (bl) {
                    this.f(by);
                    this.v = (byte)3;
                    this.ak = true;
                    return;
                }
                int n4 = by2 - 1;
                if (n4 < 0) {
                    n4 = 2;
                }
                this.dA = 0;
                byte by8 = (byte)this.a(e[n][n3], by2, (byte)0, (byte)3);
                byte by9 = (byte)this.a((int)by, (byte)54, (byte)3);
                this.a((int)by8, by9, (byte)54, (byte)3);
                this.a((int)by8, (byte)2, (byte)28, (byte)3);
                this.a((int)by8, (byte)0, (byte)47, (byte)2);
                this.a((int)by8, (byte)n4, (byte)26, (byte)2);
                this.a((int)by8, (byte)n, (byte)14, (byte)6);
                this.a((int)by8, (byte)n3, (byte)20, (byte)6);
                this.a((int)by8, (byte)0, (byte)57, (byte)1);
                this.f(by);
                return;
            }
        }
        if (by3 == 2 && by4 == 0) {
            if ((byte)(a[n][n2 + 1] - 80) >= 0 || a[n][n2 + 1] == 10 || a[n][n2 + 1] == 37 || a[n][n2 + 1] == 34 || a[n][n2 + 1] == 35) {
                if (by5 == 0) {
                    if (bl) {
                        this.c(n, n2, by3);
                    } else {
                        this.a(n, n2, by3, (byte)15, (byte)3, (byte)4);
                    }
                    by7 = this.a(by, n, n2, by5, by3, (byte)1, bl);
                    if (by7 < 0) {
                        by7 = this.a(by, n, n2, by5, by3, (byte)-1, bl);
                    } else if ((byte)(a[n + -1][n2] - 80) < 0 && a[n + -1][n2] != 10 && a[n + -1][n2] != 37 && a[n + -1][n2] != 34 && a[n + -1][n2] != 35) {
                        this.a(n - 1, n2, bl ? (byte)7 : 5, (byte)-1, (byte)2, (byte)this.a((int)by, (byte)54, (byte)3));
                    }
                } else {
                    by7 = this.a(by, n, n2, by5, by3, by5, bl);
                }
                if (by7 == -2) {
                    by2 = b[n][n2 + 1];
                    if (this.d((int)by2) && this.a(n, n2, (int)by5)) {
                        this.ds = 0;
                        this.dA = 0;
                        this.a((int)by, (byte)2, (byte)28, (byte)3);
                        this.a((int)by, this.a((int)by2, (byte)0, (byte)6), (byte)0, (byte)7);
                        this.a((int)by, (byte)2, (byte)26, (byte)2);
                        this.a((int)by, (byte)n, (byte)14, (byte)6);
                        this.a((int)by, (byte)(n2 + 1), (byte)20, (byte)6);
                    } else {
                        this.a((int)by, (byte)3, (byte)28, (byte)3);
                    }
                    n += by5;
                } else {
                    by5 = by7;
                    n += by5;
                }
            } else if (by5 != 0) {
                by5 = 0;
                this.a((int)by, (byte)0, (byte)45, (byte)2);
            }
        }
        if (by7 != -2) {
            switch (by5) {
                case 0: {
                    this.a(by, n, n2, by3, bl);
                    return;
                }
                case -1: 
                case 1: {
                    this.a(n, n2, by3, by4);
                }
            }
        }
    }

    public final void a(int n, int n2, byte by, byte by2) {
        if ((by2 = (byte)(by2 + 1)) > 2) {
            by2 = 0;
        }
        this.a(n, n2, by, by2, (byte)7, (byte)2);
    }

    public final void a(byte by, int n, int n2, byte by2, boolean bl) {
        if (!bl && this.a(e[n][n2], by2, (byte)3, (byte)4) == 0) {
            this.a(n, n2, by2, (byte)3, (byte)3, (byte)4);
        }
        if ((by2 = (byte)(by2 + 1)) > 2) {
            by2 = 0;
            this.a((int)by, (byte)(++n2), (byte)37, (byte)6);
        }
        this.a((int)by, by2, (byte)43, (byte)2);
        if (bl) {
            this.a(n, n2, by2, (byte)6, (byte)3, (byte)4);
            return;
        }
        this.a(n, n2, by2, by, (byte)0, (byte)3);
        this.a(n, n2, by2, (byte)0, (byte)3, (byte)4);
    }

    public final void r(int n, int n2) {
        this.v = 1;
        this.a(n, n2 + 1, (byte)0, (byte)0, (byte)0, this.b(n, n2));
    }

    public final void c(int n, int n2, byte by) {
        int n3 = e[n][n2];
        byte by2 = (byte)(by * 9);
        int n4 = n3 >>> by2;
        n4 &= 0x1FF;
        k.e[n][n2] = n3 ^= (n4 <<= by2);
        k.c[n][n2] = 24;
    }

    public final byte a(int n, int n2, byte by, byte by2, byte by3, byte by4) {
        byte by5;
        for (by5 = 1; by5 <= 15 && this.a((int)by5, (byte)28, (byte)3) != 0; by5 = (byte)((byte)(by5 + 1))) {
        }
        k.a[by5 - 1] = 0L;
        if (by == 7) {
            this.c(n, n2, by3);
            this.a((int)by5, (byte)7, (byte)28, (byte)3);
        } else {
            this.a((int)by5, (byte)1, (byte)28, (byte)3);
            this.a((int)by5, by4, (byte)54, (byte)3);
            this.a(n, n2, by3, by5, (byte)0, (byte)3);
            this.a(n, n2, by3, by, (byte)3, (byte)4);
        }
        this.a((int)by5, (byte)n, (byte)31, (byte)6);
        this.a((int)by5, (byte)n2, (byte)37, (byte)6);
        this.a((int)by5, by3, (byte)43, (byte)2);
        if (by2 < 0) {
            by2 = (byte)2;
        }
        this.a((int)by5, by2, (byte)45, (byte)2);
        return by5;
    }

    public final int a(int n, int n2, int n3, byte by) {
        byte by2 = (byte)this.a(n3, by, (byte)0, (byte)3);
        int n4 = this.a((int)by2, (byte)31, (byte)6);
        int n5 = this.a((int)by2, (byte)37, (byte)6);
        int n6 = this.a((int)by2, (byte)43, (byte)2);
        int n7 = this.a(n3, by, (byte)3, (byte)4);
        if (n4 == n && n5 == n2 && n6 == by) {
            switch (n7) {
                case 4: {
                    n7 = 1;
                    break;
                }
                case 5: {
                    n7 = 2;
                }
            }
            return n7 << 1;
        }
        switch (n7) {
            case 6: {
                this.c(n, n2, by);
            }
        }
        return n7 << 1;
    }

    public final void s(int n, int n2) {
        if (this.k) {
            int n3 = e[n - 1][n2] != 0 ? -1 : (this.dy = e[n + 1][n2] != 0 ? 1 : 0);
            if (this.dy == 0) {
                int n4 = this.dy = e[n][n2 - 1] != 0 ? 2 : 0;
            }
            if (this.dy != 0) {
                this.v = (byte)5;
                this.dw = n;
                this.dx = n2;
            }
        }
    }

    public final int f(int n, int n2) {
        byte by = 0;
        boolean bl = true;
        int n3 = 0;
        int n4 = this.dy;
        int n5 = 0;
        block0: while (true) {
            int n6 = 0;
            while (e[n + n4][n2 - 1] != 0 && (byte)(a[n][n2] - 80) >= 0 || a[n][n2] == 10 || a[n][n2] == 37 || a[n][n2] == 34 || a[n][n2] == 35) {
                n += n4;
            }
            n3 = 0;
            while ((byte)(a[n + n3][n2] - 80) < 0 && a[n + n3][n2] != 10 && a[n + n3][n2] != 37 && a[n + n3][n2] != 34 && a[n + n3][n2] != 35) {
                if (bl) {
                    bl = false;
                    by = this.a(n, n2, (byte)8, (byte)-2, (byte)2, (byte)0);
                    this.a((int)by, (byte)5, (byte)28, (byte)3);
                    this.a((int)by, (byte)n, (byte)14, (byte)6);
                    this.a((int)by, (byte)n2, (byte)20, (byte)6);
                }
                this.a(n + n3, n2, (byte)2, by, (byte)0, (byte)3);
                n3 += n4;
            }
            n3 = Math.abs(n3);
            n5 += n3;
            ++n2;
            while (true) {
                if (e[n][n2] != 0) continue block0;
                if (n6 >= n3 || (n += n4) < 0 || n == this.ax) {
                    if (n5 > 0) {
                        this.a((int)by, (byte)n5, (byte)7, (byte)7);
                    }
                    return n5;
                }
                ++n6;
            }
            break;
        }
    }

    public final void t(int n, int n2) {
        this.dr = 0;
        int n3 = 0;
        n3 = this.dy > 1 ? e[n][n2 - 1] : e[n + this.dy][n2];
        this.u = (byte)this.a(n3, (byte)2, (byte)0, (byte)3);
        this.a((int)this.u, (byte)0, (byte)47, (byte)2);
        int n4 = this.a((int)this.u, (byte)7, (byte)7);
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        switch (this.dy) {
            case 2: {
                n5 = 0;
                n6 = n;
                n7 = n2;
                n8 = n4;
                n9 = n2 - 1;
                this.dx = -1;
                this.dw = -1;
                break;
            }
            default: {
                n5 = this.dy;
                n6 = n + n5;
                n5 = n5 < 0 ? 1 : 2;
                n7 = n2 + 1;
                n8 = n4 - this.f(n6, n7);
                n9 = n2;
                this.dw = n;
                this.dx = n2;
            }
        }
        this.a((int)this.u, (byte)n5, (byte)45, (byte)2);
        this.dz = n7;
        this.a((byte)n8, (byte)n6, (byte)n9, (byte)n5);
        byte by = this.b(n6, n9);
        this.a(by, (byte)2, (byte)0, (byte)4);
        this.v = 1;
        switch (this.dy) {
            case 2: {
                by = this.a(n6, n2, (byte)3, (byte)0, (byte)0, by);
                break;
            }
            case 1: {
                by = this.a(n6 - 1, n2, (byte)14, (byte)-1, (byte)2, by);
                break;
            }
            case -1: {
                by = this.a(n6 + 1, n2, (byte)11, (byte)1, (byte)2, by);
            }
        }
        this.a((int)by, (byte)6, (byte)28, (byte)3);
        this.dy = 0;
    }

    public final void u(int n, int n2) {
        byte by = this.a(n, n2, (byte)2);
        if (by > 0) {
            k.a[n][n2] = -1;
            this.r(n, n2);
        }
    }

    public final int b(b b2, int n) {
        int n2 = (n << 2) + 3;
        return b2.c[n2] & 0xFF;
    }

    public final int c(b b2, int n) {
        int n2 = (n << 2) + 2;
        return b2.c[n2] & 0xFF;
    }

    public final void A(int n) {
        try {
            a = n <= 5 ? k.a("/tips.f", n) : null;
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(k.a("/tipst.f", 0));
            int n2 = byteArrayInputStream.read();
            byte[] byArray = new byte[(n2 + 1) * 2];
            byteArrayInputStream.read(byArray);
            int n3 = k.a(byArray, (n %= n2) << 1);
            int n4 = k.a(byArray, n + 1 << 1);
            byteArrayInputStream.skip(n3);
            f = new byte[n4 - n3];
            byteArrayInputStream.read(f);
            byteArrayInputStream.close();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void cl() {
        k.a[41].p = 0;
        int n = 0;
        ++n;
        int n2 = f[0];
        this.R = false;
        Graphics graphics = a;
        graphics.setColor(798521);
        graphics.fillRoundRect(5, 16, 166, 145, 8, 8);
        graphics.setColor(13540096);
        graphics.drawRoundRect(5, 16, 166, 145, 8, 8);
        int n3 = 0;
        boolean bl = true;
        for (int i2 = 0; i2 <= n2; ++i2) {
            int n4;
            byte by;
            if (i2 == n2) {
                if (bl) {
                    bl = false;
                    i2 = -1;
                    n = 1;
                    n3 -= 4;
                    n3 = 16 + (145 - n3 >> 1);
                    continue;
                }
                return;
            }
            if ((by = f[n++]) == 0) {
                boolean bl2 = false;
                n += 2;
                boolean bl3 = false;
                n4 = k.a(f, n += 2);
                int n5 = n += 2;
                n += n4;
                byte by2 = f[n++];
                int n6 = n;
                n += by2;
                n3 += this.a(graphics, f, a[41], n5, n4, bl ? -1 : (n3 -= 3), a, n6, 158);
            } else {
                n += 2;
                n += 2;
                n4 = f[n++] & 0xFF;
                if (a != null) {
                    if (!bl) {
                        a.a(graphics, n4, (176 - k.a.c[(n4 << 2) + 2] & 0xFF) >> 1, n3, 0, 0, 0);
                    }
                    n3 += k.a.c[(n4 << 2) + 3] & 0xFF;
                }
            }
            n3 += 4;
        }
    }

    public final void a(Graphics graphics, b b2, String string, int n, int n2, int n3, int n4, boolean bl) {
        b2.p = n4;
        if (string.endsWith("\n")) {
            string = string.substring(0, string.length() - 1);
        }
        string = k.a(string, 160);
        int n5 = k.a(b2, string, bl ? -1 : 0);
        int n6 = b2.a(string);
        int n7 = n;
        int n8 = n2;
        if ((n3 & 0x20) != 0) {
            n8 -= n6;
        } else if ((n3 & 2) != 0) {
            n8 -= n6 >> 1;
        }
        if ((n3 & 8) != 0) {
            n7 -= n5;
        } else if ((n3 & 1) != 0) {
            n7 -= n5 >> 1;
        }
        graphics.setColor(798521);
        graphics.fillRoundRect(n7 - 5, n8 - 5, n5 + 10, n6 + 10 + 1, 10, 10);
        graphics.setColor(13540096);
        graphics.drawRoundRect(n7 - 5, n8 - 5, n5 + 10, n6 + 10, 10, 10);
        b2.b(graphics, string, n, n2, n3);
    }

    public final int a(Graphics graphics, byte[] byArray, b b2, int n, int n2, int n3, b b3, int n4, int n5) {
        int n6 = 0;
        int n7 = b2.p + (b2.a[1] & 0xFF);
        int n8 = 0;
        int n9 = n3 -= b2.d[2];
        boolean bl = n3 != -1;
        int n10 = b2.m;
        int n11 = n;
        boolean bl2 = true;
        int n12 = n;
        int n13 = 0;
        boolean bl3 = false;
        for (int i2 = n; i2 <= n + n2; ++i2) {
            int n14;
            int n15 = 10;
            if (i2 < n + n2) {
                n15 = byArray[i2] & 0xFF;
            }
            if (bl2 && n8 > n5) {
                n8 = n13;
                byArray[n12] = 10;
                i2 = n12 - 1;
                continue;
            }
            if (n15 == 10) {
                if (bl2 && bl) {
                    n8 = 88 - (n8 >> 1);
                    i2 = n11 - 1;
                    n6 = 0;
                } else {
                    n8 = 0;
                    n11 = i2 + 1;
                    n9 += n7;
                    n7 = b2.p + (b2.a[1] & 0xFF);
                }
                if (!bl) continue;
                bl2 = !bl2;
                continue;
            }
            if (n15 > 32) {
                if (n15 == 64 && b3 != null) {
                    if (!bl2 && bl) {
                        b3.a(graphics, byArray[n6 + n4], n8, n9, 0, 0, 0);
                    }
                    n8 += this.c(b3, (int)byArray[n6 + n4]);
                    n14 = this.b(b3, (int)byArray[n6 + n4]);
                    if (n14 > n7) {
                        n7 = n14;
                    }
                    ++n6;
                    continue;
                }
                n15 = b.h[n15] & 0xFF;
            } else {
                if (n15 == 32) {
                    n12 = i2;
                    n13 = n8;
                    n8 += (b2.a[0] & 0xFF) + b2.d[1];
                    continue;
                }
                if (n15 == 1) {
                    b2.m = byArray[++i2];
                    continue;
                }
                if (n15 != 2) continue;
                n15 = byArray[++i2] & 0xFF;
            }
            if (n15 >= b2.b(0)) {
                n14 = n15 - b2.b(0);
                if (!bl2 && bl) {
                    b2.a(graphics, n14, n8, n9, 0, 0, 0);
                }
                n8 += (b2.c[(n14 << 2) + 2] & 0xFF) - (b2.c[n14 << 2] & 0xFF) + b2.d[1];
                continue;
            }
            n14 = (b2.d[n15 << 2] & 0xFF) << 1;
            if (!bl2 && bl) {
                b2.b(graphics, 0, n15, n8, n9, 0, 0, 0);
            }
            n8 += (b2.a[n14] & 0xFF) - b2.d[(n15 << 2) + 1] + b2.d[1];
        }
        b2.m = n10;
        return n9 - n3;
    }

    public final void cm() {
        this.H = false;
        k.a(a[23], true);
        k.a[23] = null;
        k.a(a[24], true);
        k.a[24] = null;
        k.a(a[25], true);
        k.a[25] = null;
        k.a(a[26], true);
        k.a[26] = null;
        k.a(a[17], true);
        k.a[17] = null;
        this.a = null;
        c = null;
        d = null;
        System.gc();
    }

    public final void cn() {
        this.a();
        this.at = true;
        this.au = true;
        this.am = true;
        l = (byte)21;
        this.bu = 0;
        this.bt = 14;
        this.dL = 100;
        if (this.aq > this.a(this.ap)) {
            this.aq = this.a(this.ap);
        }
        this.cH();
    }

    private void cH() {
        a = new long[12][12];
        this.a = new int[20];
    }

    public final int a(long l, byte by, byte by2) {
        l >>>= by;
        return (int)(l &= -1L << by2 ^ 0xFFFFFFFFFFFFFFFFL);
    }

    public final void a(int n, int n2, int n3, byte by, byte by2) {
        long l = a[n][n2];
        long l2 = this.a(l, by, by2);
        l ^= (l2 <<= by);
        long l3 = n3;
        k.a[n][n2] = l |= (l3 <<= by);
    }

    public final void co() {
        if (this.at) {
            c = Image.createImage((int)165, (int)124);
        }
        if (this.au) {
            this.au = false;
            this.av = true;
            this.cu();
            this.ct();
        }
        if (this.av) {
            k.a(a, c, 6, 51, 0);
            this.cv();
            this.cs();
            this.cp();
            this.cq();
        }
        if (this.av && this.dW == this.dY && this.dX == this.dZ) {
            this.av = false;
        }
    }

    public final void cp() {
        long l = a[this.dW][this.dX];
        int n = this.a(l, (byte)6, (byte)5);
        if (n < this.dL) {
            a[41].a(a, a.toString() + (n + 1), 8, 43, 6);
            return;
        }
        a[41].a(a, b.toString() + (n - this.dL + 1), 8, 43, 6);
    }

    public final void cq() {
        int n;
        if (this.dW != this.dY || this.dX != this.dZ) {
            return;
        }
        long l = a[this.dW][this.dX];
        int n2 = this.a(l, (byte)6, (byte)5);
        int n3 = 0;
        n3 = this.b(this.ap, n2);
        if (n3 > (n = this.c(this.ap, n2))) {
            n3 = n;
        }
        c.delete(0, c.length());
        c.append(n3);
        c.append('/');
        c.append(n);
        a[41].a(c.toString());
        boolean bl = false;
        int n4 = b.n + 6 + 14;
        boolean bl2 = false;
        int n5 = 16 + this.dW * 12 + 6;
        int n6 = 29 + this.dX * 12 + 6;
        int n7 = n5 - (n4 >> 1) + 0;
        int n8 = n6 - 16 + -31;
        if (n8 <= 63) {
            n8 = 63;
            n7 = n5 + 20;
            if (n7 + n4 >= 160) {
                n7 = n5 - n4 + -20;
            }
        }
        if (n7 <= 15) {
            n7 = 15;
        }
        if (n7 + n4 >= 160) {
            n7 = 114;
        }
        k.b(a, n7, n8, n4, 16, 37042, 0);
        a[41].a(a, c.toString(), n7 + 2, n8 + 2, 20);
        if (a[17] != null) {
            a[17].a(a, 10, n7 + n4 - 2 - 14, n8 + 2 - 1, 0, 0, 0);
        }
    }

    public final void cr() {
        this.em = 0;
        this.ej = 0;
        this.ek = 0;
        this.aq = false;
        this.ap = true;
        this.ao = false;
        this.el = 2;
        this.en = 2;
        this.ar = false;
    }

    public final boolean g() {
        int n;
        int n2;
        boolean bl = false;
        int n3 = this.ej >> 1;
        this.el = this.el < 0 ? 2 : --this.el;
        if (this.dY == 0 && this.dZ == 0) {
            this.dY = this.dW;
            this.dZ = this.dX;
        }
        if (this.el == 0) {
            if (this.ek == n3) {
                bl = true;
            } else {
                ++this.ek;
                bl = false;
            }
        }
        long l = a[this.dW][this.dX];
        int n4 = this.a(l, (byte)3, (byte)3);
        long l2 = a[this.dY][this.dZ];
        int n5 = this.a(l2, (byte)3, (byte)3);
        int n6 = 0;
        int n7 = 0;
        n7 = n4 == 1 || n5 == 1 ? 1 : n4;
        switch (n7) {
            case 0: {
                n6 = 2;
                break;
            }
            case 1: {
                n6 = 8;
            }
        }
        int n8 = 0;
        int n9 = this.ar ? n3 - 1 : 0;
        int n10 = n2 = this.ar ? -1 : 1;
        while (n8 < this.ek) {
            n = n9 * 2;
            a[17].a(a, n6, this.a[n], this.a[n + 1], 0, 0, 0);
            ++n8;
            n9 += n2;
        }
        n = 0;
        int n11 = 0;
        switch (n4) {
            case 0: {
                n11 = 0;
                n = 0;
                break;
            }
            case 1: {
                n11 = 2;
                n = 9;
            }
        }
        int n12 = this.dW * 12 + n11 + 16;
        int n13 = this.dX * 12 + n11 + 29;
        a[17].a(a, n, n12, n13, 0, 0, 0);
        int n14 = this.an ? 7 : 6;
        a[17].a(a, n14, n12 + 6, n13 + 6, 0, 0, 0);
        boolean bl2 = true;
        if (n8 == n3) {
            this.en = this.en < 0 ? 2 : --this.en;
            if (this.en == 0) {
                this.en = 1;
                bl2 = false;
            }
        }
        if (!bl2) {
            switch (n5) {
                case 0: {
                    n11 = 0;
                    n = 0;
                    break;
                }
                case 1: {
                    n11 = 2;
                    n = 9;
                }
            }
        } else {
            switch (n5) {
                case 0: {
                    n11 = 0;
                    n = 1;
                    break;
                }
                case 1: {
                    n11 = 2;
                    n = 5;
                }
            }
        }
        n12 = this.dY * 12 + n11 + 16;
        n13 = this.dZ * 12 + n11 + 29;
        a[17].a(a, n, n12, n13, 0, 0, 0);
        if (!bl2) {
            if (this.em == a[9].a(0)) {
                --this.em;
                this.aq = true;
                bl = true;
            } else {
                bl = false;
            }
            if (!this.P) {
                a[9].a(a, this.em, n12, n13, 0, 0, 0);
            }
            ++this.em;
        }
        return bl;
    }

    public final void cs() {
        int n = 16 + this.dW * 12 + 6;
        int n2 = 29 + this.dX * 12 + 6;
        if (this.dW != this.dY || this.dX != this.dZ) {
            int n3 = 16 + this.dY * 12 + 6;
            int n4 = 29 + this.dZ * 12 + 6;
            if ((this.a(this.ap, this.aq + 1) & 2) != 0 && this.aq + 1 == ea || this.aq == ea) {
                this.ao = true;
            }
            if (!this.ao) {
                this.ao = this.g();
                if (this.ao) {
                    this.au = true;
                    return;
                }
            } else {
                boolean bl = this.c(n, n2, n3, n4);
                if (bl) {
                    this.dW = this.dY;
                    this.dX = this.dZ;
                    return;
                }
            }
        } else if (this.av) {
            int n5 = this.an ? 7 : 6;
            a[17].a(a, n5, n, n2, 0, 0, 0);
        }
    }

    public final boolean c(int n, int n2, int n3, int n4) {
        int n5;
        if (this.am) {
            this.am = false;
            this.dN = n;
            this.dO = n2;
            this.dP = 0;
            this.dQ = n3 - n;
            this.dR = n4 - n2;
            this.dS = 0;
            this.dT = 0;
            this.dU = 10;
            this.dV = 10;
        }
        if (this.dQ < 0) {
            this.dU = -10;
            this.dQ = -this.dQ;
        }
        if (this.dR < 0) {
            this.dV = -10;
            this.dR = -this.dR;
        }
        this.an = this.dU <= 0;
        int n6 = n5 = this.an ? 7 : 6;
        if (this.dR <= this.dQ) {
            this.dS = 2 * this.dQ;
            this.dT = 2 * this.dR;
            if (this.dU < 0 && this.dN <= n3 || this.dU > 0 && this.dN >= n3) {
                n3 = 16 + this.dY * 12 + 6;
                n4 = 29 + this.dZ * 12 + 6;
                a[17].a(a, n5, n3, n4, 0, 0, 0);
                this.am = true;
                return true;
            }
            a[17].a(a, n5, this.dN, this.dO, 0, 0, 0);
            this.dN += this.dU;
            this.dP += this.dT;
            if (this.dP > this.dQ) {
                this.dO += this.dV;
                this.dP -= this.dS;
            }
        } else {
            this.dS = 2 * this.dR;
            this.dT = 2 * this.dQ;
            if (this.dV < 0 && this.dO <= n4 || this.dV > 0 && this.dO >= n4) {
                n3 = 16 + this.dY * 12 + 6;
                n4 = 29 + this.dZ * 12 + 6;
                a[17].a(a, n5, n3, n4, 0, 0, 0);
                this.am = true;
                return true;
            }
            a[17].a(a, n5, this.dN, this.dO, 0, 0, 0);
            this.dO += this.dV;
            this.dP += this.dT;
            if (this.dP > this.dR) {
                this.dN += this.dU;
                this.dP -= this.dS;
            }
        }
        return false;
    }

    public final void a(int n, int n2, long l, int n3, int n4) {
        int n5 = this.a(l, (byte)6, (byte)5);
        this.dM |= 1 << n5;
        int n6 = this.a(l, (byte)11, (byte)3);
        int n7 = 14;
        int n8 = 0;
        while (n8 < n6) {
            block29: {
                boolean bl;
                int n9;
                int n10;
                int n11;
                int n12;
                int n13;
                int n14;
                int n15;
                int n16;
                block30: {
                    int n17 = 16 + n * 12;
                    int n18 = 29 + n2 * 12;
                    int n19 = this.a(l, (byte)n7, (byte)4);
                    int n20 = this.a(l, (byte)(n7 += 4), (byte)4);
                    n16 = n19;
                    n15 = n20;
                    long l2 = a[n16][n15];
                    n14 = this.a(l2, (byte)6, (byte)5);
                    int n21 = this.dM;
                    if ((n21 &= 1 << n14) > 0) break block29;
                    n16 = 16 + n16 * 12;
                    n15 = 29 + n15 * 12;
                    this.eb = n17 += 6;
                    this.ec = n18 += 6;
                    this.ed = 0;
                    this.ee = (n16 += 6) - n17;
                    this.ef = (n15 += 6) - n18;
                    this.eg = 0;
                    this.eh = 0;
                    this.ei = 1;
                    n13 = 1;
                    n12 = 1;
                    if (this.ee < 0) {
                        n13 = -1;
                        this.ee = -this.ee;
                    }
                    if (this.ef < 0) {
                        n12 = -1;
                        this.ef = -this.ef;
                    }
                    n11 = 0;
                    n10 = this.a(l2, (byte)0, (byte)3);
                    n9 = this.a(l2, (byte)3, (byte)3);
                    if (n3 == 1) {
                        n9 = n3;
                    }
                    if (n4 != 1) break block30;
                    if (n9 == 1) break block29;
                    n10 = n4;
                }
                if (!this.aq && n14 == ea) {
                    n10 = 1;
                }
                if (n10 == 0) {
                    switch (n9) {
                        case 0: {
                            n11 = 2;
                            break;
                        }
                        case 1: {
                            n11 = 8;
                        }
                    }
                } else {
                    switch (n9) {
                        case 0: {
                            n11 = 3;
                            break;
                        }
                        case 1: {
                            n11 = 4;
                        }
                    }
                }
                if (this.ef <= this.ee) {
                    this.eg = this.ee << 1;
                    this.eh = this.ef << 1;
                    bl = false;
                    while (true) {
                        if (this.ei % 8 == 0) {
                            a[17].a(d, n11, this.eb - 6, this.ec - 51, 0, 0, 0);
                            if (this.ap) {
                                this.v(n5, n14);
                            }
                        }
                        if (this.eb != n16) {
                            this.eb += n13;
                            this.ed += this.eh;
                            if (this.ed > this.ee) {
                                this.ec += n12;
                                this.ed -= this.eg;
                            }
                            ++this.ei;
                            continue;
                        }
                        break;
                    }
                } else {
                    this.eg = 2 * this.ef;
                    this.eh = 2 * this.ee;
                    bl = false;
                    while (true) {
                        if (this.ei % 8 == 0) {
                            a[17].a(d, n11, this.eb - 6, this.ec - 51, 0, 0, 0);
                            if (this.ap) {
                                this.v(n5, n14);
                            }
                        }
                        if (this.ec == n15) break;
                        this.ec += n12;
                        this.ed += this.eh;
                        if (this.ed > this.ef) {
                            this.eb += n13;
                            this.ed -= this.eg;
                        }
                        ++this.ei;
                    }
                }
            }
            ++n8;
            n7 += 4;
        }
    }

    public final void v(int n, int n2) {
        if (!this.as) {
            long l = a[this.cz][this.cA];
            int n3 = this.a(l, (byte)6, (byte)5);
            if (n2 == ea && n == n3 || n == ea && n2 == n3) {
                if (n == ea && n2 == n3) {
                    this.ar = true;
                }
                this.a[this.ej++] = this.eb;
                this.a[this.ej++] = this.ec;
                return;
            }
        } else if (n2 == ea && n == ea - 1 || n == ea && n2 == ea - 1) {
            if (n == ea && n2 == ea - 1) {
                this.ar = true;
            }
            this.a[this.ej++] = this.eb;
            this.a[this.ej++] = this.ec;
        }
    }

    public final void ct() {
        this.dM = 0;
        if ((this.a(this.ap, this.aq + 1) & 2) != 0 && this.aq + 1 == ea || this.aq == ea) {
            this.ap = false;
            this.aq = true;
        }
        for (int i2 = 0; i2 < 12; ++i2) {
            for (int i3 = 0; i3 < 12; ++i3) {
                int n;
                long l = a[i2][i3];
                boolean bl = false;
                if (l == 0L) continue;
                int n2 = this.a(l, (byte)3, (byte)3);
                int n3 = this.a(l, (byte)6, (byte)5);
                int n4 = !this.aq && n3 == ea && n3 != 0 ? 1 : this.a(l, (byte)0, (byte)3);
                int n5 = -1;
                int n6 = -1;
                int n7 = -1;
                if (n4 == 0) {
                    bl = this.b(this.ap, n3) == this.c(this.ap, n3);
                    switch (n2) {
                        case 0: {
                            n6 = 17;
                            n7 = 0;
                            n = this.a(l, (byte)11, (byte)3);
                            if (n > 2) {
                                n5 = 13;
                                break;
                            }
                            n5 = 0;
                            break;
                        }
                        case 1: {
                            n6 = 18;
                            n7 = 2;
                            n5 = 9;
                        }
                    }
                } else {
                    switch (n2) {
                        case 0: {
                            n7 = 0;
                            n5 = 1;
                        }
                    }
                }
                this.a(i2, i3, l, n2, n4);
                if (n7 == -1 || n5 == -1) continue;
                if (bl && n6 != -1) {
                    a[17].a(d, n6, i2 * 12 + n7 + 16 - 6, i3 * 12 + n7 + 29 - 51, 0, 0, 0);
                }
                a[17].a(d, n5, i2 * 12 + n7 + 16 - 6, i3 * 12 + n7 + 29 - 51, 0, 0, 0);
                n = -1;
                switch (this.ap) {
                    case 0: {
                        if (n3 != 8) break;
                        n = 52;
                        break;
                    }
                    case 1: {
                        if (n3 != 9) break;
                        n = 53;
                        break;
                    }
                    case 2: {
                        if (n3 != 10) break;
                        n = 54;
                    }
                }
                if (n == -1) continue;
                a[n].a(d, 0, i2 * 12 + -8 + 16 - 6, i3 * 12 + -8 + 29 - 51, 0, 0, 0);
            }
        }
        this.ap = false;
    }

    public final void cu() {
        k.a(a, 0, 0, 176, 208);
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        int n4 = -1;
        int n5 = 0;
        switch (this.ap) {
            case 0: {
                n = 939282;
                n2 = 3111750;
                n3 = 8635434;
                n5 = 24;
                n4 = 28;
                break;
            }
            case 1: {
                n = 869201;
                n2 = 4022666;
                n3 = 5873874;
                n5 = 25;
                n4 = 29;
                break;
            }
            case 2: {
                n = 5210510;
                n2 = 3711421;
                n3 = 7469567;
                n5 = 26;
                n4 = 30;
            }
        }
        a.setColor(n);
        a.fillRect(0, 0, 176, 208);
        a[n5].a(a, 0, 87, 0, 0, 0, 0);
        a[41].a(a, a[n4], 8, 6, 20);
        d = c.getGraphics();
        d.setColor(n);
        d.fillRect(0, 0, 165, 124);
        a[23].a(d, 0, 81, 62, 0, 0, 0);
        a.setColor(n2);
        a.fillRoundRect(2, 175, 172, 16, 8, 8);
        a.setColor(n3);
        a.drawRoundRect(2, 175, 172, 16, 8, 8);
        this.ag();
        this.ah();
        a[41].a(a, a[96], 156, 201, 10);
        if (a[17] != null) {
            a[17].a(a, 12, 5, 177, 0, 0, 0);
            a[17].a(a, 10, 104, 177, 0, 0, 0);
            a[17].a(a, 11, 49, 177, 0, 0, 0);
        }
        c.delete(0, c.length());
        c.append(this.ao);
        a[41].a(a, c.toString(), 29, 178, 20);
        c.delete(0, c.length());
        c.append(k.a(i, 4));
        a[41].a(a, c.toString(), 66, 178, 20);
        c.delete(0, c.length());
        int n6 = k.a(i, 6);
        boolean bl = false;
        byte by = i[0];
        if (n6 >= by) {
            c.append(n6).append("/").append(n6);
        } else {
            c.append(n6).append("/").append(by);
        }
        a[41].a(a, c.toString(), 123, 178, 20);
        this.at = false;
    }

    public final void cv() {
        int n = 0;
        int n2 = 0;
        switch (this.ap) {
            case 0: {
                n = 3111750;
                n2 = 8635434;
                break;
            }
            case 1: {
                n = 4022666;
                n2 = 5873874;
                break;
            }
            case 2: {
                n = 3711421;
                n2 = 7469567;
            }
        }
        a.setColor(n);
        a.fillRoundRect(2, 33, 172, 18, 8, 8);
        a.setColor(n2);
        a.drawRoundRect(2, 33, 172, 18, 8, 8);
    }

    public final void cw() {
        if (this.dW == this.dY && this.dX == this.dZ) {
            int n = -1;
            if (this.a(4097)) {
                n = 2;
            } else if (this.a(262146)) {
                n = 3;
            } else if (this.a(16388)) {
                n = 4;
            } else if (this.a(65544)) {
                n = 1;
            } else {
                if (this.a(32976)) {
                    if (System.currentTimeMillis() - this.p < 2000L) {
                        return;
                    }
                    long l = a[this.dW][this.dX];
                    int n2 = this.a(l, (byte)6, (byte)5);
                    this.u();
                    this.cm();
                    System.gc();
                    this.aq = n2;
                    this.n();
                    W = 0;
                    return;
                }
                if (this.a(32)) {
                    this.J = true;
                    this.H = true;
                    this.L = true;
                    this.bu = 0;
                    l = (byte)28;
                    W = 0;
                    return;
                }
            }
            W = 0;
            if (n != 0 && n != -1) {
                int n3;
                int n4;
                int n5;
                int n6 = this.dW;
                int n7 = this.dX;
                long l = a[n6][n7];
                int n8 = this.a(l, (byte)11, (byte)3);
                int n9 = 14;
                int n10 = -1;
                int n11 = -1;
                int n12 = 0;
                while (n12 < n8) {
                    n5 = this.a(l, (byte)n9, (byte)4);
                    long l2 = a[n5][n4 = this.a(l, (byte)(n9 += 4), (byte)4)];
                    n3 = this.a(l2, (byte)0, (byte)3);
                    if (n3 != 1) {
                        switch (n) {
                            case 1: {
                                if (n5 <= n6) break;
                                if (n10 >= 0) {
                                    n11 = n12;
                                    break;
                                }
                                n10 = n12;
                                break;
                            }
                            case 4: {
                                if (n5 >= n6) break;
                                if (n10 >= 0) {
                                    n11 = n12;
                                    break;
                                }
                                n10 = n12;
                                break;
                            }
                            case 2: {
                                if (n4 >= n7) break;
                                if (n10 >= 0) {
                                    n11 = n12;
                                    break;
                                }
                                n10 = n12;
                                break;
                            }
                            case 3: {
                                if (n4 <= n7) break;
                                if (n10 >= 0) {
                                    n11 = n12;
                                    break;
                                }
                                n10 = n12;
                            }
                        }
                    }
                    ++n12;
                    n9 += 4;
                }
                if (n10 != -1) {
                    n12 = -1;
                    if (n11 != -1) {
                        n9 = 14 + n10 * 2 * 4;
                        n5 = this.a(l, (byte)n9, (byte)4);
                        n4 = this.a(l, (byte)(n9 += 4), (byte)4);
                        n9 = 14 + n11 * 2 * 4;
                        int n13 = this.a(l, (byte)n9, (byte)4);
                        int n14 = this.a(l, (byte)(n9 += 4), (byte)4);
                        switch (n) {
                            case 1: 
                            case 4: {
                                if (n7 == n4) {
                                    n12 = n10;
                                    break;
                                }
                                if (n7 == n14) {
                                    n12 = n11;
                                    break;
                                }
                                if (Math.abs(n6 - n5) > Math.abs(n6 - n13)) {
                                    n12 = n10;
                                    break;
                                }
                                n12 = n11;
                                break;
                            }
                            case 2: 
                            case 3: {
                                n12 = n6 == n5 ? n10 : (n6 == n13 ? n11 : (n5 > n13 ? n10 : n11));
                            }
                        }
                    } else {
                        n12 = n10;
                    }
                    if (n12 != -1) {
                        n9 = 14 + n12 * 2 * 4;
                        n5 = this.a(l, (byte)n9, (byte)4);
                        long l3 = a[n5][n4 = this.a(l, (byte)(n9 += 4), (byte)4)];
                        n3 = this.a(l3, (byte)0, (byte)3);
                        if (n3 == 0) {
                            this.dY = n5;
                            this.dZ = n4;
                            this.av = true;
                        }
                    }
                }
            }
        }
    }

    public final void B(int n) {
        try {
            switch (n) {
                case 0: {
                    if (!this.I) break;
                    this.y();
                    break;
                }
                case 1: {
                    if (!this.J) break;
                    this.u();
                    break;
                }
                case 2: {
                    if (!this.G) break;
                    this.e();
                    break;
                }
                case 3: {
                    if (!this.H) break;
                    this.cm();
                    break;
                }
                case 4: {
                    k.a[41].m = 0;
                    c.delete(0, c.length());
                    switch (this.ap) {
                        case 0: {
                            c.append("/map_angkor.out");
                            break;
                        }
                        case 1: {
                            c.append("/map_scotland.out");
                            break;
                        }
                        case 2: {
                            c.append("/map_tibet.out");
                        }
                    }
                    a = new long[12][12];
                    this.a = new int[20];
                    this.a(c.toString());
                    break;
                }
                case 5: {
                    k.a[17] = k.a("/ms.f", 0);
                    k.a[23] = k.a("/ms.f", 1);
                    break;
                }
                case 6: {
                    switch (this.ap) {
                        case 0: {
                            k.a[24] = k.a("/ms.f", 2);
                            break;
                        }
                        case 1: {
                            k.a[25] = k.a("/ms.f", 3);
                            break;
                        }
                        case 2: {
                            k.a[26] = k.a("/ms.f", 4);
                        }
                    }
                    break;
                }
                case 7: {
                    if (a[54] == null) {
                        k.a[54] = k.a("/mmv.f", 1);
                    }
                    this.v = this.c(a[54], 0) >> 1;
                    this.w = this.b(a[54], 0) >> 1;
                    break;
                }
                case 8: {
                    if (a[53] != null) break;
                    k.a[53] = k.a("/mmv.f", 2);
                    break;
                }
                case 9: {
                    if (a[52] != null) break;
                    k.a[52] = k.a("/mmv.f", 3);
                    break;
                }
                case 10: {
                    if (!this.aa) break;
                    this.cr();
                    break;
                }
                case 14: {
                    if (this.B) {
                        this.B = false;
                    }
                    this.cx();
                    l = (byte)15;
                }
            }
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    private void a(String string) throws IOException {
        a a2 = k.a(string);
        int n = a2.a();
        n = ((byte)n & 0xFF) + ((byte)a2.a() & 0xFF) * 256;
        int n2 = a2.a();
        f = new byte[n];
        a2.a(f);
        a2.a();
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            byte by = f[n3++];
            byte by2 = f[n3++];
            byte by3 = f[n3++];
            int n4 = f[n3++];
            if (by3 == 1 && n4 < this.dL) {
                this.dL = n4;
            }
            int n5 = f[n3++];
            this.a((int)by, (int)by2, 1, (byte)0, (byte)3);
            this.a((int)by, (int)by2, (int)by3, (byte)3, (byte)3);
            this.a((int)by, (int)by2, n4, (byte)6, (byte)5);
            this.a((int)by, (int)by2, n5, (byte)11, (byte)3);
            byte by4 = 14;
            for (int i3 = 0; i3 < n5; ++i3) {
                byte by5 = f[n3++];
                this.a((int)by, (int)by2, (int)by5, by4, (byte)4);
                by4 = (byte)(by4 + 4);
                byte by6 = f[n3++];
                this.a((int)by, (int)by2, (int)by6, by4, (byte)4);
                by4 = (byte)(by4 + 4);
            }
        }
        f = null;
        System.gc();
    }

    public final void cx() {
        this.dW = -1;
        if (!this.aa) {
            this.aq = ea;
        }
        this.aa = false;
        for (int i2 = 0; i2 < 12; ++i2) {
            for (int i3 = 0; i3 < 12; ++i3) {
                long l = a[i2][i3];
                if (l == 0L) continue;
                int n = this.a(l, (byte)6, (byte)5);
                boolean bl = (this.a(this.ap, n) & 0x40) != 0;
                if (bl || n == 0) {
                    this.a(i2, i3, 0, (byte)0, (byte)3);
                } else {
                    this.a(i2, i3, 1, (byte)0, (byte)3);
                }
                if (n == this.aq) {
                    this.dW = i2;
                    this.dX = i3;
                }
                if (n == ea) {
                    this.dY = i2;
                    this.dZ = i3;
                }
                this.an = false;
            }
        }
    }

    public final void cy() {
        k.a[17] = k.a("/ms.f", 0);
        this.aH();
    }

    public static final void b(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6) {
        int n7;
        int n8 = graphics.getClipX();
        int n9 = graphics.getClipY();
        int n10 = graphics.getClipWidth();
        int n11 = graphics.getClipHeight();
        k.a(graphics, n, n2, n3, n4);
        graphics.setColor(n5);
        graphics.fillRect(n, n2, n3, n4);
        k.a(graphics, n - 3, n2, n3 + 6, n4);
        for (n7 = n2; n7 <= n2 + n4; n7 += 8) {
            k.a(graphics, b[n6][7], n, n7, 24);
            k.a(graphics, b[n6][5], n + n3, n7, 20);
        }
        k.a(graphics, n, n2 - 3, n3, n4 + 6);
        for (n7 = n; n7 <= n + n3; n7 += 8) {
            k.a(graphics, b[n6][4], n7, n2, 36);
            k.a(graphics, b[n6][6], n7, n2 + n4, 20);
        }
        k.a(graphics, n - 3, n2 - 3, n3 + 6, n4 + 6);
        k.a(graphics, b[n6][0], n, n2, 40);
        k.a(graphics, b[n6][1], n + n3, n2, 36);
        k.a(graphics, b[n6][2], n, n2 + n4, 24);
        k.a(graphics, b[n6][3], n + n3, n2 + n4, 20);
        k.a(graphics, n8, n9, n10, n11);
    }

    public static final void a(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9 = graphics.getClipX();
        int n10 = graphics.getClipY();
        int n11 = graphics.getClipWidth();
        int n12 = graphics.getClipHeight();
        k.b(graphics, n, n2, n3, n4, n5, n6);
        k.b(graphics, n + 10, n2 - 3 - n8, n7, n8, n5, n6);
        k.a(graphics, n + 10 - 3, n2 - 3, n7 + 6, 3);
        graphics.setColor(n5);
        graphics.fillRect(n + 10 - 3, n2 - 3, n7 + 6, 3);
        k.a(graphics, b[n6][3], n + 10, n2 - 3, 24);
        k.a(graphics, b[n6][2], n + 10 + n7, n2 - 3, 20);
        k.a(graphics, n9, n10, n11, n12);
    }

    public final void cz() {
        int n;
        int n2;
        if (this.c == this.eo && !this.au) {
            return;
        }
        if (this.c != this.eo) {
            this.au = true;
        }
        k.a(a, 0, 0, 176, 208);
        if (this.au) {
            this.a(a, true);
            a.setColor(0);
            a.fillRect(0, 0, 176, 12);
            a.setColor(0xFFFFFF);
            a.drawLine(0, 12, 176, 12);
            a[41].a(a, a[72], 88, 0, 17);
            k.b(a, 10, 18, 160, 66, 4273165, 0);
            if (this.d != -1) {
                a[41].b(a, k.a(this.a, 136), 88, 176, 17);
            }
            if (this.Y) {
                this.Y = false;
                a[41].a(a, this.a, 88, 122, 1);
            }
            a[41].b(a, this.f, 88, 160, 17);
            this.ag();
            this.ah();
            this.au = false;
        }
        if (this.c != this.eo) {
            a.setColor(4273165);
            a.fillRect(20, 23 + (this.eo >= 0 ? this.eo : this.c) * 14 + 2, 7, 9);
        }
        a[17].a(a, 14, 20, 23 + this.c * 14 + 2, 0, 0, 0);
        k.b(a, 10, 96, 160, 50, 4273165, 0);
        if (this.d != -1) {
            String string = a[74] + " " + this.d.toString() + "\n" + a[42];
            k.a[41].p = 0;
            a[41].b(a, string, 88, 116, 1);
        } else {
            a[41].b(a, this.a, 88, 122, 1);
        }
        int n3 = 0;
        for (int i2 = 0; i2 < 4; ++i2) {
            n3 = 23 + 14 * i2;
            a[46].a(a, 0 + i2, 27, n3, 0, 0, 0);
            a[41].a(a, a[85 + i2], 53, n3, 0);
        }
        f[] fArray = k.a[0].a[0];
        int n4 = fArray[11].a;
        int n5 = fArray[15].a;
        boolean bl = false;
        boolean bl2 = false;
        k.a(a, fArray[11], 68, 98, 0);
        for (n2 = 0; n2 < 8; ++n2) {
            n = n2 >= 4 ? 13 : 15;
            k.a(a, fArray[n], 68 + n4, 98, 0);
            n4 += n5;
        }
        n2 = this.c;
        n = n4;
        n4 -= n5 * 4;
        for (int i3 = 0; i3 <= n2; ++i3) {
            k.a(a, fArray[15], 68 + n4, 98, 0);
            n4 += n5;
        }
        k.a(a, fArray[17], 68 + n, 98, 0);
        if (this.c != this.eo) {
            this.eo = this.c;
        }
    }

    public static final void a(int n, int n2, short s) {
        for (int i2 = 0; i2 < a[n].length; i2 += 2) {
            if (n2 != a[n][i2]) continue;
            k.a[n][i2 + 1] = s;
            return;
        }
    }

    public final void C(int n) {
        this.a.b(n);
    }

    public final void cA() {
        switch (this.aO) {
            case 0: {
                this.ep = 0;
                this.eq = 0;
                this.aO = 1;
                return;
            }
            case 1: {
                s = k.a("/cr.f", 0);
                int n = 0;
                while (n < s.length) {
                    if (s[n] == 92 && s[n + 1] == 110) {
                        k.s[n++] = 10;
                        k.s[n++] = 32;
                        continue;
                    }
                    ++n;
                }
                n = 0;
                while (s[n] != 36) {
                    ++n;
                }
                int n2 = 0;
                while (n2 < GloftDIRU.a.length) {
                    k.s[n] = GloftDIRU.a[n2];
                    ++n2;
                    ++n;
                }
                this.aO = 2;
                return;
            }
            case 2: {
                int n;
                int n3;
                if (this.a(4097)) {
                    n3 = 0;
                    if (this.ep < 156) {
                        ++this.ep;
                    } else {
                        this.ep -= 3;
                        if (this.ep < 156) {
                            this.ep = 156;
                        }
                    }
                } else if (this.a(262146)) {
                    this.ep += 3;
                } else if (this.a(32)) {
                    if (this.h) {
                        this.bu = 0;
                        this.bt = 8;
                        l = (byte)9;
                        this.h = false;
                    } else {
                        this.aO = 3;
                    }
                } else {
                    ++this.ep;
                }
                n3 = -this.ep;
                boolean bl = false;
                for (n = 0; n < s.length && n3 <= -225; ++n) {
                    if (s[n] != 10) continue;
                    n3 += 15;
                }
                this.eq = n;
                if (this.eq < s.length) break;
                this.eq = 0;
                this.ep = 0;
                return;
            }
            case 3: {
                s = null;
                System.gc();
                l = (byte)4;
                this.aO = 2;
                this.a(0);
                this.a.c(4);
                this.a.d();
            }
        }
    }

    public final void cB() {
        if (this.aO != 2) {
            return;
        }
        Graphics graphics = a;
        graphics.setColor(0, 0, 0);
        graphics.fillRect(0, 0, 176, 208);
        int n = 0;
        int n2 = -15;
        int n3 = this.eq;
        boolean bl = false;
        int n4 = 0;
        n4 = this.ep >= 225 ? -(this.ep % 15) : 225 - this.ep - 15;
        for (int i2 = this.eq; i2 < s.length && n2 < 225; ++i2) {
            if (s[i2] != 10) continue;
            k.a[41].m = 0;
            this.a(graphics, s, a[41], n3, i2 - n3, n2 + n4, null, 0, 170);
            n2 += 15;
            n3 = i2 + 1;
        }
        n = 0;
        for (int i3 = 6; i3 > 0; --i3) {
            graphics.setColor(0);
            graphics.fillRect(0, n, 176, i3);
            graphics.fillRect(0, 208 - n - i3, 176, i3);
            n += i3 + 1;
        }
        this.ag();
    }

    public final void cC() {
        if (er > 0) {
            er = (int)((long)er - (System.currentTimeMillis() - this.q));
            this.q = System.currentTimeMillis();
            if (er <= 0) {
                this.c(true);
            }
        }
    }

    public final void a(String string, int n, int n2, int n3, int n4, int n5) {
        this.q = System.currentTimeMillis();
        er = n3;
        this.es = n;
        this.et = n2;
        this.g = k.a(string, 156);
        this.eu = n4;
        this.ev = n5;
    }

    public final void c(boolean bl) {
        er = 0;
        if (bl) {
            this.au = true;
        }
    }

    public final boolean h() {
        return er > 0;
    }

    public final void cD() {
        b b2 = a[41];
        if (er <= 0) {
            return;
        }
        int n = b2.p;
        b2.p = 3;
        b2.a(this.g);
        int n2 = b.o;
        int n3 = b.n;
        if (this.es == -1) {
            this.es = 176 - n3 >> 1;
        }
        if (this.et == -1) {
            this.et = 208 - n2 >> 1;
        }
        k.a(a, this.es - 6, this.et - 3, n3 + 12, n2 + 6);
        k.b(a, this.es - 6, this.et - 3, n3 + 12, n2 + 6, this.eu, this.ev);
        b2.b(a, this.g, this.es, this.et, 0);
        b2.p = n;
    }

    public static final String a(String string, int n) {
        b b2 = a[41];
        boolean bl = false;
        int n2 = 0;
        boolean bl2 = false;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        StringBuffer stringBuffer = new StringBuffer(string);
        for (int i2 = 0; i2 <= stringBuffer.length(); ++i2) {
            int n6;
            int n7 = 10;
            if (i2 < stringBuffer.length()) {
                n7 = stringBuffer.charAt(i2) & 0xFF;
            }
            if (n2 > n && n3 != n5) {
                n2 = n4;
                stringBuffer.setCharAt(n3, '\n');
                i2 = n3 - 1;
                n5 = n3;
                continue;
            }
            if (n7 == 10) {
                n2 = 0;
                continue;
            }
            if (n7 > 32) {
                if (n7 == 64) {
                    n2 += 14;
                    continue;
                }
            } else {
                if (n7 != 32) continue;
                n3 = i2;
                n4 = n2;
                n2 += (b2.a[0] & 0xFF) + b2.d[1];
                continue;
            }
            n7 = b.h[n7] & 0xFF;
            if (n7 >= b2.b(0)) {
                n6 = n7 - b2.b(0);
                n2 += (b2.c[(n6 << 2) + 2] & 0xFF) - (b2.c[n6 << 2] & 0xFF) + b2.d[1];
                continue;
            }
            n6 = (b2.d[n7 << 2] & 0xFF) << 1;
            n2 += (b2.a[n6] & 0xFF) - b2.d[(n7 << 2) + 1] + b2.d[1];
        }
        return stringBuffer.toString();
    }

    public final void cE() {
        if (a[41] != null) {
            k.a[41] = null;
            System.gc();
        }
        k.a[41] = new b();
        byte[] byArray = k.a("/ui.f", 1);
        a[41].a(byArray, 0);
        a[41].a(0, 0, -1, -1);
        a[41].a(1, 0, -1, -1);
        a[41].a(2, 0, -1, -1);
        k.a[41].g = null;
    }

    public static final int a(Graphics graphics) {
        if (graphics == a) {
            return 0;
        }
        if (b != null && graphics == b) {
            return 1;
        }
        if (d != null && graphics == d) {
            return 2;
        }
        if (c != null && graphics == c) {
            return 3;
        }
        graphics.setColor(255, 0, 0);
        graphics.drawRect(0, 0, 20, 20);
        graphics.drawRect(0, 0, 120, 120);
        System.out.print("UNKNOWN Graphics!!!");
        return -1;
    }

    public static final void a(Graphics graphics, f f2, int n, int n2, int n3) {
        f2.a(graphics, n, n2, n3, 0, true);
    }

    public static final void a(Graphics graphics, Image image, int n, int n2, int n3) {
        int n4 = k.a(graphics);
        if (n4 != -1) {
            graphics.drawImage(image, n + g[n4], n2 + h[n4], n3);
            return;
        }
        graphics.drawImage(image, n, n2, n3);
    }

    public static final void cF() {
        c = new int[4];
        d = new int[4];
        e = new int[4];
        f = new int[4];
        g = new int[4];
        h = new int[4];
        for (int i2 = 0; i2 < 4; ++i2) {
            k.c[i2] = 0;
            k.d[i2] = 0;
            k.e[i2] = 176;
            k.f[i2] = 208;
            k.g[i2] = 0;
            k.h[i2] = 0;
        }
    }

    public static final void a(Graphics graphics, int n, int n2, int n3, int n4) {
        int n5;
        if (c == null) {
            k.cF();
        }
        if ((n5 = k.a(graphics)) != -1) {
            if (n5 == 1) {
                graphics.setClip(0, 0, 176, 208);
                graphics.clipRect(n + g[n5], n2 + h[n5], n3, n4);
                return;
            }
            int n6 = n + g[n5] >= 0 ? n : 0;
            int n7 = n6 + n3 <= 176 ? n3 : 176 - n6;
            graphics.setClip(n6, n2 + h[n5], n7, n4);
            return;
        }
        graphics.setClip(n, n2, n3, n4);
        System.out.print("Clipping on unknown Graphics!!!");
    }

    public static final void a(Graphics graphics, int n, int n2) {
        int n3;
        if (c == null) {
            k.cF();
        }
        if ((n3 = k.a(graphics)) != -1) {
            int n4 = n3;
            g[n4] = g[n4] + n;
            int n5 = n3;
            h[n5] = h[n5] + n2;
            return;
        }
        System.out.print("Translating on unknown Graphics!!!");
    }

    public static final a a(String string) {
        return new a(string);
    }

    static {
        new String("Nokia6600/3");
        a = false;
        a = new boolean[]{true, false, false};
        b = new boolean[]{false, false, false};
        a = new byte[16];
        b = new byte[8];
        c = new byte[8];
        l = 0;
        g = new byte[]{0, 0, -1, 0, 1, 0, 0, 0, 0, 1, 0, -1, 0, 0, 0, 0};
        h = new byte[]{0, 3, 4, 1, 2, 5, 6};
        i = null;
        j = null;
        a = null;
        p = null;
        E = false;
        a = null;
        b = null;
        cC = 0;
        cD = 0;
        cE = -1;
        cF = -1;
        cG = -1;
        cH = -1;
        a = null;
        cM = 0;
        cN = 0;
        cO = 0;
        b = null;
        T = false;
        U = true;
        int[] nArray = new int[]{512, 16384, 131072, 131072, 4096};
        df = 0;
        dg = 0;
        dh = 0;
        q = new byte[16];
        r = new byte[16];
        ai = false;
        a = new long[15];
        b = new long[15];
        a = new short[][]{{0, 0, 1, 1, 6, 3, 2, 2, 3, 4, 4, 5, 5, 6}, {0, 25, 1, 26, 2, 2, 6, 4, 3, 49, 4, 27, 5, 6}, {0, 28, 1, 29, 2, 30, 3, 31}, {0, 32, 1, 33}, {0, 45, 1, 46}, {0, 33, 1, 50}, {0, 25, 4, 27}, {0, 101, 1, 100}};
        b = new int[]{28, 29, 30};
        g = new int[][]{{8, 9, 10, 11, 12, 14, 15, 16, 17, 20, 21, 22, 23}, {8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 20, 21, 22}, {8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 47}};
        s = null;
        b = new String[]{"/w0.bin", "/w1.bin", "/w2.bin"};
        er = 0;
        c = null;
        d = null;
        e = null;
        f = null;
        g = null;
        h = null;
    }
}
