/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 */
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class g {
    public static Image[] a;
    public static b a;
    public static b b;
    public static String[] a;
    public static String[] b;
    public static int a;
    public static int b;
    public static int c;
    public boolean a;
    public int d;

    public g() {
        a = new Image[5];
        a = new String[5];
    }

    public static final void a(String string) {
        if (string == null) {
            return;
        }
        try {
            if (k.a.platformRequest(string)) {
                k.a.destroyApp(true);
            }
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final void a() {
        int n;
        b = k.a[41];
        g.b.p = 1;
        a = k.a("/tips.f", 0);
        if (b == null) {
            n = 0;
            b = k.a.a("/lang_IGA.f", 15);
            g.b[7] = k.a(b[7], 106);
            g.b[8] = k.a(b[8], 106);
            g.b[9] = k.a(b[9], 106);
        }
        n = 10;
        int n2 = 0;
        while (n <= 14) {
            g.a[n2] = k.a.getAppProperty(b[n]);
            if (a[n2] != null && (a[n2].compareTo("no") == 0 || a[n2].compareTo("") == 0)) {
                g.a[n2] = null;
            }
            ++n;
            ++n2;
        }
        g.b[3] = b[3] + "\n\u0001\u0001" + b[4] + "\n\u0001\u0000" + b[5];
        g.b[7] = new String("\u0001\u0000" + b[7]);
        try {
            for (n = 0; n < 4; ++n) {
                g.a[n] = Image.createImage((byte[])a.a("/ad" + (n + 1)), (int)0, (int)a.a("/ad" + (n + 1)));
            }
            k.a[0] = new i(k.a("/ui.f", 0), 0, 0, null);
        }
        catch (Exception exception) {}
        a = 0;
        k.z(3);
    }

    public final void a(int n) {
        if ((a += n) == 3 && a[a] == null) {
            a += n;
        }
        if (a < 0) {
            a = 4;
            return;
        }
        if (a == 5) {
            a = 0;
        }
    }

    public final void a(Graphics graphics, int n) {
        if (a[a] == null) {
            return;
        }
        if (b % 30 < 15) {
            return;
        }
        String string = a >= 3 ? b[8] : b[9];
        b.a(string);
        int n2 = b.n + 2;
        int n3 = b.a(string);
        int n4 = n != 0 ? (208 + n >> 1) - ((n3 >> 1) + 4) : 104 - (n3 >> 1);
        k.a(graphics, 0, 0, 176, 208);
        graphics.setColor(0xFF0000);
        graphics.fillRect(88 - (n2 >> 1) - 4, n4 - 4, n2 + 8, n3 + 8);
        b.b(graphics, string, 88, n4, 1);
    }

    public final void a(Graphics graphics) {
        boolean bl = false;
        boolean bl2 = false;
        boolean bl3 = false;
        boolean bl4 = false;
        boolean bl5 = false;
        boolean bl6 = false;
        boolean bl7 = false;
        boolean bl8 = false;
        boolean bl9 = false;
        int n = 99;
        boolean bl10 = false;
        int n2 = 189;
        k.a(graphics, 0, 0, 176, 208);
        for (int i2 = 0; i2 < 16; ++i2) {
            graphics.setColor(n << 16 | 0 | n2);
            graphics.fillRect(0, 104 + 104 * i2 / 16, 176, 14);
            graphics.fillRect(0, 104 - 104 * (i2 + 1) / 16, 176, 14);
            n -= 4;
            n2 -= 8;
        }
    }

    public final void b(Graphics graphics) {
        this.a(graphics);
        int n = 0;
        switch (a) {
            case 4: {
                i i2 = k.a[0];
                i2.a.a(graphics, 11, 88, 7, 0, 0, 0);
                b.b(graphics, "\n\u0001\u0002" + b[6], 88, 28, 17);
                b.b(graphics, b[7], 88, 101, 3);
                b.a(b[7]);
                n = 104 + (b.o >> 1) + 4;
                break;
            }
            case 3: {
                graphics.drawImage(a[a], 88, 5, 17);
                b.b(graphics, b[3], 88, 104, 3);
                b.a(b[3]);
                n = 104 + (b.o >> 1) + 4;
                break;
            }
            default: {
                graphics.drawImage(a[a], 88, 176, 33);
                b.b(graphics, b[a], 88, 178, 17);
                n = 0;
            }
        }
        k.a.ag();
        if (a[a] != null) {
            k.a.ah();
        }
        this.a(graphics, n);
        if (k.a.a(16388)) {
            this.a(-1);
        } else if (k.a.a(65544)) {
            this.a(1);
        } else if (k.a.a(32848)) {
            g.a(a[a]);
        } else if (k.a.a(32)) {
            k.a.a(0);
            c = 2;
            k.W = 0;
        }
        a.a(graphics, k.a.a(16388) ? 2 : 0, b % a.a(0), 20 + this.d, 104, 0, 0, 0);
        a.a(graphics, k.a.a(65544) ? 3 : 1, b % a.a(1), 156 - this.d, 104, 0, 0, 0);
        this.d += this.a ? -1 : 1;
        if (this.d > 3 || this.d < 1) {
            this.a = !this.a;
        }
        k.W = 0;
    }

    public final void b() {
        int n = 0;
        int n2 = a.length;
        for (n = 0; n < n2; ++n) {
            g.a[n] = null;
        }
        a = null;
        n2 = a.length;
        for (n = 0; n < n2; ++n) {
            g.a[n] = null;
        }
        a = null;
        n2 = b.length;
        for (n = 0; n < n2; ++n) {
            g.b[n] = null;
        }
        b = null;
        b = null;
        a = null;
        c = 0;
        System.gc();
    }
}
