/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 */
import java.io.ByteArrayInputStream;
import javax.microedition.lcdui.Graphics;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class d {
    public static long a = 1000L;
    public static String a = "/demoSpr.bin";
    public static String b = "/demo.f";
    public static b[] a = null;
    public byte[][] a;
    public int a;
    public long b;
    public byte[] a;
    public int b;
    public boolean a;
    public int c = 0;
    public int d = 0;
    public int e = 0;
    public int f = 0;
    public int g = -1;
    public boolean b = false;
    public k a;
    public final short[] a = new short[16];
    public int h;

    public d(k k2) {
        this.a = k2;
    }

    public final void a(Graphics graphics, byte[] byArray, int n, int n2) {
        if (byArray == null) {
            return;
        }
        byte by = byArray[n + 0];
        switch (by) {
            case 18: {
                if (byArray[n + 7] == 0) break;
                int n3 = (byArray[n + 3] & 0xFF) + ((byArray[n + 3 + 1] & 0xFF) << 8) + ((byArray[n + 3 + 2] & 0xFF) << 16);
                graphics.setColor(n3);
                graphics.fillRect(0, 0, 176, 208);
                return;
            }
            case 12: {
                int n4 = this.b;
                graphics.setColor(0xFFFFFF);
                if (n4 > 5) {
                    n4 = 5;
                }
                int n5 = this.a.aR * 24;
                int n6 = this.a.aS * 24;
                int n7 = this.c;
                int n8 = this.d;
                graphics.fillRect(((n5 - this.a.ar) * (5 - n4) + n7 * n4) / 5, ((n6 - this.a.as) * (5 - n4) + n8 * n4) / 5, 102 * n4 / 5, 38 * n4 / 5);
                return;
            }
            case 1: {
                int n9 = this.b;
                short s = (short)k.a(byArray, n + 2);
                short s2 = (short)k.a(byArray, n + 4);
                short s3 = (short)k.a(byArray, n + 6);
                short s4 = (short)k.a(byArray, n + 8);
                short s5 = (short)k.a(byArray, n + 10);
                if (s4 == 10000) {
                    s4 = (short)this.a.av;
                }
                if (s5 == 10000) {
                    s5 = (short)this.a.aw;
                }
                if (n9 > s3) {
                    n9 = s3;
                }
                s = (short)(s - 76);
                s2 = (short)(s2 - 78);
                this.a.av = (short)((s * n9 + s4 * (s3 - n9)) / s3);
                this.a.aw = (short)((s2 * n9 + s5 * (s3 - n9)) / s3);
                if (this.a.au > 0) {
                    --this.a.au;
                } else if (this.a.au < 0) {
                    ++this.a.au;
                }
                if (this.a.at > 0) {
                    --this.a.at;
                } else if (this.a.at < 0) {
                    ++this.a.at;
                }
                int n10 = this.a.ax * 24 - 176;
                int n11 = this.a.ay * 24 - 208 + 28;
                if (this.a.av > n10) {
                    this.a.av = n10;
                } else if (this.a.av < 0) {
                    this.a.av = 0;
                }
                if (this.a.aw > n11) {
                    this.a.aw = n11;
                } else if (this.a.aw < 0) {
                    this.a.aw = 0;
                }
                this.a.ar = this.a.av + this.a.at;
                this.a.as = this.a.aw + this.a.au;
                if (this.a.ar > n10) {
                    this.a.ar -= n10 - this.a.at;
                } else if (this.a.ar < 0) {
                    this.a.ar += this.a.at;
                }
                if (this.a.as > n11) {
                    this.a.as = n11 - this.a.au;
                    return;
                }
                if (this.a.as >= 0) break;
                this.a.as += this.a.au;
                return;
            }
            case 13: {
                int n12 = this.b;
                short s = (short)k.a(byArray, n + 2);
                short s6 = (short)k.a(byArray, n + 4);
                short s7 = (short)k.a(byArray, n + 6);
                short s8 = (short)k.a(byArray, n + 8);
                short s9 = (short)k.a(byArray, n + 10);
                if (n12 > s7) {
                    n12 = s7;
                }
                short s10 = (short)((s * n12 + s8 * (s7 - n12)) / s7);
                short s11 = (short)((s6 * n12 + s9 * (s7 - n12)) / s7);
                if (by != 13) break;
                this.c = s10;
                this.d = s11;
                return;
            }
            case 4: {
                int n13 = this.b;
                short s = (short)k.a(byArray, n + 2);
                short s12 = (short)k.a(byArray, n + 4);
                short s13 = (short)k.a(byArray, n + 6);
                short s14 = (short)k.a(byArray, n + 6);
                short s15 = (short)k.a(byArray, n + 14);
                if (n13 > s15) {
                    n13 = s15;
                }
                short s16 = (short)((s13 * n13 + s * (s15 - n13)) / s15);
                short s17 = (short)((s14 * n13 + s12 * (s15 - n13)) / s15);
                short s18 = (short)k.a(byArray, n + 10);
                short s19 = (short)k.a(byArray, n + 12);
                a[s18].a(graphics, s19, s16, s17, 0, 0, 0);
                return;
            }
            case 27: {
                k.a[41].p = 2;
                int n14 = byArray[n + 6] & 0xFF;
                k.a(graphics, 8, 135, 162, 35, 73, 1, k.a(k.a[41], k.a[70], 0) + 10, 15);
                String string = null;
                try {
                    string = new String(byArray, n + 8, (int)((short)k.a(byArray, n + 2)), "ISO-8859-1");
                }
                catch (Exception exception) {}
                this.a(string, 136);
                this.a(graphics, string, 20, 139, 136, n14, n14 + 2);
                k.a[41].a(graphics, k.a[70], 23, 120, 20);
                if ((k.aQ << 1) % 2 != 0) break;
                k.a(graphics, k.b[0][9], 160, 126, 17);
                return;
            }
            case 2: {
                k.a[41].p = 2;
                short s = (short)k.a(byArray, n + 6);
                int n15 = k.a(byArray, n + 4);
                if (n15 == 10000) {
                    n15 = -176;
                }
                int n16 = byArray[n + 8] & 0xFF;
                int n17 = byArray[n + 9] & 0xFF;
                int n18 = n16 * this.a.a(k.a[41]) + 12 - 2;
                k.b(graphics, n15, s, 164, n18, 73, 0);
                String string = null;
                try {
                    string = new String(byArray, n + 11, (int)((short)k.a(byArray, n + 2)), "ISO-8859-1");
                }
                catch (Exception exception) {}
                this.a(string, 150);
                this.a(graphics, string, n15 + 6 - 3, s + 6, 150, n17, n17 + n16);
                if (this.b / 2 % 2 == 0) {
                    k.a(graphics, k.b[0][9], n15 + 162 - 10, s + n18 - 5, 17);
                }
                k.a(graphics, 0, 0, 176, 208);
            }
        }
    }

    public final void a(byte[] byArray, int n, int n2) {
        short s = byArray[n + 0];
        switch (s) {
            case 7: {
                byArray[n + 1] = 1;
                return;
            }
            case 27: {
                if (k.E) {
                    return;
                }
                String string = null;
                try {
                    string = new String(byArray, n + 8, (int)((short)k.a(byArray, n + 2)), "ISO-8859-1");
                }
                catch (Exception exception) {}
                this.a(string, 136);
                short s2 = (short)(byArray[n + 6] & 0xFF);
                boolean bl = false;
                if (s2 + 2 >= this.h) {
                    byArray[n + 7] = 1;
                    return;
                }
                byArray[n + 6] = (byte)(s2 + 2);
                return;
            }
            case 2: {
                String string = null;
                try {
                    string = new String(byArray, n + 11, (int)((short)k.a(byArray, n + 2)), "ISO-8859-1");
                }
                catch (Exception exception) {}
                this.a(string, 150);
                short s3 = (short)(byArray[n + 9] & 0xFF);
                short s4 = (short)(byArray[n + 8] & 0xFF);
                if (s3 + s4 >= this.h) {
                    byArray[n + 10] = 1;
                    return;
                }
                byArray[n + 9] = (byte)(s3 + s4);
            }
        }
    }

    public final void a() {
        if (this.a == null) {
            return;
        }
        if (Math.abs(this.b - System.currentTimeMillis()) < a) {
            return;
        }
        if (this.a[0] == 0) {
            int n = this.a[1];
            int n2 = 2 + n * 4;
            for (int i2 = 0; i2 < n; ++i2) {
                int n3 = k.b(this.a, 2 + i2 * 4);
                this.a(this.a, n2, n3);
                n2 += n3;
            }
        } else {
            this.a(this.a, 0, this.a.length);
        }
    }

    public final void a(Graphics graphics) {
        if (this.b) {
            return;
        }
        switch (this.a()) {
            case 25: 
            case 26: {
                if (this.a != null && this.a < this.a.length) break;
                return;
            }
            default: {
                graphics.setColor(0);
                graphics.fillRect(0, 0, 176, 30);
                graphics.fillRect(0, 178, 176, 30);
                k.a[41].a(graphics, k.a[53], 5, 203, 36);
            }
        }
        if (this.a[0] == 0) {
            int n = this.a[1];
            int n2 = 2 + n * 4;
            for (int i2 = 0; i2 < n; ++i2) {
                int n3 = k.b(this.a, 2 + i2 * 4);
                this.a(graphics, this.a, n2, n3);
                n2 += n3;
            }
        } else {
            this.a(graphics, this.a, 0, this.a.length);
        }
        if (this.a) {
            graphics.setColor(0);
            graphics.fillRect(this.c - 3, this.d - 3, 109, 45);
            a[this.f].a(graphics, 0, this.b % a[this.f].a(0), this.c, this.d, 0, 0, 0);
            a[0].a(graphics, this.e, this.c + 0, this.d, 0, 0, 0);
            if (this.g >= 0) {
                a[1].a(graphics, this.g, this.c + 90, this.d + -6, 0, 0, 0);
            }
        }
    }

    public final byte[] a() {
        this.a(this.a);
        this.a = false;
        this.c = 0;
        this.d = 0;
        this.e = 0;
        this.f = 0;
        this.g = -1;
        this.b = false;
        this.a = 0;
        this.b = System.currentTimeMillis();
        return this.b();
    }

    public final void b(byte[] byArray, int n, int n2) {
        if (byArray[n + 0] != 0) {
            byArray[n + 1] = 0;
            switch (byArray[n + 0]) {
                case 27: {
                    byArray[n + 6] = 0;
                    d.a(byArray, n + 4, (short)-176);
                    byArray[n + 7] = 0;
                    break;
                }
                case 2: {
                    byArray[n + 9] = 0;
                    d.a(byArray, n + 4, (short)-176);
                    byArray[n + 10] = 0;
                }
            }
            return;
        }
        int n3 = byArray[n + 1];
        int n4 = n + 2 + n3 * 4;
        for (int i2 = 0; i2 < n3; ++i2) {
            int n5 = k.b(byArray, n + 2 + i2 * 4);
            this.b(byArray, n4, n5);
            n4 += n5;
        }
    }

    public final void a(byte[][] byArray) {
        for (int i2 = 0; i2 < byArray.length; ++i2) {
            this.b(byArray[i2], 0, byArray[i2].length);
        }
    }

    public final byte[] b() {
        this.b = 0;
        this.a = (byte[])(this.a == null || this.a >= this.a.length ? null : this.a[this.a++]);
        return this.a;
    }

    public final void b() {
        if (this.a[0] == 0) {
            int n = this.a[1];
            int n2 = 2 + n * 4;
            for (int i2 = 0; i2 < n; ++i2) {
                int n3 = k.b(this.a, 2 + i2 * 4);
                this.c(this.a, n2, n3);
                n2 += n3;
            }
        } else {
            this.c(this.a, 0, this.a.length);
        }
        ++this.b;
    }

    public final void c(byte[] byArray, int n, int n2) {
        short s = byArray[n + 0];
        if (this.b) {
            switch (s) {
                case 5: 
                case 9: 
                case 10: 
                case 25: 
                case 26: {
                    break;
                }
                default: {
                    byArray[n + 1] = 1;
                    return;
                }
            }
        }
        switch (s) {
            case 16: 
            case 17: 
            case 18: {
                boolean bl;
                if (this.b % 2 == 0) {
                    return;
                }
                int n3 = n + (s == 18 ? 2 : 4);
                byte by = byArray[n3];
                int n4 = -1;
                int n5 = n + (s == 18 ? 7 : 5);
                boolean bl2 = bl = byArray[n5] != 0;
                if (s != 18) {
                    n4 = (short)k.a(byArray, n + 2);
                }
                if (bl) {
                    bl = false;
                    this.g = -1;
                    if ((by = (byte)(by - 1)) == 0) {
                        byArray[n + 1] = 1;
                        if (s != 18) {
                            this.g = s == 16 ? n4 : -1;
                        }
                    }
                } else if (by > 0) {
                    bl = true;
                    if (s != 18) {
                        this.g = n4;
                    }
                } else {
                    byArray[n + 1] = 1;
                }
                byArray[n5] = (byte)(bl ? 1 : 0);
                byArray[n3] = by;
                return;
            }
            case 14: 
            case 15: {
                this.a = s == 14;
                byArray[n + 1] = 1;
                return;
            }
            case 12: {
                short s2 = (short)k.a(byArray, n + 2);
                short s3 = (short)k.a(byArray, n + 4);
                this.c = s2;
                this.d = s3;
                if (this.b <= 5) break;
                byArray[n + 1] = 1;
                this.a = true;
                return;
            }
            case 11: {
                this.f = (short)k.a(byArray, n + 4);
                this.e = (short)k.a(byArray, n + 2);
                byArray[n + 1] = 1;
                return;
            }
            case 10: {
                byte by = byArray[n + 2];
                if (this.b == 0) {
                    this.a.aU = this.a.aU & 0xFFFFFFF8 | by;
                    this.a.j = by;
                } else if (this.a.aT <= 0) {
                    this.a.j = 0;
                    byArray[n + 1] = 1;
                }
                this.a.bq();
                return;
            }
            case 13: {
                short s4;
                if ((short)k.a(byArray, n + 8) == 10000) {
                    d.a(byArray, n + 8, (short)this.c);
                }
                if ((short)k.a(byArray, n + 10) == 10000) {
                    d.a(byArray, n + 10, (short)this.d);
                }
                if (this.b <= (s4 = (short)k.a(byArray, n + 6))) break;
                byArray[n + 1] = 1;
                return;
            }
            case 1: {
                short s5;
                if ((short)k.a(byArray, n + 8) == 10000) {
                    d.a(byArray, n + 8, (short)this.a.av);
                }
                if ((short)k.a(byArray, n + 10) == 10000) {
                    d.a(byArray, n + 10, (short)this.a.aw);
                }
                if (this.b <= (s5 = (short)k.a(byArray, n + 6))) break;
                byArray[n + 1] = 1;
                return;
            }
            case 4: {
                short s6 = (short)k.a(byArray, n + 14);
                if (this.b <= s6) break;
                byArray[n + 1] = 1;
                return;
            }
            case 6: {
                if (this.b <= k.b(byArray, n + 2)) break;
                byArray[n + 1] = 1;
                return;
            }
            case 25: {
                short s7 = (short)k.a(byArray, n + 2);
                short s8 = (short)k.a(byArray, n + 4);
                byte by = byArray[n + 6];
                byte by2 = byArray[n + 7];
                k.a[s7][s8] = by2 << 8 | by;
                byArray[n + 1] = 1;
                return;
            }
            case 26: {
                int n6;
                short s9 = (short)k.a(byArray, n + 2);
                short s10 = (short)k.a(byArray, n + 4);
                k.b[s9][s10] = n6 = k.b(byArray, n + 6);
                byArray[n + 1] = 1;
                return;
            }
            case 5: {
                this.a.a((short)k.a(byArray, n + 2), (short)k.a(byArray, n + 4), byArray[n + 6], 0);
                byArray[n + 1] = 1;
                return;
            }
            case 8: {
                return;
            }
            case 9: {
                this.a.a((short)k.a(byArray, n + 2), (short)k.a(byArray, n + 4), (byte)0, (int)((short)k.a(byArray, n + 6)));
                byArray[n + 1] = 1;
                return;
            }
            case 27: {
                if (byArray[n + 7] == 0) break;
                byArray[n + 1] = 1;
                return;
            }
            case 2: {
                short s11 = (short)k.a(byArray, n + 4);
                if (s11 == 10000) {
                    s11 = -162;
                }
                s11 = (short)(s11 + 30);
                if (byArray[n + 10] == 0) {
                    if (s11 > 7) {
                        s11 = 7;
                    }
                } else if (s11 > 176) {
                    byArray[n + 1] = 1;
                }
                d.a(byArray, n + 4, s11);
            }
        }
    }

    public final boolean a() {
        boolean bl = true;
        if (this.a[0] == 0) {
            int n = this.a[1];
            int n2 = 2 + n * 4;
            for (int i2 = 0; i2 < n; ++i2) {
                int n3 = k.b(this.a, 2 + i2 * 4);
                if (bl = bl && this.a[n2 + 1] == 1) {
                    n2 += n3;
                    continue;
                }
                break;
            }
        } else {
            bl = this.a[1] == 1;
        }
        return bl;
    }

    public final byte a() {
        if (this.a == null) {
            return -1;
        }
        return this.a[0];
    }

    public final void a(int n) {
        try {
            this.a.getClass();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(k.a(b, 0));
            byte[] byArray = new byte[4];
            byteArrayInputStream.read(byArray, 0, 2);
            boolean bl = false;
            do {
                int n2;
                byteArrayInputStream.read(byArray, 0, 2);
                short s = (short)k.a(byArray, 0);
                if (s == n) {
                    int n3;
                    short s2;
                    int n4;
                    int n5;
                    int n6;
                    Object object;
                    int n7;
                    int n8;
                    Object object2;
                    byteArrayInputStream.read(byArray, 0, 2);
                    n2 = k.a(byArray, 0);
                    byteArrayInputStream.read(byArray, 0, 4);
                    int n9 = k.b(byArray, 0);
                    byArray = new byte[n9];
                    byteArrayInputStream.read(byArray);
                    byteArrayInputStream.close();
                    byteArrayInputStream = null;
                    bl = true;
                    int n10 = 0;
                    int n11 = k.a(byArray, 0);
                    n10 += 2;
                    if (n11 != 0) {
                        object2 = new short[n11];
                        for (n8 = 0; n8 < n11; ++n8) {
                            object2[n8] = (short)k.a(byArray, n10);
                            n10 += 2;
                        }
                        for (n7 = 1; n7 < n11; ++n7) {
                            n8 = object2[n7];
                            for (int i2 = n7; i2 > 0 && object2[i2 - 1] > n8; --i2) {
                                object2[i2] = object2[i2 - 1];
                            }
                            object2[i2] = n8;
                        }
                        a a2 = k.a(a);
                        object = new byte[4];
                        a2.a((byte[])object, 0, 2);
                        n6 = (short)k.a(object, 0);
                        if (a == null) {
                            a = new b[n6];
                        }
                        for (n5 = 0; n5 < n11; ++n5) {
                            n4 = object2[n5];
                            boolean bl2 = false;
                            while (!bl2) {
                                a2.a((byte[])object, 0, 2);
                                s2 = (short)k.a(object, 0);
                                if (n4 == s2) {
                                    bl2 = true;
                                }
                                a2.a((byte[])object, 0, 4);
                                n3 = k.b(object, 0);
                                if (!bl2 && a[n4] != null) {
                                    a2.a(n3);
                                    continue;
                                }
                                object = new byte[n3];
                                a2.a((byte[])object);
                                d.a[n4] = new b();
                                a[n4].a((byte[])object, 0);
                                a[n4].a(0, 0, -1, -1);
                                d.a[n4].g = null;
                            }
                        }
                        a2.a();
                    }
                    object2 = new byte[n2][];
                    n8 = 0;
                    Object object3 = null;
                    n7 = 0;
                    n6 = 0;
                    for (n5 = 0; n5 < n2 || n6 != 0; ++n5) {
                        int n12;
                        if (n6 == 0) {
                            object = object2;
                        } else {
                            object = object3;
                            --n6;
                            --n5;
                        }
                        n4 = byArray[n10++] & 0xFF;
                        byte[] byArray2 = null;
                        switch (n4) {
                            case 18: {
                                s2 = (short)(byArray[n10++] & 0xFF);
                                n3 = (byArray[n10++] & 0xFF) + ((byArray[n10++] & 0xFF) << 8) + ((byArray[n10++] & 0xFF) << 16);
                                byArray2 = new byte[8];
                                d.a(byArray2, 2, s2);
                                d.d(byArray2, 3, n3);
                                byArray2[7] = 0;
                                break;
                            }
                            case 16: 
                            case 17: {
                                n12 = k.a(byArray, n10);
                                n10 += 2;
                                s2 = (short)(byArray[n10++] & 0xFF);
                                byArray2 = new byte[6];
                                d.a(byArray2, 2, (short)n12);
                                d.a(byArray2, 4, s2);
                                byArray2[5] = 0;
                                break;
                            }
                            case 11: {
                                n12 = (short)k.a(byArray, n10);
                                short s3 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[6];
                                d.a(byArray2, 2, (short)n12);
                                d.a(byArray2, 4, s3);
                                break;
                            }
                            case 12: {
                                short s4 = (short)k.a(byArray, n10);
                                short s5 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[6];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                break;
                            }
                            case 13: {
                                short s4 = (short)k.a(byArray, n10);
                                short s5 = (short)k.a(byArray, n10 += 2);
                                short s6 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[12];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                d.a(byArray2, 6, s6);
                                d.a(byArray2, 8, (short)10000);
                                d.a(byArray2, 10, (short)10000);
                                break;
                            }
                            case 14: 
                            case 15: {
                                byArray2 = new byte[2];
                                break;
                            }
                            case 4: {
                                short s7 = (short)k.a(byArray, n10);
                                short s8 = (short)k.a(byArray, n10 += 2);
                                short s9 = (short)k.a(byArray, n10 += 2);
                                short s10 = (short)k.a(byArray, n10 += 2);
                                short s11 = (short)k.a(byArray, n10 += 2);
                                n12 = (short)k.a(byArray, n10 += 2);
                                short s6 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[16];
                                d.a(byArray2, 2, s7);
                                d.a(byArray2, 4, s8);
                                d.a(byArray2, 6, s9);
                                d.a(byArray2, 8, s10);
                                d.a(byArray2, 10, s11);
                                d.a(byArray2, 12, (short)n12);
                                d.a(byArray2, 14, s6);
                                break;
                            }
                            case 7: {
                                byArray2 = new byte[2];
                                break;
                            }
                            case 1: {
                                short s4 = (short)(k.a(byArray, n10) * 24);
                                short s5 = (short)(k.a(byArray, n10 += 2) * 24);
                                short s6 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[12];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                d.a(byArray2, 6, s6);
                                d.a(byArray2, 8, (short)10000);
                                d.a(byArray2, 10, (short)10000);
                                break;
                            }
                            case 6: {
                                int n13 = k.b(byArray, n10);
                                n10 += 4;
                                byArray2 = new byte[6];
                                d.d(byArray2, 2, n13);
                                break;
                            }
                            case 26: {
                                short s4 = (short)k.a(byArray, n10);
                                short s5 = (short)k.a(byArray, n10 += 2);
                                int n14 = k.b(byArray, n10 += 2);
                                n10 += 4;
                                byArray2 = new byte[10];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                d.d(byArray2, 6, n14);
                                break;
                            }
                            case 25: {
                                short s4 = (short)k.a(byArray, n10);
                                short s5 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                short s12 = (short)(byArray[n10++] & 0xFF);
                                short s13 = (short)(byArray[n10++] & 0xFF);
                                byArray2 = new byte[8];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                byArray2[6] = (byte)s12;
                                byArray2[7] = (byte)s13;
                                break;
                            }
                            case 5: {
                                short s4 = (short)k.a(byArray, n10);
                                short s5 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                short s12 = (short)(byArray[n10++] & 0xFF);
                                byArray2 = new byte[7];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                byArray2[6] = (byte)s12;
                                break;
                            }
                            case 27: {
                                short s14 = (short)k.a(byArray, n10);
                                n10 += 2;
                                byArray2 = new byte[8 + s14];
                                d.a(byArray2, 2, s14);
                                d.a(byArray2, 4, (short)10000);
                                byArray2[6] = 0;
                                byArray2[7] = 0;
                                System.arraycopy(byArray, n10, byArray2, 8, s14);
                                n10 += s14;
                                break;
                            }
                            case 2: {
                                short s15 = (short)(byArray[n10++] & 0xFF);
                                short s5 = (short)k.a(byArray, n10);
                                short s14 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[11 + s14];
                                d.a(byArray2, 2, s14);
                                d.a(byArray2, 4, (short)10000);
                                d.a(byArray2, 6, s5);
                                byArray2[8] = (byte)s15;
                                byArray2[9] = 0;
                                byArray2[10] = 0;
                                System.arraycopy(byArray, n10, byArray2, 11, s14);
                                n10 += s14;
                                break;
                            }
                            case 9: {
                                short s4 = (short)k.a(byArray, n10);
                                short s5 = (short)k.a(byArray, n10 += 2);
                                short s16 = (short)k.a(byArray, n10 += 2);
                                n10 += 2;
                                byArray2 = new byte[8];
                                d.a(byArray2, 2, s4);
                                d.a(byArray2, 4, s5);
                                d.a(byArray2, 6, s16);
                                break;
                            }
                            case 10: {
                                short s17 = (short)(byArray[n10++] & 0xFF);
                                byte[] byArray3 = new byte[3];
                                byArray2 = byArray3;
                                byArray3[2] = (byte)s17;
                                break;
                            }
                            case 0: {
                                short s18 = (short)(byArray[n10++] & 0xFF);
                                n6 = s18;
                                object3 = new byte[s18][];
                                byArray2 = null;
                            }
                        }
                        if (byArray2 != null) {
                            byArray2[0] = (byte)(n4 & 0xFF);
                            byArray2[1] = 0;
                            if (object == object3) {
                                object[n7] = (byte)byArray2;
                                ++n7;
                            } else {
                                object[n8] = (byte)byArray2;
                                ++n8;
                            }
                        }
                        if (object != object3 || n6 != 0) continue;
                        s2 = 0;
                        for (n3 = 0; n3 < ((byte[][])object3).length; ++n3) {
                            s2 += object3[n3].length;
                        }
                        byte[] byArray4 = new byte[2 + ((byte[][])object3).length * 4 + s2];
                        byArray2 = byArray4;
                        byArray4[0] = 0;
                        byArray2[1] = (byte)((byte[][])object3).length;
                        n3 = 2 + ((byte[][])object3).length * 4;
                        for (n12 = 0; n12 < ((byte[][])object3).length; ++n12) {
                            d.d(byArray2, 2 + n12 * 4, object3[n12].length);
                            System.arraycopy(object3[n12], 0, byArray2, n3, object3[n12].length);
                            n3 += object3[n12].length;
                        }
                        object2[n8] = (short)byArray2;
                        n7 = 0;
                        object3 = null;
                        ++n8;
                    }
                    this.a = (byte[][])object2;
                    continue;
                }
                byteArrayInputStream.skip(2L);
                byteArrayInputStream.read(byArray, 0, 4);
                n2 = k.b(byArray, 0);
                byteArrayInputStream.skip(n2);
            } while (!bl);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final void a(Graphics graphics, String string, int n, int n2, int n3, int n4, int n5) {
        int n6 = k.a[41].p + (k.a[41].a[1] & 0xFF);
        if (n5 > this.h) {
            n5 = this.h;
        }
        for (int i2 = n4; i2 < n5; ++i2) {
            b.q = i2 > 0 ? this.a[i2 - 1] + 1 : 0;
            b.r = this.a[i2];
            k.a[41].a(graphics, string, n, n2 + (i2 - n4) * n6, 4);
        }
        b.q = -1;
        b.r = -1;
    }

    public final void a(String string, int n) {
        this.h = 0;
        int n2 = string.length();
        int n3 = 0;
        int n4 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            int n5;
            char c = string.charAt(i2);
            if (c > ' ') {
                int n6 = b.h[c] & 0xFF;
                n5 = (k.a[41].d[n6 << 2] & 0xFF) << 1;
                n3 += (k.a[41].a[n5] & 0xFF) - k.a[41].d[(n6 << 2) + 1] + k.a[41].d[1];
            } else if (c == ' ' && i2 + 1 < n2 && (string.charAt(i2 + 1) == '?' || string.charAt(i2 + 1) == '!' || string.charAt(i2 + 1) == ':')) {
                n3 += (k.a[41].a[0] & 0xFF) + k.a[41].d[1];
                n5 = b.h[string.charAt(i2 + 1)] & 0xFF;
                int n7 = (k.a[41].d[n5 << 2] & 0xFF) << 1;
                n3 += (k.a[41].a[n7] & 0xFF) - k.a[41].d[(n5 << 2) + 1] + k.a[41].d[1];
            } else {
                if (c == ' ') {
                    n3 += (k.a[41].a[0] & 0xFF) + k.a[41].d[1];
                    n4 = i2 + 1;
                    continue;
                }
                if (c != '\n') continue;
                n3 = 0;
                this.a[this.h++] = (short)i2;
                continue;
            }
            if (n3 > n) {
                i2 = n4 - 1;
                this.a[this.h++] = (short)i2;
                n3 = 0;
            }
            if (string.charAt(i2) != ' ') continue;
            n4 = i2 + 1;
        }
        this.a[this.h++] = (short)n2;
    }

    public static final void a(byte[] byArray, int n, short s) {
        byArray[n] = (byte)(s & 0xFF);
        byArray[n + 1] = (byte)(s >> 8 & 0xFF);
    }

    public static final void d(byte[] byArray, int n, int n2) {
        byArray[n] = (byte)(n2 & 0xFF);
        byArray[n + 1] = (byte)(n2 >> 8 & 0xFF);
        byArray[n + 2] = (byte)(n2 >> 16 & 0xFF);
        byArray[n + 3] = (byte)(n2 >> 24 & 0xFF);
    }
}
