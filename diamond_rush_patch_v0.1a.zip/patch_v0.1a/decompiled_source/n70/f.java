/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 */
import javax.microedition.lcdui.Graphics;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class f {
    public boolean a;
    public int[] a;
    public int[] b;
    public int[] c;
    public int[] d;
    public int a = true;
    public int b;

    public static final f a(int[] nArray, int n, int n2, boolean bl) {
        if (nArray == null) {
            System.out.println("createRGBImage - image_data==null!!!");
            return null;
        }
        f f2 = new f();
        new f().a = bl;
        f2.a = n;
        f2.b = n2;
        f2.a = new int[n * n2];
        System.arraycopy(nArray, 0, f2.a, 0, n * n2);
        return f2;
    }

    public final void a(Graphics graphics, int n, int n2, int n3, int n4, boolean bl) {
        int[] nArray;
        int n5;
        if (this.a == null) {
            return;
        }
        int n6 = n;
        int n7 = n2;
        int n8 = this.a;
        int n9 = this.b;
        boolean bl2 = false;
        if (n3 != 0) {
            if ((n3 & 8) != 0) {
                n6 -= this.a;
            } else if ((n3 & 1) != 0) {
                n6 -= this.a >> 1;
            }
            if ((n3 & 0x20) != 0) {
                n7 -= this.b;
            } else if ((n3 & 2) != 0) {
                n7 -= this.b >> 1;
            }
        }
        if ((n5 = k.a(graphics)) != -1) {
            n6 += k.g[n5];
            n7 += k.h[n5];
        }
        if (n4 != 0) {
            nArray = (n4 & 1) != 0 && (n4 & 2) == 0 ? this.b : ((n4 & 1) == 0 && (n4 & 2) != 0 ? this.c : this.d);
            if (nArray == null) {
                nArray = this.a(n4);
            }
        } else {
            nArray = this.a;
        }
        try {
            graphics.drawRGB(nArray, 0, this.a, n6, n7, n8, n9, this.a && bl);
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public final int[] a(int n) {
        int[] nArray;
        block11: {
            block10: {
                if (this.a == null) {
                    return null;
                }
                if (this.a <= 0 || this.b <= 0) {
                    return null;
                }
                nArray = new int[this.a.length];
                System.arraycopy(this.a, 0, nArray, 0, this.a * this.b);
                if ((n & 1) == 0) break block10;
                if ((n & 2) != 0) {
                    int n2 = this.a >> 1;
                    int n3 = this.b >> 1;
                    int n4 = 0;
                    int n5 = (this.b - 1) * this.a;
                    for (int i2 = 0; i2 < n3; ++i2) {
                        for (int i3 = 0; i3 < n2; ++i3) {
                            nArray[n4 + i3] = nArray[n5 + this.a - i3 - 1];
                            nArray[n5 + this.a - i3 - 1] = this.a[n4 + i3];
                            nArray[n5 + i3] = nArray[n4 + this.a - i3 - 1];
                            nArray[n4 + this.a - i3 - 1] = this.a[n5 + i3];
                        }
                        n4 += this.a;
                        n5 -= this.a;
                    }
                } else {
                    int n6 = this.a >> 1;
                    int n7 = 0;
                    for (int i4 = 0; i4 < this.b; ++i4) {
                        for (int i5 = 0; i5 < n6; ++i5) {
                            nArray[n7 + i5] = nArray[n7 + this.a - i5 - 1];
                            nArray[n7 + this.a - i5 - 1] = this.a[n7 + i5];
                        }
                        n7 += this.a;
                    }
                }
                break block11;
            }
            if ((n & 2) == 0) break block11;
            int n8 = this.b >> 1;
            int n9 = 0;
            int n10 = (this.b - 1) * this.a;
            for (int i6 = 0; i6 < n8; ++i6) {
                for (int i7 = 0; i7 < this.a; ++i7) {
                    nArray[n9 + i7] = nArray[n10 + i7];
                    nArray[n10 + i7] = this.a[n9 + i7];
                }
                n9 += this.a;
                n10 -= this.a;
            }
        }
        return nArray;
    }

    public final void a(int n, boolean bl) {
        if (n == 0) {
            return;
        }
        if (!bl) {
            if ((n & 1) != 0 && (n & 2) == 0 && this.b != null) {
                return;
            }
            if ((n & 1) == 0 && (n & 2) != 0 && this.c != null) {
                return;
            }
            if (this.d != null) {
                return;
            }
        }
        int[] nArray = this.a(n);
        if ((n & 1) != 0 && (n & 2) == 0) {
            this.b = nArray;
            return;
        }
        if ((n & 1) == 0 && (n & 2) != 0) {
            this.c = nArray;
            return;
        }
        this.d = nArray;
    }
}
