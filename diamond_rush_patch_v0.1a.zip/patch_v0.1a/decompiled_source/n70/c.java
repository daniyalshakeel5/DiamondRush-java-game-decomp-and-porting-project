/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Graphics
 */
import javax.microedition.lcdui.Graphics;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class c {
    public static byte[][] a;
    public static byte a;
    public static byte b;
    public static int a;
    public static byte[][] b;
    public static byte c;
    public static byte d;
    public static boolean a;
    public static int b;

    public static final void a(int n) {
        int n2;
        int n3;
        if ((a = (byte)(a + b)) > 24) {
            a = 0;
            for (n3 = 9; n3 >= 1; --n3) {
                for (n2 = 0; n2 < 9; ++n2) {
                    c.a[n2][n3] = a[n2][n3 - 1];
                }
            }
            c.b(n);
        }
        if (a && (c = (byte)(c + d)) > 24) {
            c = 0;
            for (n3 = 9; n3 >= 1; --n3) {
                for (n2 = 0; n2 < 9; ++n2) {
                    c.b[n2][n3] = b[n2][n3 - 1];
                }
            }
            c.b(n);
        }
    }

    public static final void b(int n) {
        int n2;
        int n3;
        for (n3 = 0; n3 < 9; ++n3) {
            c.a[n3][0] = 0;
        }
        if (a) {
            for (n3 = 0; n3 < 9; ++n3) {
                c.b[n3][0] = 0;
            }
        }
        int n4 = 0;
        for (n2 = 0; n2 < n; ++n2) {
            n3 = e.a(0, 9);
            while (a[n3][0] != 0) {
                n3 = e.a(0, 9);
            }
            n4 = e.a(1, 3);
            c.a[n3][0] = (byte)n4;
        }
        if (a) {
            for (n2 = 0; n2 < n; ++n2) {
                n3 = e.a(0, 9);
                while (b[n3][0] != 0) {
                    n3 = e.a(0, 9);
                }
                n4 = e.a(1, 3);
                c.b[n3][0] = (byte)n4;
            }
        }
    }

    public static final void a(Graphics graphics) {
        int n;
        int n2;
        for (n2 = 0; n2 < 9; ++n2) {
            for (n = 0; n < 10; ++n) {
                if (a[n2][n] == 1) {
                    k.a[k.c(2)].a(graphics, a, n2 * 24, (n - 1) * 24 + a, 0, 0, 0);
                    continue;
                }
                if (a[n2][n] != 2) continue;
                k.a[k.c(2)].a(graphics, 0, n2 * 24, (n - 1) * 24 + a, 0, 0, 0);
            }
        }
        if (a) {
            for (n2 = 0; n2 < 9; ++n2) {
                for (n = 0; n < 10; ++n) {
                    if (b[n2][n] == 1) {
                        k.a[k.c(2)].a(graphics, 0, n2 * 24, (n - 1) * 24 + c, 0, 0, 0);
                        continue;
                    }
                    if (b[n2][n] != 2) continue;
                    k.a[k.c(2)].a(graphics, 0, n2 * 24, (n - 1) * 24 + c, 0, 0, 0);
                }
            }
        }
        a = (a + 1) % b;
    }

    static {
        a = 0;
        b = (byte)4;
        a = 0;
        c = 0;
        d = (byte)2;
        a = false;
        b = 0;
    }
}
