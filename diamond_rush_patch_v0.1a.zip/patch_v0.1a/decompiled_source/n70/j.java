/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.media.Manager
 *  javax.microedition.media.Player
 *  javax.microedition.media.PlayerListener
 *  javax.microedition.media.control.VolumeControl
 */
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import javax.microedition.media.PlayerListener;
import javax.microedition.media.control.VolumeControl;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class j
implements Runnable,
PlayerListener {
    public static boolean a = false;
    public int a;
    public int b;
    public Player a;
    public Player[] a;
    public ByteArrayInputStream[] a;
    public boolean b;
    public a a;
    public byte[] a = null;
    public static final byte[] b = new byte[]{64, 31, 0, 0};
    public static final byte[] c = new byte[]{1, 0};
    public static final byte[] d = new byte[]{8, 0};
    public static final short[] a;
    public static final short[] b;
    public static final byte[] e;
    public static final byte[] f;
    public static final byte[] g;
    public static final byte[] h;
    public static final byte[] i;
    public static final byte[] j;
    public static final byte[] k;
    public static final byte[] l;

    public final void a(int n) {
        if (a) {
            return;
        }
        if (k.a && n >= 5) {
            return;
        }
        try {
            int n2 = k.a(this.a, n * 8 + 4);
            byte[] byArray = new byte[n2];
            this.a.a(byArray);
            byte[] byArray2 = this.a(n) == "audio/amr" ? byArray : j.a(byArray);
            this.a[n] = new ByteArrayInputStream(byArray2);
            if (this.a == null) {
                this.a = new Player[11];
            }
            this.a[n].reset();
            this.a[n] = Manager.createPlayer((InputStream)this.a[n], (String)this.a(n));
            this.a[n].addPlayerListener((PlayerListener)this);
            this.a[n].realize();
            this.a[n].prefetch();
            System.gc();
            return;
        }
        catch (Exception exception) {
            String cfr_ignored_0 = "2_" + n + exception.toString();
            return;
        }
    }

    public final String a(int n) {
        switch (n) {
            case 0: 
            case 1: 
            case 2: {
                return "audio/amr";
            }
        }
        return "audio/x-wav";
    }

    public final void a() {
        if (a) {
            return;
        }
        if (this.a == null) {
            try {
                this.a = new ByteArrayInputStream[11];
                this.a = new a("/snd.f");
                this.a.a(1);
                this.a = new byte[88];
                this.a.a(this.a);
                return;
            }
            catch (Exception exception) {
                String cfr_ignored_0 = "3" + exception.toString();
            }
        }
    }

    public final void b() {
        if (a) {
            return;
        }
        try {
            this.a = -1;
            this.b = Integer.MIN_VALUE;
            this.a.b();
            this.a.a();
            this.a = null;
            this.a = null;
            System.gc();
            return;
        }
        catch (Exception exception) {
            String cfr_ignored_0 = "4" + exception.toString();
            return;
        }
    }

    public final void c() {
        if (this.a != null) {
            this.e();
        }
        this.a = null;
        a = true;
        this.a = null;
        if (this.a != null) {
            for (int i2 = 0; i2 < 11; ++i2) {
                if (this.a[i2] == null) continue;
                this.a[i2].deallocate();
                this.a[i2] = null;
            }
        }
        this.a = null;
    }

    public final synchronized void b(int n) {
        if (k.a && n >= 6) {
            return;
        }
        if (a) {
            return;
        }
        int n2 = this.a(n);
        if (this.b && this.b < n2) {
            this.e();
            this.a = n;
            this.b = n2;
            this.a = this.a[this.a];
            try {
                ((VolumeControl)this.a.getControl("VolumeControl")).setLevel(70);
                this.a.start();
                return;
            }
            catch (Exception exception) {}
        }
    }

    public final int a(int n) {
        switch (n) {
            case 0: 
            case 1: {
                return 30;
            }
            case 2: 
            case 5: 
            case 6: 
            case 8: 
            case 9: {
                return 20;
            }
            case 3: 
            case 4: 
            case 7: 
            case 10: {
                return 10;
            }
        }
        return 0;
    }

    public final synchronized void run() {
    }

    public final void c(int n) {
        if (a) {
            return;
        }
        try {
            this.e();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(k.a("/osnd.f", n));
            this.a = Manager.createPlayer((InputStream)byteArrayInputStream, (String)"audio/midi");
            this.a.addPlayerListener((PlayerListener)this);
            this.a.prefetch();
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.toString();
            return;
        }
    }

    public final void d() {
        if (a) {
            return;
        }
        if (this.b && this.a != null) {
            try {
                this.b = 30;
                this.a.start();
                ((VolumeControl)this.a.getControl("VolumeControl")).setLevel(70);
                return;
            }
            catch (Exception exception) {
                Exception exception2 = exception;
                exception.toString();
                this.e();
            }
        }
    }

    public final void e() {
        if (a) {
            return;
        }
        try {
            if (this.a != null && 400 == this.a.getState()) {
                this.a.stop();
            }
        }
        catch (Exception exception) {
            String cfr_ignored_0 = "1" + exception.toString();
        }
        this.a = null;
        this.a = -1;
        this.b = Integer.MIN_VALUE;
    }

    public final void playerUpdate(Player player, String string, Object object) {
        if (string.equals("endOfMedia") || string.equals("closed") || string.equals("stopped") || string.equals("stoppedAtTime")) {
            this.e();
        }
    }

    public final void f() {
        this.e();
    }

    public static final int a(byte[] byArray) {
        int n = 0;
        int n2 = k.b(byArray, 16);
        n = 16 + (n2 + 4);
        n2 = k.b(byArray, n += 4);
        n += n2 + 4;
        return n += 8;
    }

    public static final int b(byte[] byArray) {
        int n = 0;
        int n2 = k.b(byArray, 16);
        n = 16 + (n2 + 4);
        n2 = k.b(byArray, n += 4);
        n += n2 + 4;
        n2 = k.b(byArray, n += 4);
        return n2;
    }

    public static final byte[] a(int n) {
        int n2 = n + 44;
        byte[] byArray = new byte[n2];
        System.arraycopy(e, 0, byArray, 0, 4);
        byArray[4] = (byte)((n2 -= 8) & 0xFF);
        byArray[5] = (byte)(n2 >> 8 & 0xFF);
        byArray[6] = (byte)(n2 >> 16 & 0xFF);
        byArray[7] = (byte)(n2 >> 24 & 0xFF);
        System.arraycopy(f, 0, byArray, 8, 4);
        System.arraycopy(g, 0, byArray, 12, 4);
        System.arraycopy(i, 0, byArray, 16, 4);
        System.arraycopy(j, 0, byArray, 20, 2);
        System.arraycopy(k, 0, byArray, 22, 2);
        System.arraycopy(l, 0, byArray, 24, 4);
        System.arraycopy(b, 0, byArray, 28, 4);
        System.arraycopy(c, 0, byArray, 32, 2);
        System.arraycopy(d, 0, byArray, 34, 2);
        System.arraycopy(h, 0, byArray, 36, 4);
        n2 = n;
        byArray[40] = (byte)(n2 & 0xFF);
        byArray[41] = (byte)(n2 >> 8 & 0xFF);
        byArray[42] = (byte)(n2 >> 16 & 0xFF);
        byArray[43] = (byte)(n2 >> 24 & 0xFF);
        return byArray;
    }

    public static final void a(byte[] byArray, byte[] byArray2, int n, int n2) {
        int n3 = k.a(byArray, n);
        int n4 = byArray[n + 2];
        byArray2[n2] = (byte)(n3 >>> 8);
        byArray2[n2] = (byte)(byArray2[n2] & 0x7F | ~byArray2[n2] & 0x80);
        ++n2;
        n += 4;
        boolean bl = false;
        int n5 = 0;
        short s = b[n4];
        for (int i2 = 504; i2 > 0; --i2) {
            int n6;
            if (bl) {
                n6 = n5 & 0xF;
            } else {
                n5 = byArray[n++];
                n6 = n5 >> 4 & 0xF;
            }
            boolean bl2 = bl = !bl;
            if ((n4 += a[n6]) < 0) {
                n4 = 0;
            }
            if (n4 > 88) {
                n4 = 88;
            }
            int n7 = n6 & 8;
            int n8 = s >> 3;
            if (((n6 &= 7) & 4) != 0) {
                n8 += s;
            }
            if ((n6 & 2) != 0) {
                n8 += s >> 1;
            }
            if ((n6 & 1) != 0) {
                n8 += s >> 2;
            }
            n3 = n7 != 0 ? (n3 -= n8) : (n3 += n8);
            s = b[n4];
            byArray2[n2] = (byte)(n3 >>> 8);
            byArray2[n2] = (byte)(byArray2[n2] & 0x7F | ~byArray2[n2] & 0x80);
            ++n2;
        }
    }

    public static final byte[] a(byte[] byArray) {
        int n = j.a(byArray);
        int n2 = j.b(byArray);
        int n3 = n2 >> 8;
        int n4 = 505 * n3;
        byte[] byArray2 = j.a(n4);
        int n5 = 44;
        for (int i2 = 0; i2 < n3; ++i2) {
            j.a(byArray, byArray2, n, n5);
            n += 256;
            n5 += 505;
        }
        return byArray2;
    }

    static {
        byte[] byArray = new byte[]{-128, 62, 0, 0};
        byte[] byArray2 = new byte[]{2, 0};
        byte[] byArray3 = new byte[]{16, 0};
        a = new short[]{-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8};
        b = new short[]{7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, Short.MAX_VALUE};
        e = new byte[]{82, 73, 70, 70};
        f = new byte[]{87, 65, 86, 69};
        g = new byte[]{102, 109, 116, 32};
        h = new byte[]{100, 97, 116, 97};
        i = new byte[]{16, 0, 0, 0};
        j = new byte[]{1, 0};
        k = new byte[]{1, 0};
        l = new byte[]{64, 31, 0, 0};
    }
}
