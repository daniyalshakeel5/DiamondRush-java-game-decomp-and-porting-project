/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import java.io.InputStream;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class a {
    public static byte[][] a = null;
    public static String[] a = null;
    public static int a = 0;
    public int b = -1;
    public int c = 0;

    public a(String string) {
        if (a == null) {
            a = new byte[50][];
            a = new String[50];
            a = 0;
        }
        this.c = 0;
        for (int i = 0; i < a; ++i) {
            if (!a[i].equals(string)) continue;
            this.b = i;
            return;
        }
        try {
            InputStream inputStream = string.getClass().getResourceAsStream(string);
            int n = inputStream.read();
            n += inputStream.read() << 8;
            n += inputStream.read() << 16;
            this.b = a;
            a.a[this.b] = string;
            a.a[this.b] = new byte[n += inputStream.read() << 24];
            for (int i = 0; i < n; ++i) {
                a.a[this.b][i] = (byte)inputStream.read();
            }
            inputStream.close();
            ++a;
            System.out.println("metaInputStream(" + string + ") - loaded #" + this.b + " size=" + n);
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            exception.printStackTrace();
        }
        System.gc();
    }

    public final int a() {
        if (this.c >= a[this.b].length) {
            return -1;
        }
        return a[this.b][this.c++];
    }

    public final int a(byte[] byArray) {
        if (this.c >= a[this.b].length) {
            return -1;
        }
        int n = byArray.length;
        if (n > a[this.b].length - this.c) {
            n = a[this.b].length - this.c;
        }
        System.arraycopy(a[this.b], this.c, byArray, 0, n);
        this.c += n;
        return n;
    }

    public final int a(byte[] byArray, int n, int n2) throws IOException {
        if (this.c >= a[this.b].length) {
            return -1;
        }
        int n3 = byArray.length - n;
        if (n2 < n3) {
            n3 = n2;
        }
        if (n3 > a[this.b].length - this.c) {
            n3 = a[this.b].length - this.c;
        }
        System.arraycopy(a[this.b], this.c, byArray, n, n3);
        this.c += n3;
        return n3;
    }

    public final int a(int n) {
        if (n <= 0) {
            return 0;
        }
        if (this.c >= a[this.b].length) {
            return 0;
        }
        int n2 = n;
        if (n2 > a[this.b].length - this.c) {
            n2 = a[this.b].length - this.c;
        }
        this.c += n2;
        return n2;
    }

    public final void a() {
        this.c = 0;
    }

    public static final byte[] a(String string) {
        a a2 = new a(string);
        return a[a2.b];
    }

    public static final int a(String string) {
        a a2 = new a(string);
        return a[a2.b].length;
    }

    public final void b() {
        a.a[this.b] = null;
    }
}
